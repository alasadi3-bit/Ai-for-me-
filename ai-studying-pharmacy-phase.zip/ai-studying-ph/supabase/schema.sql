-- AI for Studying Pharmacy: database schema (run once in the Supabase SQL editor).
-- Safe to re-run: uses IF NOT EXISTS / DROP POLICY IF EXISTS.
-- Every table is owned by the signed-in user and protected by Row Level Security.
-- No service-role key is ever needed by this app.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- documents
create table if not exists public.documents (
  id             uuid primary key default gen_random_uuid(),
  owner          uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind           text not null check (kind in ('source','handout')),
  title          text not null,
  file_name      text not null,
  storage_path   text not null,
  file_type      text not null default 'pdf',
  status         text not null default 'uploaded'
                 check (status in ('uploaded','processing','processed','failed','unsupported')),
  status_message text,
  pages_total    integer,
  pages_done     integer not null default 0,
  created_at     timestamptz not null default now()
);

-- One row per PDF page. page_index is the physical (1-based) PDF page and is
-- the only page reference the app treats as reliable. printed_label is a
-- detected page number that is shown as unverified.
create table if not exists public.document_pages (
  id            uuid primary key default gen_random_uuid(),
  owner         uuid not null default auth.uid() references auth.users(id) on delete cascade,
  document_id   uuid not null references public.documents(id) on delete cascade,
  page_index    integer not null,
  printed_label text,
  raw_text      text not null default '',
  status        text not null default 'ok' check (status in ('ok','empty','failed')),
  flags         text[] not null default '{}',
  error         text,
  unique (document_id, page_index)
);

-- Paragraph-level passages. raw_text is the text exactly as extracted (lines
-- joined with newlines); text is the same content with whitespace normalised
-- (and line-end hyphens joined, flagged 'dehyphenated').
create table if not exists public.passages (
  id           uuid primary key default gen_random_uuid(),
  owner        uuid not null default auth.uid() references auth.users(id) on delete cascade,
  document_id  uuid not null references public.documents(id) on delete cascade,
  page_index   integer not null,
  seq          integer not null,
  kind         text not null default 'paragraph' check (kind in ('heading','paragraph')),
  heading_path text,
  raw_text     text not null,
  text         text not null,
  flags        text[] not null default '{}',
  unique (document_id, page_index, seq)
);
create index if not exists passages_doc_order on public.passages (document_id, page_index, seq);

-- Sentence units. Joining a passage's units with single spaces must equal the
-- passage text (checked in code and in tests).
create table if not exists public.units (
  id          uuid primary key default gen_random_uuid(),
  owner       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  passage_id  uuid not null references public.passages(id) on delete cascade,
  document_id uuid not null references public.documents(id) on delete cascade,
  idx         integer not null,
  text        text not null,
  kind        text not null default 'sentence' check (kind in ('sentence','fragment')),
  unique (passage_id, idx)
);
create index if not exists units_passage on public.units (passage_id, idx);

-- Machine translations are append-only: a row is never updated. The newest row
-- for a unit is the one displayed.
create table if not exists public.translations (
  id             uuid primary key default gen_random_uuid(),
  owner          uuid not null default auth.uid() references auth.users(id) on delete cascade,
  unit_id        uuid not null references public.units(id) on delete cascade,
  machine_text   text not null,
  model          text not null,
  prompt_version text not null,
  flags          text[] not null default '{}',
  checks         jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now()
);
create index if not exists translations_unit on public.translations (unit_id, created_at desc);

-- Corrections are append-only too. They never overwrite machine_text.
create table if not exists public.translation_edits (
  id             uuid primary key default gen_random_uuid(),
  owner          uuid not null default auth.uid() references auth.users(id) on delete cascade,
  translation_id uuid not null references public.translations(id) on delete cascade,
  edited_text    text not null,
  created_at     timestamptz not null default now()
);
create index if not exists translation_edits_tr on public.translation_edits (translation_id, created_at desc);

-- Links between a handout passage and a source passage.
-- method 'manual' = created by the student. 'auto' is reserved for a future,
-- tested automatic matcher; nothing in the app writes 'auto' today.
create table if not exists public.links (
  id                  uuid primary key default gen_random_uuid(),
  owner               uuid not null default auth.uid() references auth.users(id) on delete cascade,
  handout_passage_id  uuid not null references public.passages(id) on delete cascade,
  source_passage_id   uuid not null references public.passages(id) on delete cascade,
  method              text not null default 'manual' check (method in ('manual','auto')),
  status              text not null default 'manual' check (status in ('manual','auto_verified','auto_uncertain','auto_confirmed','auto_rejected')),
  evidence            jsonb,
  created_at          timestamptz not null default now(),
  unique (handout_passage_id, source_passage_id)
);

-- Where the student stopped, plus the study timer (timestamp based, so it stays
-- correct while the iPad is locked).
create table if not exists public.study_progress (
  owner                uuid not null default auth.uid() references auth.users(id) on delete cascade,
  handout_id           uuid not null references public.documents(id) on delete cascade,
  source_id            uuid references public.documents(id) on delete set null,
  passage_index        integer not null default 0,
  source_page          integer,
  timer_accumulated_ms bigint not null default 0,
  timer_started_at     timestamptz,
  updated_at           timestamptz not null default now(),
  primary key (owner, handout_id)
);

-- Cached pre-lesson content for a handout + source pair.
create table if not exists public.prelessons (
  id             uuid primary key default gen_random_uuid(),
  owner          uuid not null default auth.uid() references auth.users(id) on delete cascade,
  handout_id     uuid not null references public.documents(id) on delete cascade,
  source_id      uuid references public.documents(id) on delete cascade,
  content        jsonb not null,
  model          text not null,
  prompt_version text not null,
  created_at     timestamptz not null default now()
);
create index if not exists prelessons_pair on public.prelessons (handout_id, source_id, created_at desc);

-- ------------------------------------------------------ row level security
do $$
declare t text;
begin
  foreach t in array array[
    'documents','document_pages','passages','units','translations',
    'translation_edits','links','study_progress','prelessons'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "%1$s_owner_all" on public.%1$I', t);
    execute format(
      'create policy "%1$s_owner_all" on public.%1$I for all to authenticated using (owner = auth.uid()) with check (owner = auth.uid())',
      t);
  end loop;
end $$;

grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;

-- ------------------------------------------------- private storage bucket
insert into storage.buckets (id, name, public)
values ('documents', 'documents', false)
on conflict (id) do update set public = false;

drop policy if exists "documents_files_select" on storage.objects;
drop policy if exists "documents_files_insert" on storage.objects;
drop policy if exists "documents_files_update" on storage.objects;
drop policy if exists "documents_files_delete" on storage.objects;

create policy "documents_files_select" on storage.objects for select to authenticated
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "documents_files_insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "documents_files_update" on storage.objects for update to authenticated
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "documents_files_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text);
