-- Phase 2: profiles, roles (admin foundation) and security hardening.
-- Run AFTER supabase/schema.sql, in the Supabase SQL editor. Safe to re-run.
-- (If you ever re-run schema.sql, run this file again afterwards: schema.sql re-grants table
--  privileges that this file narrows.)
--
-- Design rules:
--   * Every student can only read/write their own rows (unchanged, owner = auth.uid()).
--   * A user can NEVER change their own role. Three independent layers enforce it:
--       1. no INSERT/DELETE grant and no policy for clients on public.profiles,
--       2. UPDATE is granted only on the display_name column,
--       3. a trigger rejects any role change made through the API as `authenticated`/`anon`.
--     Roles are changed only from the Supabase SQL editor (see the setup guide) or with the
--     service role on a trusted machine. This app never uses the service role.
--   * Admins can list profiles. They get NO access to students' documents, passages or
--     translations: that would be a privacy decision to make deliberately later.

-- ------------------------------------------------------------------ profiles
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  email        text,
  display_name text,
  role         text not null default 'student' check (role in ('student', 'admin')),
  created_at   timestamptz not null default now()
);

-- Every new auth user gets a profile, always as 'student'.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Users who signed up before this migration.
insert into public.profiles (id, email)
select id, email from auth.users
on conflict (id) do nothing;

-- Layer 3: a role may only change from a trusted connection (SQL editor / service role).
create or replace function public.profiles_guard() returns trigger
language plpgsql as $$
begin
  if new.role is distinct from old.role and current_user in ('authenticated', 'anon') then
    raise exception 'roles cannot be changed through the API' using errcode = '42501';
  end if;
  if new.id is distinct from old.id then
    raise exception 'profile id is immutable' using errcode = '42501';
  end if;
  return new;
end $$;

drop trigger if exists profiles_guard_trg on public.profiles;
create trigger profiles_guard_trg before update on public.profiles
  for each row execute function public.profiles_guard();

-- is_admin(): used by policies now and by future admin features. SECURITY DEFINER so that it
-- can read profiles without recursing through the profiles policies.
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'admin' from public.profiles where id = auth.uid()), false)
$$;
revoke all on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;

alter table public.profiles enable row level security;
drop policy if exists "profiles_select_own_or_admin" on public.profiles;
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
create policy "profiles_update_own" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
-- (No INSERT or DELETE policy: with RLS enabled that means clients cannot do either.)

-- Layer 1 + 2: privileges.
revoke all on public.profiles from authenticated, anon;
grant select on public.profiles to authenticated;
grant update (display_name) on public.profiles to authenticated;

-- ---------------------------------------------- privileges on the other tables
-- Nothing is ever readable by the anonymous role.
revoke all on all tables in schema public from anon;
-- Machine translations and corrections are append-only: no UPDATE for clients.
revoke update on public.translations from authenticated;
revoke update on public.translation_edits from authenticated;

-- ------------------------------------- parent rows must belong to the same owner
-- Foreign keys do not check ownership, so without this a user could attach their own rows to
-- another user's document or passage (the row would be invisible to the victim, but it would
-- be deleted with the victim's parent row and would confirm that the parent id exists).
create or replace function public.enforce_parent_owner() returns trigger
language plpgsql as $$
declare
  spec text; col text; tbl text; val uuid; parent_owner uuid; j jsonb := to_jsonb(new);
begin
  foreach spec in array tg_argv loop
    col := split_part(spec, ':', 1);
    tbl := split_part(spec, ':', 2);
    val := nullif(j ->> col, '')::uuid;
    if val is not null then
      parent_owner := null;
      execute format('select owner from public.%I where id = $1', tbl) into parent_owner using val;
      if parent_owner is distinct from new.owner then
        raise exception '% % does not exist or belongs to another user', tbl, val using errcode = '42501';
      end if;
    end if;
  end loop;
  return new;
end $$;

do $$
declare r record;
begin
  for r in select * from (values
    ('document_pages',    'document_id:documents'),
    ('passages',          'document_id:documents'),
    ('units',             'passage_id:passages,document_id:documents'),
    ('translations',      'unit_id:units'),
    ('translation_edits', 'translation_id:translations'),
    ('links',             'handout_passage_id:passages,source_passage_id:passages'),
    ('study_progress',    'handout_id:documents,source_id:documents'),
    ('prelessons',        'handout_id:documents,source_id:documents')
  ) as t(tbl, spec) loop
    execute format('drop trigger if exists %I on public.%I', r.tbl || '_parent_owner', r.tbl);
    execute format(
      'create trigger %I before insert or update on public.%I for each row execute function public.enforce_parent_owner(%s)',
      r.tbl || '_parent_owner', r.tbl,
      (select string_agg(quote_literal(s), ',') from unnest(string_to_array(r.spec, ',')) as s));
  end loop;
end $$;

-- A document's file must live in its owner's folder of the private bucket.
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'documents_storage_path_owner') then
    alter table public.documents
      add constraint documents_storage_path_owner
      check (storage_path like owner::text || '/%' and storage_path not like '%..%') not valid;
  end if;
end $$;

-- ------------------------------------------------------------- private storage
insert into storage.buckets (id, name, public)
values ('documents', 'documents', false)
on conflict (id) do update set public = false;
update storage.buckets
   set file_size_limit = 52428800,                    -- 50 MB per file
       allowed_mime_types = array['application/pdf']  -- PDFs only
 where id = 'documents';

drop policy if exists "documents_files_select" on storage.objects;
drop policy if exists "documents_files_insert" on storage.objects;
drop policy if exists "documents_files_update" on storage.objects;
drop policy if exists "documents_files_delete" on storage.objects;

-- Same rule as before (first folder = the caller's user id), plus: no '..' in the name.
create policy "documents_files_select" on storage.objects for select to authenticated
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text and name not like '%..%');
create policy "documents_files_insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text and name not like '%..%');
create policy "documents_files_update" on storage.objects for update to authenticated
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text and name not like '%..%')
  with check (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text and name not like '%..%');
create policy "documents_files_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'documents' and (storage.foldername(name))[1] = auth.uid()::text and name not like '%..%');
