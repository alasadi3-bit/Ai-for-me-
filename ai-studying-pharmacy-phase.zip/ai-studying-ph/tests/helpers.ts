import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
// @ts-ignore - pdf.js ships its own types for the legacy build
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import { processPdfPage, type PageRows } from '../src/lib/process';

export function fixturePath(name: string): string {
  return path.join(__dirname, 'fixtures', name);
}

export async function extractFixture(name: string): Promise<PageRows[]> {
  const data = new Uint8Array(readFileSync(fixturePath(name)));
  const doc = await pdfjs.getDocument({ data, useSystemFonts: true, verbosity: 0 }).promise;
  const out: PageRows[] = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    out.push(await processPdfPage('00000000-0000-0000-0000-000000000001', page, i, () => randomUUID()));
  }
  return out;
}
