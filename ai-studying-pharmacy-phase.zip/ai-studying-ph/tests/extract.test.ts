import test from 'node:test';
import assert from 'node:assert/strict';
import { extractFixture } from './helpers';
import { classifyDocument, mapLigatures, extractPage } from '../src/lib/extract';
import { splitSentences, unitsPreserveText, normaliseWhitespace } from '../src/lib/sentences';

test('source.pdf: page count, physical page indexes, printed labels', async () => {
  const pages = await extractFixture('source.pdf');
  assert.equal(pages.length, 4);
  assert.deepEqual(pages.map((p) => p.page.page_index), [1, 2, 3, 4]);
  // printed labels are 43, 44, 45 (physical pages are 1, 2, 3): both kept, never confused
  assert.deepEqual(pages.slice(0, 3).map((p) => p.page.printed_label), ['43', '44', '45']);
  assert.equal(pages[3].page.printed_label, null);
});

test('source.pdf: headings, paragraphs and heading path', async () => {
  const [p1] = await extractFixture('source.pdf');
  const kinds = p1.passages.map((p) => p.kind);
  assert.equal(kinds[0], 'heading');
  assert.equal(p1.passages[0].text, 'Chapter 3: Anti-inflammatory Drugs');
  assert.equal(p1.passages[1].kind, 'heading');
  assert.equal(p1.passages[1].text, '3.1 Aspirin');
  const paras = p1.passages.filter((p) => p.kind === 'paragraph');
  assert.equal(paras.length, 2);
  assert.match(paras[0].heading_path, /Chapter 3: Anti-inflammatory Drugs . 3\.1 Aspirin/);
  // page number line is excluded from passages but recorded as the label
  assert.ok(!p1.passages.some((p) => p.text === '43'));
});

test('source.pdf: line-end hyphen is joined only when flagged, raw text is untouched', async () => {
  const [p1] = await extractFixture('source.pdf');
  const para = p1.passages.find((p) => p.kind === 'paragraph')!;
  assert.ok(para.flags.includes('dehyphenated'));
  assert.match(para.text, /The inhibition of platelet cyclooxygenase/);
  assert.match(para.raw_text, /inhibi-\ntion/); // original lines preserved exactly
});

test('numbers, units and technical terms survive extraction exactly', async () => {
  const pages = await extractFixture('source.pdf');
  const all = pages.flatMap((p) => p.passages.map((x) => x.text)).join(' ');
  for (const needle of ['75 to 100 mg', '75 mg once daily', '300 to 900 mg', '4 to 6 hours', 'Doses above 4 g per day', 'COX-1', 'COX-2', 'thromboxane A2', '0.5 mg/kg', 'e.g. with bronchospasm', 'Fig. 2']) {
    assert.ok(all.includes(needle), `missing: ${needle}`);
  }
});

test('list items become separate passages', async () => {
  const pages = await extractFixture('source.pdf');
  const texts = pages[1].passages.map((p) => p.text);
  assert.ok(texts.some((t) => t.startsWith('• COX-1 inhibition')));
  assert.ok(texts.some((t) => t.startsWith('• COX-2 inhibition')));
});

test('sentence units: exact preservation and correct order for every passage', async () => {
  for (const f of ['source.pdf', 'handout.pdf']) {
    const pages = await extractFixture(f);
    for (const pg of pages) {
      for (const p of pg.passages) {
        const us = pg.units.filter((u) => u.passage_id === p.id).sort((a, b) => a.idx - b.idx);
        assert.ok(us.length >= 1, 'every passage has at least one unit');
        assert.deepEqual(us.map((u) => u.idx), us.map((_, i) => i));
        assert.equal(normaliseWhitespace(us.map((u) => u.text).join(' ')), p.text, `unit join mismatch in ${f} p${pg.page.page_index}`);
      }
    }
  }
});

test('abbreviations and decimals do not split sentences; real boundaries do', () => {
  const t1 = 'Patients may react, e.g. with bronchospasm. See Fig. 2 for the pathway.';
  assert.deepEqual(splitSentences(t1).map((u) => u.text), [
    'Patients may react, e.g. with bronchospasm.',
    'See Fig. 2 for the pathway.',
  ]);
  const t2 = 'The dose is 0.5 mg/kg. Give it twice daily.';
  assert.deepEqual(splitSentences(t2).map((u) => u.text), ['The dose is 0.5 mg/kg.', 'Give it twice daily.']);
  const t3 = 'Dr. Smith measured 5 mg. The next value was 7 mg.';
  assert.equal(splitSentences(t3).length, 2);
  assert.ok(unitsPreserveText(t3, splitSentences(t3)));
});

test('property: for many strings, units always rejoin to the normalised text', () => {
  const samples = [
    'A. B. C. D.',
    'No terminator here',
    '  spaced   out   text.  Another one!  Third? Yes.',
    'See p. 5. Next.',
    '"Quoted sentence." Another one follows.',
    'Value 3.14 is pi. Value 2.71 is e.',
    'e.g. this i.e. that etc. Then done.',
    '1. First item 2. Second item.',
  ];
  for (const s of samples) assert.ok(unitsPreserveText(s, splitSentences(s)), s);
});

test('two-column page: columns are not merged into one paragraph', async () => {
  const pages = await extractFixture('source.pdf');
  const paras = pages[2].passages.filter((p) => p.kind === 'paragraph').map((p) => p.text);
  assert.equal(paras.length, 2);
  assert.ok(paras[0].startsWith('Left column') && !paras[0].includes('Right column'));
  assert.ok(paras[1].startsWith('Right column'));
});

test('suspicious reading order is flagged, not silently reordered', () => {
  // y jumps back up twice: the pattern of a column switch or a misordered stream
  const mk = (str: string, y: number) => ({ str, x: 72, y, w: 200, h: 10, eol: true });
  const page = extractPage(
    [
      mk('First line of a paragraph that is long enough.', 700),
      mk('Second line in the lower area of the page here.', 500),
      mk('Third line jumps back up to the top again now.', 690),
      mk('Fourth line drops low once more on this page.', 480),
      mk('Fifth line jumps back up to the top yet again.', 680),
    ],
    { pageIndex: 1, pageHeight: 800 },
  );
  assert.ok(page.flags.includes('order_jump_or_columns'));
  // text is still all present
  const all = page.passages.map((p) => p.text).join(' ');
  for (const w of ['First line', 'Second line', 'Third line', 'Fourth line', 'Fifth line']) assert.ok(all.includes(w));
});

test('garbled text is flagged', () => {
  const page = extractPage(
    [{ str: 'Valid words here ��� broken glyphs follow here', x: 72, y: 500, w: 300, h: 10, eol: true }],
    { pageIndex: 1, pageHeight: 800 },
  );
  assert.ok(page.passages[0].flags.includes('garbled'));
});

test('image-only page is reported as empty, not as extracted text', async () => {
  const pages = await extractFixture('source.pdf');
  assert.equal(pages[3].page.status, 'empty');
  assert.ok(pages[3].page.flags.includes('no_text_layer'));
  assert.equal(pages[3].passages.length, 0);
});

test('a scanned PDF is classified unsupported and never claimed as processed', async () => {
  const pages = await extractFixture('scanned.pdf');
  assert.ok(pages.every((p) => p.page.status === 'empty'));
  const c = classifyDocument(pages.map((p) => ({ status: p.page.status })));
  assert.equal(c.supported, false);
  assert.match(c.message ?? '', /NOT processed/);
});

test('a normal text PDF with one empty page is supported with a message', async () => {
  const pages = await extractFixture('source.pdf');
  const c = classifyDocument(pages.map((p) => ({ status: p.page.status })));
  assert.equal(c.supported, true);
  assert.match(c.message ?? '', /1 page/);
});

test('handout.pdf: headings and short passages', async () => {
  const [p] = await extractFixture('handout.pdf');
  const texts = p.passages.map((x) => x.text);
  assert.equal(texts[0], 'Lecture 5: Aspirin');
  assert.ok(texts.includes('Mechanism'));
  assert.ok(texts.includes('Dose'));
  assert.ok(texts.some((t) => t.includes('Antiplatelet dose: 75 mg once daily.')));
  assert.equal(p.page.printed_label, '1');
});

test('ligature code points are mapped only for display text', () => {
  assert.equal(mapLigatures('eﬀect ﬁrst'), 'effect first');
  assert.equal(mapLigatures('µg and ℃'), 'µg and ℃'); // units untouched
});
