// Browser-side session handling (public/app/api.js) with a fake fetch and fake localStorage.
// These are unit tests of OUR client logic against a scripted server. They do not talk to Supabase.
import { beforeEach, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

type Call = { url: string; method: string; headers: Record<string, string>; body: any };
let calls: Call[] = [];
let handler: (c: Call) => { status: number; json?: any } | 'network-error';
let store: Map<string, string>;
let n = 0;

const CFG = { supabaseUrl: 'https://proj.supabase.co', supabaseAnonKey: 'ANON-KEY', supabaseConfigured: true, aiConfigured: false };
const tokenBody = (tag: string, expiresIn = 3600) => ({ access_token: `access-${tag}`, refresh_token: `refresh-${tag}`, expires_in: expiresIn, user: { id: 'user-1', email: 'a@example.com' } });

async function freshApi(cfg: any = CFG) {
  calls = [];
  store = new Map();
  (globalThis as any).localStorage = { getItem: (k: string) => store.get(k) ?? null, setItem: (k: string, v: string) => void store.set(k, v), removeItem: (k: string) => void store.delete(k) };
  (globalThis as any).fetch = async (url: string, init: any = {}) => {
    if (url === '/api/config') return { ok: true, status: 200, json: async () => cfg };
    const c: Call = { url, method: init.method ?? 'GET', headers: init.headers ?? {}, body: typeof init.body === 'string' ? JSON.parse(init.body) : init.body };
    calls.push(c);
    const r = handler(c);
    if (r === 'network-error') throw new TypeError('fetch failed');
    return { ok: r.status >= 200 && r.status < 300, status: r.status, json: async () => r.json ?? {}, text: async () => (r.json === undefined ? '' : JSON.stringify(r.json)), arrayBuffer: async () => new TextEncoder().encode('%PDF-bytes').buffer };
  };
  // A data: URL gives a brand-new module instance every time (api.js keeps state in module variables).
  const src = readFileSync(join(__dirname, '../public/app/api.js'), 'utf8') + `\n// instance ${++n}`;
  return (await import('data:text/javascript;base64,' + Buffer.from(src).toString('base64'))) as any;
}
const sessionOnDisk = () => store.get('aisph.session.v1');
const seed = (over: any = {}) => store.set('aisph.session.v1', JSON.stringify({ access_token: 'access-old', refresh_token: 'refresh-old', expires_at: Math.floor(Date.now() / 1000) + 3000, user: { id: 'user-1', email: 'a@example.com' }, ...over }));

beforeEach(() => { handler = () => ({ status: 200, json: {} }); });

describe('not connected (no Supabase credentials on the server)', () => {
  it('sign-in refuses with a clear code and makes NO call to Supabase', async () => {
    const api = await freshApi({ supabaseUrl: null, supabaseAnonKey: null, supabaseConfigured: false, aiConfigured: false });
    await assert.rejects(api.sendCode('a@example.com'), (e: any) => e.code === 'supabase_not_configured');
    assert.equal(calls.length, 0);
    assert.equal(api.currentUser(), null);
  });
});

describe('registration / login with an email code', () => {
  it('sendCode asks Supabase to email a code (creating the account if new), using only the public anon key', async () => {
    const api = await freshApi();
    await api.sendCode('a@example.com');
    assert.equal(calls.length, 1);
    assert.equal(calls[0].url, 'https://proj.supabase.co/auth/v1/otp');
    assert.deepEqual(calls[0].body, { email: 'a@example.com', create_user: true });
    assert.equal(calls[0].headers.apikey, 'ANON-KEY');
  });

  it('a wrong code is an error and creates no session', async () => {
    const api = await freshApi();
    handler = () => ({ status: 403, json: { msg: 'Token has expired or is invalid' } });
    await assert.rejects(api.verifyCode('a@example.com', '000000'), /expired or is invalid/);
    assert.equal(api.currentUser(), null);
    assert.equal(sessionOnDisk(), undefined);
  });

  it('a correct code stores the session and the user', async () => {
    const api = await freshApi();
    handler = () => ({ status: 200, json: tokenBody('1') });
    const user = await api.verifyCode('a@example.com', ' 123456 ');
    assert.deepEqual(user, { id: 'user-1', email: 'a@example.com' });
    assert.equal(calls[0].body.token, '123456', 'code is trimmed');
    assert.ok(sessionOnDisk());
  });
});

describe('data requests are made as the user, never with the anon key as identity', () => {
  it('REST calls carry the user\'s access token; anon key only as apikey', async () => {
    const api = await freshApi();
    seed();
    handler = () => ({ status: 200, json: [] });
    await api.db.get('documents?select=id');
    const c = calls[0];
    assert.equal(c.url, 'https://proj.supabase.co/rest/v1/documents?select=id');
    assert.equal(c.headers.Authorization, 'Bearer access-old');
    assert.equal(c.headers.apikey, 'ANON-KEY');
    assert.notEqual(c.headers.Authorization, 'Bearer ANON-KEY');
  });

  it('with no session, a data request fails with not_signed_in and sends nothing', async () => {
    const api = await freshApi();
    await assert.rejects(api.db.get('documents'), (e: any) => e.code === 'not_signed_in');
    assert.equal(calls.length, 0);
  });

  it('a database refusal is reported as an error, not as success', async () => {
    const api = await freshApi();
    seed();
    handler = () => ({ status: 403, json: { message: 'new row violates row-level security policy' } });
    await assert.rejects(api.db.insert('documents', { kind: 'source' }), /row-level security/);
  });
});

describe('session restoration and refresh', () => {
  it('no saved session -> restoreSession returns null', async () => {
    const api = await freshApi();
    assert.equal(await api.restoreSession(), null);
    assert.equal(calls.length, 0);
  });

  it('a still-valid session is restored without any network call', async () => {
    const api = await freshApi();
    seed();
    assert.deepEqual(await api.restoreSession(), { id: 'user-1', email: 'a@example.com' });
    assert.equal(calls.length, 0);
  });

  it('an expired access token is refreshed with the refresh token and the new token is used', async () => {
    const api = await freshApi();
    seed({ expires_at: Math.floor(Date.now() / 1000) - 10 });
    handler = (c) => (c.url.includes('/auth/v1/token') ? { status: 200, json: tokenBody('new') } : { status: 200, json: [] });
    await api.db.get('documents');
    assert.match(calls[0].url, /auth\/v1\/token\?grant_type=refresh_token/);
    assert.deepEqual(calls[0].body, { refresh_token: 'refresh-old' });
    assert.equal(calls[1].headers.Authorization, 'Bearer access-new');
    assert.match(sessionOnDisk()!, /refresh-new/);
  });

  it('a revoked/expired refresh token signs the user out locally (restoreSession -> null, storage cleared)', async () => {
    const api = await freshApi();
    seed({ expires_at: 1 });
    handler = () => ({ status: 400, json: { error_description: 'Invalid Refresh Token' } });
    assert.equal(await api.restoreSession(), null);
    assert.equal(sessionOnDisk(), undefined);
    assert.equal(api.currentUser(), null);
  });

  it('offline at start-up keeps the saved session (a network failure must not sign the student out)', async () => {
    const api = await freshApi();
    seed({ expires_at: 1 });
    handler = () => 'network-error';
    assert.deepEqual(await api.restoreSession(), { id: 'user-1', email: 'a@example.com' });
    assert.ok(sessionOnDisk(), 'session still saved');
    await assert.rejects(api.db.get('documents'), (e: any) => e.code !== 'not_signed_in' && /Could not reach/.test(e.message));
    assert.ok(sessionOnDisk(), 'still saved after a failed request');
  });

  it('a server error (5xx) while refreshing also keeps the session', async () => {
    const api = await freshApi();
    seed({ expires_at: 1 });
    handler = () => ({ status: 503, json: { message: 'unavailable' } });
    assert.ok(await api.restoreSession());
    assert.ok(sessionOnDisk());
  });
});

describe('sign-out', () => {
  it('clears the session immediately, calls the server logout with the user token, and later requests send nothing', async () => {
    const api = await freshApi();
    seed();
    await api.loadConfig();
    api.signOut();
    assert.equal(sessionOnDisk(), undefined);
    assert.equal(api.currentUser(), null);
    await new Promise((r) => setTimeout(r, 10));
    const logout = calls.find((c) => c.url.endsWith('/auth/v1/logout'));
    assert.ok(logout, 'server logout was called');
    assert.equal(logout!.headers.Authorization, 'Bearer access-old');
    const before = calls.length;
    await assert.rejects(api.db.get('documents'), (e: any) => e.code === 'not_signed_in');
    assert.equal(calls.length, before);
  });

  it('is still signed out locally when the server cannot be reached', async () => {
    const api = await freshApi();
    seed();
    await api.loadConfig();
    handler = () => 'network-error';
    assert.doesNotThrow(() => api.signOut());
    await new Promise((r) => setTimeout(r, 10));
    assert.equal(api.currentUser(), null);
    assert.equal(sessionOnDisk(), undefined);
  });
});

describe('profile / role (read-only on the client)', () => {
  it('loadProfile returns the row and exposes the role; there is no client function that sets a role', async () => {
    const api = await freshApi();
    seed();
    handler = () => ({ status: 200, json: [{ id: 'user-1', email: 'a@example.com', display_name: null, role: 'student' }] });
    const p = await api.loadProfile();
    assert.equal(p.role, 'student');
    assert.equal(api.isAdminProfile(p), false);
    assert.equal(api.isAdminProfile({ role: 'admin' }), true);
    assert.equal(calls[0].url, 'https://proj.supabase.co/rest/v1/profiles?id=eq.user-1&select=id,email,display_name,role');
    assert.equal(Object.keys(api).filter((k) => /role|admin|promote/i.test(k)).join(','), 'isAdminProfile');
  });

  it('a missing profiles table (migration not applied) gives null, never a made-up role', async () => {
    const api = await freshApi();
    seed();
    handler = () => ({ status: 404, json: { message: 'relation "public.profiles" does not exist' } });
    assert.equal(await api.loadProfile(), null);
  });
});

describe('private storage access from the client', () => {
  it('upload goes to the private documents bucket as the user, as application/pdf, and a refusal is an error', async () => {
    const api = await freshApi();
    seed();
    handler = () => ({ status: 200, json: { Key: 'ok' } });
    await api.uploadFile('user-1/doc.pdf', { type: '' , size: 5 });
    assert.equal(calls[0].url, 'https://proj.supabase.co/storage/v1/object/documents/user-1/doc.pdf');
    assert.equal(calls[0].headers['Content-Type'], 'application/pdf');
    assert.equal(calls[0].headers.Authorization, 'Bearer access-old');
    handler = () => ({ status: 403, json: { message: 'new row violates row-level security policy' } });
    await assert.rejects(api.uploadFile('someone-else/doc.pdf', { type: 'application/pdf' }), /Upload failed.*row-level security/);
  });

  it('download uses the authenticated (not the public) endpoint; a 403/404 is an error, not an empty file', async () => {
    const api = await freshApi();
    seed();
    const bytes = await api.downloadFile('user-1/doc.pdf');
    assert.equal(calls[0].url, 'https://proj.supabase.co/storage/v1/object/authenticated/documents/user-1/doc.pdf');
    assert.ok(bytes.length > 0);
    handler = () => ({ status: 404 });
    await assert.rejects(api.downloadFile('user-2/doc.pdf'), /HTTP 404/);
  });
});
