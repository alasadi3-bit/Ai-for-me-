// End-to-end test of the real browser app (Chromium) against tests/e2e/fake-backend.ts.
// Run:  npm run build && npm run test:e2e
// Needs Playwright with a Chromium browser (set PLAYWRIGHT_PATH if it is installed globally).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { readFileSync, writeFileSync } from 'node:fs';
import { startBackend } from './fake-backend';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const { chromium } = require(process.env.PLAYWRIGHT_PATH || 'playwright');
const FIX = path.join(__dirname, '..', 'fixtures');

type Backend = Awaited<ReturnType<typeof startBackend>>;
let be: Backend;
let browser: any;
const consoleProblems: string[] = [];

before(async () => {
  be = await startBackend();
  browser = await chromium.launch();
});
after(async () => {
  await browser?.close();
  await be?.close();
});

async function newPage(viewport = { width: 1180, height: 820 }) {
  const ctx = await browser.newContext({ viewport, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', (e: Error) => consoleProblems.push(`pageerror: ${e.message}`));
  page.on('console', (m: any) => {
    if (m.type() === 'error') consoleProblems.push(`console.error: ${m.text()}`);
  });
  return { ctx, page };
}

async function signIn(page: any, email = 'student@example.com') {
  await page.goto(be.origin + '/');
  await page.getByLabel('Email address').fill(email);
  await page.getByRole('button', { name: 'Send code' }).click();
  await page.getByLabel('Sign-in code').fill('123456');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByRole('heading', { name: 'Library' }).waitFor();
}

async function upload(page: any, kind: 'source' | 'handout', file: string, title: string, mime = 'application/pdf') {
  const label = kind === 'source' ? 'Primary source' : 'Lecture handout';
  const f = typeof file === 'string' && file.includes('/') ? file : path.join(FIX, file);
  await page.getByLabel(`${label} PDF file`).setInputFiles(f);
  await page.getByLabel(`${label} title`).fill(title);
  await page.getByRole('button', { name: `Upload ${label.toLowerCase()}` }).click();
}
const row = (page: any, title: string) => page.locator('.docrow', { hasText: title });

// ------------------------------------------------------------------ tests
test('server not configured: honest setup screen, nothing pretends to work', async () => {
  be.control.supabaseConfigured = false;
  const { ctx, page } = await newPage();
  await page.goto(be.origin + '/');
  await page.getByText('The server is not configured yet.').waitFor();
  assert.equal(await page.getByLabel('Email address').count(), 0);
  await ctx.close();
  be.control.supabaseConfigured = true;
});

test('sign-in: a wrong code is rejected with a message', async () => {
  const { ctx, page } = await newPage();
  await page.goto(be.origin + '/');
  await page.getByLabel('Email address').fill('wrong@example.com');
  await page.getByRole('button', { name: 'Send code' }).click();
  await page.getByLabel('Sign-in code').fill('000000');
  await page.getByRole('button', { name: 'Sign in' }).click();
  await page.getByRole('alert').getByText(/invalid|expired/i).waitFor();
  await ctx.close();
});

let studyUrl = '';
let sourceDocId = '';
let handoutDocId = '';

test('upload + real in-browser extraction of a text PDF (source and handout) with page references', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);

  await upload(page, 'source', 'source.pdf', 'Pharmacology Textbook');
  await row(page, 'Pharmacology Textbook').locator('.badge', { hasText: /^Processed/ }).waitFor({ timeout: 30000 });
  await upload(page, 'handout', 'handout.pdf', 'Lecture 5 Handout');
  await row(page, 'Lecture 5 Handout').locator('.badge', { hasText: /^Processed/ }).waitFor({ timeout: 30000 });

  const docs = be.tables.documents;
  const src = docs.find((d) => d.title === 'Pharmacology Textbook')!;
  const hnd = docs.find((d) => d.title === 'Lecture 5 Handout')!;
  sourceDocId = src.id;
  handoutDocId = hnd.id;
  assert.equal(src.status, 'processed');
  assert.equal(src.pages_total, 4);
  assert.equal(src.pages_done, 4);
  assert.match(src.status_message ?? '', /1 page\(s\) have no readable text/);
  assert.equal(hnd.pages_total, 1);

  // the original file really is in private storage, under the user's own folder
  assert.ok(be.storage.has(src.storage_path));
  assert.equal(src.storage_path.split('/')[0], src.owner);
  assert.equal(be.storage.get(src.storage_path)!.subarray(0, 5).toString(), '%PDF-');

  // physical page numbers, detected printed labels, and the empty page flagged (not invented)
  const pages = be.tables.document_pages.filter((p) => p.document_id === src.id).sort((a, b) => a.page_index - b.page_index);
  assert.deepEqual(pages.map((p) => p.page_index), [1, 2, 3, 4]);
  assert.deepEqual(pages.map((p) => p.printed_label), ['43', '44', '45', null]);
  assert.equal(pages[3].status, 'empty');
  assert.ok(pages[3].flags.includes('no_text_layer'));
  assert.equal(be.tables.passages.filter((p) => p.document_id === src.id && p.page_index === 4).length, 0);

  // sentence units rebuild each passage exactly
  for (const p of be.tables.passages.filter((x) => x.document_id === src.id || x.document_id === hnd.id)) {
    const rebuilt = be.tables.units.filter((u) => u.passage_id === p.id).sort((a, b) => a.idx - b.idx).map((u) => u.text).join(' ');
    assert.equal(rebuilt, p.text, `units must rebuild passage ${p.id}`);
  }
  // raw extracted text is preserved separately from the display text
  const hy = be.tables.passages.find((p) => p.document_id === src.id && p.flags.includes('dehyphenated'))!;
  assert.match(hy.raw_text, /-\n/);
  await ctx.close();
});

test('unsupported inputs are refused or marked, never claimed as processed', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  const before = be.tables.documents.length;

  // a scanned PDF: stored, but marked Not supported with no invented text
  await upload(page, 'source', 'scanned.pdf', 'Scanned Notes');
  await row(page, 'Scanned Notes').locator('.badge', { hasText: 'Not supported' }).waitFor({ timeout: 30000 });
  const scanned = be.tables.documents.find((d) => d.title === 'Scanned Notes')!;
  assert.equal(scanned.status, 'unsupported');
  assert.match(scanned.status_message, /scanned or image-based/i);
  assert.equal(be.tables.passages.filter((p) => p.document_id === scanned.id).length, 0);
  assert.equal(await row(page, 'Scanned Notes').getByRole('button', { name: /Process|Resume|Retry/ }).count(), 0);

  // a PowerPoint-like file is refused before upload
  const fake = '/tmp/claude-0/fake-deck.pdf';
  writeFileSync(fake, Buffer.from([0x50, 0x4b, 3, 4, 0, 0, 0, 0]));
  const storageBefore = be.storage.size;
  await upload(page, 'handout', fake, 'Slides');
  await page.getByRole('alert').getByText(/Slide decks are not supported/).waitFor();
  assert.equal(be.storage.size, storageBefore);
  assert.equal(be.tables.documents.length, before + 1); // only the scanned PDF row was added
  await ctx.close();
});

test('a failed save is shown as Failed with a Retry that resumes without duplicating', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  be.control.failTable = 'passages';
  await upload(page, 'handout', 'handout.pdf', 'Flaky Handout');
  await row(page, 'Flaky Handout').locator('.badge', { hasText: 'Failed' }).waitFor({ timeout: 30000 });
  await row(page, 'Flaky Handout').getByText(/Could not save page 1/).waitFor();
  be.control.failTable = '';
  await row(page, 'Flaky Handout').getByRole('button', { name: 'Retry' }).click();
  await row(page, 'Flaky Handout').locator('.badge', { hasText: /^Processed/ }).waitFor({ timeout: 30000 });
  const d = be.tables.documents.find((x) => x.title === 'Flaky Handout')!;
  assert.equal(be.tables.passages.filter((p) => p.document_id === d.id).length, 5); // same as handout.pdf, no duplicates
  assert.equal(be.tables.document_pages.filter((p) => p.document_id === d.id).length, 1);
  await ctx.close();
});

test('pre-lesson: three sections in order, grounded vs general, invented references removed', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.getByLabel('Lecture handout', { exact: true }).selectOption({ label: 'Lecture 5 Handout' });
  await page.getByLabel('Primary source', { exact: true }).selectOption({ label: 'Pharmacology Textbook' });
  await page.getByRole('button', { name: 'Prepare lesson' }).click();
  await page.getByRole('heading', { name: '3. Teaching Plan' }).waitFor({ timeout: 30000 });

  const headings = await page.locator('main h2').allTextContents();
  assert.deepEqual(headings.slice(0, 3), ['1. Mental Preparation', '2. Prerequisite Concepts', '3. Teaching Plan']);

  const mental = page.locator('[data-section=mental_preparation]');
  assert.ok((await mental.getByText('From your documents', { exact: true }).count()) >= 1);
  assert.match(await mental.getByText('Handout PDF page 1').first().textContent() ?? '', /Handout PDF page 1/);
  // the item citing a non-existent source S99 must have been downgraded to general
  const invented = mental.locator('.preitem', { hasText: 'Invented source' });
  await invented.getByText('General background (not from your documents)').waitFor();
  assert.equal(await invented.getByText('From your documents', { exact: true }).count(), 0);
  await invented.getByText(/did not exist and was removed|without a valid reference/).first().waitFor();
  // the model-written prerequisite is general background
  await page.locator('[data-section=prerequisites]').getByText('General background (not from your documents)').waitFor();
  // handout scope not covered by the plan is listed, not hidden
  await page.getByRole('heading', { name: 'Handout passages the Teaching Plan did not cover' }).waitFor();

  // saved + reused (no second model call)
  const calls = be.log.aiCalls;
  assert.equal(be.tables.prelessons.length, 1);
  await page.reload();
  await page.getByRole('heading', { name: '3. Teaching Plan' }).waitFor({ timeout: 30000 });
  await page.getByText('Showing the pre-lesson saved earlier').waitFor();
  assert.equal(be.log.aiCalls, calls);

  await page.getByRole('button', { name: 'Start Studying' }).click();
  await page.locator('.clock').waitFor();
  studyUrl = page.url();
  await ctx.close();
});

test('pre-lesson with AI failing shows the error and still lets you study', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  be.tables.prelessons.length = 0;
  be.control.aiMode = 'fail';
  await page.getByRole('button', { name: 'Prepare lesson' }).click();
  await page.getByRole('alert').getByText(/AI service returned an error|overload/i).waitFor({ timeout: 30000 });
  await page.getByRole('button', { name: 'Start studying anyway (no pre-lesson)' }).waitFor();
  assert.equal(be.tables.prelessons.length, 0);
  be.control.aiMode = 'good';
  await ctx.close();
});

test('study screen (landscape): timer on top, two panels side by side, English with Arabic directly underneath', async () => {
  const { ctx, page } = await newPage({ width: 1180, height: 820 });
  await signIn(page);
  await page.goto(studyUrl);
  await page.locator('.clock').waitFor();

  // timer bar is first and has Start / Pause / Reset
  const first = await page.locator('#app > *').first().evaluate((el: Element) => el.className);
  assert.equal(first, 'timerbar');
  for (const n of ['Start', 'Pause', 'Reset']) assert.equal(await page.locator('.timerbar').getByRole('button', { name: n, exact: true }).count(), 1);
  assert.equal(await page.locator('.clock').textContent(), '00:00');

  // both panels visible, left = source, right = handout
  const src = await page.locator('[data-panel=source]').boundingBox();
  const hnd = await page.locator('[data-panel=handout]').boundingBox();
  assert.ok(src && hnd && src.x < hnd.x && src.y === hnd.y && src.width > 300 && hnd.width > 300, 'panels side by side');
  assert.equal(await page.locator('.tabs').isVisible(), false);

  // honest matching banner
  await page.getByText('Automatic matching: not implemented.').waitFor();

  // first handout passage: heading, English then Arabic directly after
  await page.locator('[data-panel=handout] .unit .ar').first().waitFor({ timeout: 30000 });
  const unit = page.locator('[data-panel=handout] .unit').first();
  assert.equal(await unit.locator('.en').textContent(), 'Lecture 5: Aspirin');
  assert.equal(await unit.locator('.en + .ar').textContent(), 'ترجمة حرفية: Lecture 5: Aspirin');
  assert.equal(await unit.locator('.ar').first().getAttribute('dir'), 'rtl');
  assert.equal(await unit.locator('.en').getAttribute('lang'), 'en');
  await page.getByText('Arabic: machine translation, not reviewed').first().waitFor();
  await page.getByText('Passage 1 of 5').waitFor();
  await page.getByText(/Handout PDF page 1 \(printed 1, unverified\)/).waitFor();

  // paragraph passage with two sentences: each sentence followed by its own Arabic, in order
  await page.getByRole('button', { name: 'Next passage' }).click();
  await page.getByRole('button', { name: 'Next passage' }).click();
  await page.getByText('Passage 3 of 5').waitFor();
  await page.locator('[data-panel=handout] .unit .ar:not(.machine)').nth(1).waitFor({ timeout: 30000 });
  const ens = await page.locator('[data-panel=handout] .unit .en').allTextContents();
  const ars = await page.locator('[data-panel=handout] .unit .en + .ar').allTextContents();
  assert.deepEqual(ens, ['Aspirin irreversibly inhibits cyclooxygenase (COX).', 'Platelets cannot make new enzyme.']);
  assert.deepEqual(ars, ens.map((e) => `ترجمة حرفية: ${e}`));

  // the database holds exactly one machine translation per unit, original English untouched
  const units = be.tables.units.filter((u) => u.document_id === handoutDocId);
  const translated = be.tables.translations.filter((t) => units.some((u) => u.id === t.unit_id));
  assert.equal(new Set(translated.map((t) => t.unit_id)).size, translated.length);
  await ctx.close();
});

test('a dropped number in the Arabic is flagged, and the translation text is left as returned', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.goto(studyUrl);
  be.control.aiMode = 'drop-number';
  await page.getByRole('button', { name: 'Next passage' }).click(); // 2
  await page.getByRole('button', { name: 'Next passage' }).click(); // 3
  await page.getByRole('button', { name: 'Next passage' }).click(); // 4 heading "Dose"
  await page.getByRole('button', { name: 'Next passage' }).click(); // 5 "Antiplatelet dose: 75 mg once daily."
  await page.getByText('Passage 5 of 5').waitFor();
  await page.locator('[data-panel=handout] .unit .ar').first().waitFor({ timeout: 30000 });
  await page.locator('[data-panel=handout]').getByText(/A number in the English is missing from the Arabic/).waitFor();
  assert.equal(await page.locator('[data-panel=handout] .unit .ar').first().textContent(), 'الجرعة المضادة للصفيحات مرة واحدة يوميا');
  be.control.aiMode = 'good';
  await ctx.close();
});

test('a correction is saved separately; the machine output and English are kept', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.goto(studyUrl);
  await page.getByRole('button', { name: 'Next passage' }).click(); // 2: heading "Mechanism"
  await page.locator('[data-panel=handout] .unit .ar').first().waitFor({ timeout: 30000 });
  const before = be.tables.translations.length;
  await page.getByRole('button', { name: 'Edit translation' }).first().click();
  await page.getByLabel('Edit the Arabic translation').fill('الآلية (تصحيح)');
  await page.getByRole('button', { name: 'Save correction' }).click();
  await page.getByText('Edited by you').waitFor();
  assert.equal(await page.locator('[data-panel=handout] .unit .ar:not(.machine)').first().textContent(), 'الآلية (تصحيح)');
  assert.equal(be.tables.translation_edits.length, 1);
  assert.equal(be.tables.translations.length, before); // no machine row rewritten or added
  assert.equal(be.tables.translations.find((t) => t.id === be.tables.translation_edits[0].translation_id)!.machine_text, 'ترجمة حرفية: Mechanism');
  await page.getByRole('button', { name: 'Show original machine output' }).click();
  await page.getByText('ترجمة حرفية: Mechanism').waitFor();
  await ctx.close();
});

test('an omitted sentence and an AI outage are shown as "Translation missing", never as translated', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.goto(studyUrl);
  // Browse source page 1 so source passages (not yet translated) load
  await page.getByRole('button', { name: 'Browse source pages' }).first().click();
  be.control.aiMode = 'omit';
  await page.getByText('Common adverse effects include').waitFor();
  await page.locator('[data-panel=source] .ar-missing').first().waitFor({ timeout: 30000 });
  const missing = await page.locator('[data-panel=source] .ar-missing').allTextContents();
  assert.ok(missing.some((t) => /Translation missing/.test(t) && /not shown as translated/.test(t)));
  // the other sentences of that passage were translated
  assert.ok((await page.locator('[data-panel=source] .unit .en + .ar').count()) >= 1);

  // outage on a passage that has no translations yet
  be.control.aiMode = 'fail';
  await page.getByRole('button', { name: 'Next page' }).first().click();
  await page.getByText('The antiplatelet dose is 75 mg once daily.').waitFor();
  await page.locator('[data-panel=source]').getByText(/Translation missing/).first().waitFor({ timeout: 30000 });
  assert.equal(await page.locator('[data-panel=source] .unit .en + .ar').count(), 0);

  // recovery: Retry translation works once the model is back
  be.control.aiMode = 'good';
  await page.locator('[data-panel=source]').getByRole('button', { name: 'Retry translation' }).first().click();
  await page.locator('[data-panel=source] .unit .en + .ar').first().waitFor({ timeout: 30000 });
  await ctx.close();
});

test('manual links: Not linked -> Manual link -> removed; no automatic labels anywhere', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.goto(studyUrl);
  await page.getByRole('button', { name: 'Next passage' }).click();
  await page.getByRole('button', { name: 'Next passage' }).click(); // passage 3
  await page.locator('[data-panel=handout] .panel-head').getByText('Not linked').waitFor();
  await page.locator('[data-panel=source]').getByText('Not linked.').waitFor();

  await page.getByRole('button', { name: 'Browse source pages' }).first().click();
  await page.locator('[data-panel=source] .passage', { hasText: 'Aspirin irreversibly inhibits cyclooxygenase, an enzyme' }).getByRole('button', { name: 'Link to this handout passage' }).click();
  await page.locator('[data-panel=handout] .panel-head').getByText('Manual link').waitFor();
  assert.equal(be.tables.links.length, 1);
  assert.equal(be.tables.links[0].method, 'manual');
  assert.equal(be.tables.links[0].status, 'manual');

  await page.getByRole('button', { name: /Linked passages \(1\)/ }).click();
  await page.locator('[data-panel=source] .linked').getByText('Manual link').waitFor();
  await page.locator('[data-panel=source]').getByText(/Source PDF page 1/).first().waitFor();

  const body = (await page.locator('body').innerText()).toLowerCase();
  assert.ok(!/auto[- ]?(verified|matched|confirmed)|matching complete/.test(body), 'no automatic-matching claims');

  // the link survives a reload
  await page.reload();
  await page.locator('[data-panel=handout] .panel-head').getByText('Not linked').or(page.locator('[data-panel=handout] .panel-head').getByText('Manual link')).first().waitFor();

  await page.getByRole('button', { name: 'Next passage' }).click();
  await page.getByRole('button', { name: 'Previous passage' }).click();
  await page.locator('[data-panel=source] .linked').getByRole('button', { name: 'Remove link' }).click();
  await page.locator('[data-panel=handout] .panel-head').getByText('Not linked').waitFor();
  assert.equal(be.tables.links.length, 0);
  await ctx.close();
});

test('"View original page" renders the real PDF page on a canvas', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.goto(studyUrl);
  await page.locator('[data-panel=handout]').getByRole('button', { name: 'View original page' }).first().click();
  const overlay = page.getByRole('dialog', { name: 'Original PDF page' });
  await overlay.getByText(/Lecture 5 Handout: PDF page 1 of 1/).waitFor();
  const dark = await page.waitForFunction(() => {
    const c = document.querySelector('.pdfcanvas') as HTMLCanvasElement | null;
    if (!c || c.width < 100) return false;
    const d = c.getContext('2d')!.getImageData(0, 0, c.width, c.height).data;
    let n = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i] < 100 && d[i + 3] > 0) n++;
    return n > 200 ? n : false; // text pixels present = something was really drawn
  }, null, { timeout: 30000 });
  assert.ok(await dark.jsonValue());
  await overlay.getByRole('button', { name: 'Close' }).click();
  assert.equal(await page.getByRole('dialog').count(), 0);
  await ctx.close();
});

test('timer: start/pause/reset, correct after a simulated 2-minute lock, restored after reload', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.goto(studyUrl);
  const clock = page.locator('.clock');
  await clock.waitFor();
  await page.locator('.timerbar').getByRole('button', { name: 'Reset', exact: true }).click();
  assert.equal(await clock.textContent(), '00:00');

  await page.locator('.timerbar').getByRole('button', { name: 'Start', exact: true }).click();
  await page.waitForFunction(() => document.querySelector('.clock')!.textContent !== '00:00', null, { timeout: 5000 });
  assert.equal(await page.getByRole('button', { name: 'Start', exact: true }).isDisabled(), true);

  // iPad locks for 2 minutes: no timers fire, the clock jumps; the next visibility event repaints from timestamps
  await page.evaluate(() => {
    const real = Date.now.bind(Date);
    Date.now = () => real() + 120_000;
    document.dispatchEvent(new Event('visibilitychange'));
  });
  await page.waitForFunction(() => /^0[2-9]:\d\d$/.test(document.querySelector('.clock')!.textContent!), null, { timeout: 5000 });

  await page.locator('.timerbar').getByRole('button', { name: 'Pause', exact: true }).click();
  const frozen = await clock.textContent();
  await page.waitForTimeout(1300);
  assert.equal(await clock.textContent(), frozen);
  await page.reload(); // Date.now patch is gone; paused time must persist
  await page.locator('.clock').waitFor();
  assert.equal(await page.locator('.clock').textContent(), frozen);
  assert.ok(be.tables.study_progress.length === 1);
  assert.ok(be.tables.study_progress[0].timer_accumulated_ms >= 120_000);

  await page.locator('.timerbar').getByRole('button', { name: 'Reset', exact: true }).click();
  assert.equal(await page.locator('.clock').textContent(), '00:00');
  await ctx.close();
});

test('study position is saved and restored', async () => {
  const { ctx, page } = await newPage();
  await signIn(page);
  await page.goto(studyUrl);
  await page.getByLabel('Go to passage number').fill('4');
  await page.getByLabel('Go to passage number').press('Enter');
  await page.getByText('Passage 4 of 5').waitFor();
  await page.waitForFunction(() => document.querySelector('.timerbar')!.textContent!.includes('Progress saved'), null, { timeout: 5000 });
  assert.equal(be.tables.study_progress[0].passage_index, 3);
  const { ctx: ctx2, page: page2 } = await newPage();
  await signIn(page2);
  await page2.goto(studyUrl);
  await page2.getByText('Passage 4 of 5').waitFor();
  await ctx.close();
  await ctx2.close();
});

test('portrait iPad: one panel at a time with a switch; landscape shows both', async () => {
  const { ctx, page } = await newPage({ width: 820, height: 1180 });
  await signIn(page);
  await page.goto(studyUrl);
  await page.locator('.clock').waitFor();
  assert.equal(await page.locator('.tabs').isVisible(), true);
  assert.equal(await page.locator('[data-panel=handout]').isVisible(), true);
  assert.equal(await page.locator('[data-panel=source]').isVisible(), false);
  await page.getByRole('button', { name: 'Primary Source' }).first().click();
  assert.equal(await page.locator('[data-panel=source]').isVisible(), true);
  assert.equal(await page.locator('[data-panel=handout]').isVisible(), false);
  // text stays readable: no horizontal page overflow
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 1);
  assert.equal(overflow, false);
  await ctx.close();
});

test('privacy: another account cannot see, read or download the first account’s data', async () => {
  const { ctx, page } = await newPage();
  await signIn(page, 'someone-else@example.com');
  await page.getByText('No documents yet.').waitFor();
  const other = be.tables.documents[0];
  const token = await page.evaluate(() => JSON.parse(localStorage.getItem('aisph.session.v1')!).access_token);
  const base = be.origin + '/fake-supabase';
  const docs = await (await fetch(`${base}/rest/v1/documents?select=id`, { headers: { apikey: 'test-anon-key', Authorization: `Bearer ${token}` } })).json();
  assert.deepEqual(docs, []);
  const dl = await fetch(`${base}/storage/v1/object/authenticated/documents/${other.storage_path}`, { headers: { apikey: 'test-anon-key', Authorization: `Bearer ${token}` } });
  assert.equal(dl.status, 403);
  await ctx.close();
});

test('the Anthropic key never reaches the browser', async () => {
  const { ctx, page } = await newPage();
  const seen: string[] = [];
  page.on('response', async (r: any) => { try { seen.push(await r.text()); } catch { /* binary */ } });
  await signIn(page);
  await page.goto(studyUrl);
  await page.locator('.clock').waitFor();
  await page.waitForTimeout(500);
  const local = await page.evaluate(() => JSON.stringify({ ...localStorage }));
  assert.ok(![...seen, local].some((t) => t.includes('sk-ant-test')), 'API key must not appear in any response or storage');
  const cfg = await (await fetch(be.origin + '/api/config')).json();
  assert.deepEqual(Object.keys(cfg).sort(), ['aiConfigured', 'supabaseAnonKey', 'supabaseConfigured', 'supabaseUrl']);
  await ctx.close();
});

test('no unexpected JavaScript errors occurred during the whole run', () => {
  // Expected, deliberately provoked failures produce failed-request console lines (4xx/5xx). Anything else is a bug.
  const unexpected = consoleProblems.filter((m) => !/Failed to load resource: the server responded with a status of (400|401|403|409|500|502|529)/.test(m));
  assert.deepEqual(unexpected, []);
});
