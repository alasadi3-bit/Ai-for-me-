// TEST-ONLY backend. It is NOT part of the app.
//
// It serves public/, emulates the parts of Supabase the app uses (email-code sign-in, PostgREST with
// per-user row access like Row Level Security, private storage), and runs the REAL server handlers
// (server/translate.ts, server/prelesson.ts) with a fake Anthropic model.
// What this proves: the app's own browser and server code works end to end.
// What it does NOT prove: that real Supabase or the real Anthropic API behave identically.
import http from 'node:http';
import { createHash, randomUUID } from 'node:crypto';
import { readFileSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { handleTranslate } from '../../server/translate';
import { handlePreLesson } from '../../server/prelesson';
import { publicConfig, bearerToken } from '../../server/http';

const ROOT = path.join(__dirname, '..', '..');
const PUBLIC = path.join(ROOT, 'public');
const ANON = 'test-anon-key';
const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png',
};

type Row = Record<string, any>;
const now = () => new Date().toISOString();
const DEFAULTS: Record<string, () => Row> = {
  documents: () => ({ status: 'uploaded', file_type: 'pdf', pages_done: 0, pages_total: null, status_message: null, created_at: now() }),
  document_pages: () => ({ raw_text: '', status: 'ok', flags: [], error: null, printed_label: null }),
  passages: () => ({ kind: 'paragraph', flags: [], heading_path: null }),
  units: () => ({ kind: 'sentence' }),
  translations: () => ({ flags: [], checks: {}, created_at: now() }),
  translation_edits: () => ({ created_at: now() }),
  links: () => ({ method: 'manual', status: 'manual', evidence: null, created_at: now() }),
  study_progress: () => ({ source_id: null, passage_index: 0, source_page: null, timer_accumulated_ms: 0, timer_started_at: null, updated_at: now() }),
  prelessons: () => ({ source_id: null, created_at: now() }),
  profiles: () => ({ role: 'student', display_name: null, created_at: now() }), // created at sign-up, like the real trigger
};
const UNIQUE: Record<string, string[][]> = {
  document_pages: [['document_id', 'page_index']],
  passages: [['document_id', 'page_index', 'seq']],
  units: [['passage_id', 'idx']],
  links: [['handout_passage_id', 'source_passage_id']],
  study_progress: [['owner', 'handout_id']],
};
const ENUMS: Record<string, Record<string, string[]>> = {
  documents: { kind: ['source', 'handout'], status: ['uploaded', 'processing', 'processed', 'failed', 'unsupported'] },
  document_pages: { status: ['ok', 'empty', 'failed'] },
  passages: { kind: ['heading', 'paragraph'] },
  units: { kind: ['sentence', 'fragment'] },
  links: { method: ['manual', 'auto'], status: ['manual', 'auto_verified', 'auto_uncertain', 'auto_confirmed', 'auto_rejected'] },
};
const NOT_NULL: Record<string, string[]> = {
  documents: ['kind', 'title', 'file_name', 'storage_path'],
  document_pages: ['document_id', 'page_index'],
  passages: ['document_id', 'page_index', 'seq', 'raw_text', 'text'],
  units: ['passage_id', 'document_id', 'idx', 'text'],
  translations: ['unit_id', 'machine_text', 'model', 'prompt_version'],
  translation_edits: ['translation_id', 'edited_text'],
  links: ['handout_passage_id', 'source_passage_id'],
  study_progress: ['handout_id'],
  prelessons: ['handout_id', 'content', 'model', 'prompt_version'],
};
const CASCADE: Record<string, [string, string][]> = {
  documents: [['document_pages', 'document_id'], ['passages', 'document_id'], ['units', 'document_id'], ['links', 'handout_passage_id']],
  passages: [['units', 'passage_id'], ['links', 'handout_passage_id'], ['links', 'source_passage_id']],
  units: [['translations', 'unit_id']],
  translations: [['translation_edits', 'translation_id']],
};

export type AiMode = 'good' | 'drop-number' | 'omit' | 'fail';

export async function startBackend(port = 0) {
  const tables: Record<string, Row[]> = {};
  for (const t of Object.keys(DEFAULTS)) tables[t] = [];
  const storage = new Map<string, Buffer>();
  const log: { aiCalls: number; translateRequests: number } = { aiCalls: 0, translateRequests: 0 };
  const control = { aiMode: 'good' as AiMode, aiConfigured: true, supabaseConfigured: true, failTable: '' as string };
  let origin = '';

  const userIdFor = (email: string) => {
    const h = createHash('sha1').update(email).digest('hex');
    return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-8${h.slice(17, 20)}-${h.slice(20, 32)}`;
  };
  const userFromReq = (req: http.IncomingMessage): string | null => {
    const tok = bearerToken(req.headers.authorization);
    return tok && tok.startsWith('tok.') ? tok.slice(4) : null;
  };

  function json(res: http.ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}) {
    res.writeHead(status, { 'Content-Type': 'application/json', ...headers });
    res.end(JSON.stringify(body));
  }
  const readBody = (req: http.IncomingMessage) =>
    new Promise<Buffer>((resolve) => {
      const chunks: Buffer[] = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => resolve(Buffer.concat(chunks)));
    });

  // -------------------------------------------------------------- PostgREST
  function matches(row: Row, params: URLSearchParams): boolean {
    for (const [k, v] of params) {
      if (['select', 'order', 'limit', 'offset', 'on_conflict'].includes(k)) continue;
      const val = row[k];
      if (v.startsWith('eq.')) { if (String(val) !== v.slice(3)) return false; }
      else if (v.startsWith('in.(')) { if (!v.slice(4, -1).split(',').includes(String(val))) return false; }
      else if (v === 'is.null') { if (val !== null && val !== undefined) return false; }
      else throw new Error(`fake PostgREST: unsupported filter ${k}=${v}`);
    }
    return true;
  }
  function validate(table: string, row: Row): string | null {
    for (const c of NOT_NULL[table] ?? []) if (row[c] === undefined || row[c] === null) return `null value in column "${c}" of relation "${table}" violates not-null constraint`;
    for (const [c, allowed] of Object.entries(ENUMS[table] ?? {})) if (!allowed.includes(row[c])) return `new row for relation "${table}" violates check constraint on "${c}" (${String(row[c])})`;
    return null;
  }
  const uniqueClash = (table: string, row: Row, ignore?: Row) =>
    (UNIQUE[table] ?? []).find((cols) => tables[table].some((r) => r !== ignore && cols.every((c) => String(r[c]) === String(row[c]))));

  function cascade(table: string, removed: Row[]) {
    for (const [child, col] of CASCADE[table] ?? []) {
      const ids = new Set(removed.map((r) => String(r.id)));
      const gone = tables[child].filter((r) => ids.has(String(r[col])));
      if (gone.length) { tables[child] = tables[child].filter((r) => !gone.includes(r)); cascade(child, gone); }
    }
  }

  async function rest(req: http.IncomingMessage, res: http.ServerResponse, url: URL, table: string) {
    if (req.headers.apikey !== ANON) return json(res, 401, { message: 'Invalid API key' });
    const uid = userFromReq(req);
    if (!uid) return json(res, 401, { message: 'JWT expired or missing' });
    if (!tables[table]) return json(res, 404, { message: `relation "${table}" does not exist` });
    if (control.failTable === table && req.method !== 'GET') return json(res, 500, { message: `simulated failure writing ${table}` });
    const prefer = String(req.headers.prefer ?? '');
    const mine = (r: Row) => r.owner === uid; // Row Level Security: owner = auth.uid()

    if (req.method === 'GET') {
      let rows = tables[table].filter((r) => mine(r) && matches(r, url.searchParams));
      const order = url.searchParams.get('order');
      if (order) {
        const keys = order.split(',').map((o) => { const [c, d] = o.split('.'); return { c, desc: d === 'desc' }; });
        rows = [...rows].sort((a, b) => {
          for (const { c, desc } of keys) { if (a[c] < b[c]) return desc ? 1 : -1; if (a[c] > b[c]) return desc ? -1 : 1; }
          return 0;
        });
      }
      const off = Number(url.searchParams.get('offset') ?? 0);
      const lim = Number(url.searchParams.get('limit') ?? 1000);
      return json(res, 200, rows.slice(off, off + lim));
    }
    if (req.method === 'POST') {
      const raw = JSON.parse((await readBody(req)).toString() || 'null');
      const list: Row[] = Array.isArray(raw) ? raw : [raw];
      const upsert = prefer.includes('resolution=merge-duplicates');
      const out: Row[] = [];
      const staged: Row[] = [];
      for (const input of list) {
        if (input.owner && input.owner !== uid) return json(res, 403, { message: 'new row violates row-level security policy' });
        const row: Row = { ...DEFAULTS[table](), ...(table === 'study_progress' ? {} : { id: randomUUID() }), ...input, owner: uid };
        const bad = validate(table, row);
        if (bad) return json(res, 400, { message: bad });
        const clash = uniqueClash(table, row, undefined) ?? undefined;
        const existing = clash ? tables[table].find((r) => clash.every((c) => String(r[c]) === String(row[c]))) : undefined;
        if (clash && !upsert) return json(res, 409, { message: `duplicate key value violates unique constraint on (${clash.join(',')})` });
        if (clash && upsert && existing) {
          if (!mine(existing)) return json(res, 403, { message: 'row-level security' });
          Object.assign(existing, input, { owner: uid });
          out.push(existing);
          continue;
        }
        if (staged.some((s) => (UNIQUE[table] ?? []).some((cols) => cols.every((c) => String(s[c]) === String(row[c]))))) return json(res, 409, { message: 'duplicate key within one request' });
        staged.push(row);
      }
      tables[table].push(...staged);
      out.push(...staged);
      return prefer.includes('return=representation') ? json(res, 201, out) : (res.writeHead(201), res.end());
    }
    if (req.method === 'PATCH') {
      const patch = JSON.parse((await readBody(req)).toString());
      for (const r of tables[table].filter((x) => mine(x) && matches(x, url.searchParams))) Object.assign(r, patch);
      return (res.writeHead(204), res.end());
    }
    if (req.method === 'DELETE') {
      const gone = tables[table].filter((r) => mine(r) && matches(r, url.searchParams));
      tables[table] = tables[table].filter((r) => !gone.includes(r));
      cascade(table, gone);
      return (res.writeHead(204), res.end());
    }
    return json(res, 405, { message: 'method not allowed' });
  }

  // ---------------------------------------------------------- fake Anthropic
  function fakeAnthropic(body: any) {
    log.aiCalls++;
    if (control.aiMode === 'fail') return new Response(JSON.stringify({ error: { message: 'simulated overload' } }), { status: 529 });
    const tool = body.tool_choice?.name;
    const text: string = body.messages[0].content;
    if (tool === 'submit_translations') {
      const units: { id: string; english: string }[] = JSON.parse(text.slice(text.indexOf('\n\n') + 2));
      const translations: { id: string; arabic: string }[] = [];
      for (const u of units) {
        if (control.aiMode === 'omit' && u.english.startsWith('Common adverse')) continue;
        if (control.aiMode === 'drop-number' && /75 mg/.test(u.english)) { translations.push({ id: u.id, arabic: 'الجرعة المضادة للصفيحات مرة واحدة يوميا' }); continue; }
        translations.push({ id: u.id, arabic: `ترجمة حرفية: ${u.english}` });
      }
      return new Response(JSON.stringify({ stop_reason: 'tool_use', content: [{ type: 'tool_use', name: tool, input: { translations } }] }), { status: 200 });
    }
    if (tool === 'submit_prelesson') {
      const handout = [...text.matchAll(/^(H\d+) \((heading|paragraph)[^)]*\): (.*)$/gm)].map((m) => ({ label: m[1], kind: m[2], text: m[3] }));
      const source = [...text.matchAll(/^(S\d+) \(source page (\d+)\)/gm)].map((m) => m[1]);
      const plan = handout.slice(0, Math.max(1, handout.length - 1)).map((h) => ({
        title: h.text.slice(0, 40), text: `Study: ${h.text.slice(0, 80)}`, basis: 'document', refs: [h.label, ...(source[0] ? [source[0]] : [])],
      }));
      const input = {
        mental_preparation: [
          { title: 'Platelets', text: 'Think about how platelets form clots.', basis: 'document', refs: [handout[0]?.label ?? 'H1'] },
          { title: 'Invented source', text: 'Claims a document source that does not exist.', basis: 'document', refs: ['S99'] },
        ],
        prerequisites: [{ title: 'Prostaglandins', text: 'Know what prostaglandins do.', basis: 'general', refs: [] }],
        teaching_plan: plan,
      };
      return new Response(JSON.stringify({ stop_reason: 'tool_use', content: [{ type: 'tool_use', name: tool, input }] }), { status: 200 });
    }
    return new Response(JSON.stringify({ error: { message: 'unknown tool' } }), { status: 400 });
  }
  const fetchImpl = async (url: string, init?: any) => {
    if (url.startsWith('https://api.anthropic.com/')) return fakeAnthropic(JSON.parse(init.body));
    return fetch(url, init);
  };

  // ------------------------------------------------------------------ server
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? '/', origin || 'http://localhost');
      const p = url.pathname;
      if (p === '/api/config') {
        const env = {
          SUPABASE_URL: control.supabaseConfigured ? `${origin}/fake-supabase` : '',
          SUPABASE_ANON_KEY: control.supabaseConfigured ? ANON : '',
          ANTHROPIC_API_KEY: control.aiConfigured ? 'sk-ant-test' : '',
        };
        const r = publicConfig(env);
        return json(res, r.status, r.json);
      }
      if (p === '/api/translate' || p === '/api/prelesson') {
        if (p === '/api/translate') log.translateRequests++;
        const body = JSON.parse((await readBody(req)).toString() || '{}');
        const env = { SUPABASE_URL: `${origin}/fake-supabase`, SUPABASE_ANON_KEY: ANON, ANTHROPIC_API_KEY: control.aiConfigured ? 'sk-ant-test' : '' };
        const handler = p === '/api/translate' ? handleTranslate : handlePreLesson;
        const r = await handler({ env, fetchImpl, token: bearerToken(req.headers.authorization), body });
        return json(res, r.status, r.json);
      }
      if (p === '/fake-supabase/auth/v1/otp') return json(res, 200, {});
      if (p === '/fake-supabase/auth/v1/verify') {
        const b = JSON.parse((await readBody(req)).toString());
        if (b.token !== '123456') return json(res, 400, { msg: 'Token has expired or is invalid' });
        const id = userIdFor(b.email);
        if (!tables.profiles.some((r) => r.id === id)) tables.profiles.push({ ...DEFAULTS.profiles(), id, owner: id, email: b.email });
        return json(res, 200, { access_token: `tok.${id}`, refresh_token: `ref.${id}`, expires_in: 3600, user: { id, email: b.email } });
      }
      if (p === '/fake-supabase/auth/v1/logout') { res.statusCode = 204; return void res.end(); }
      if (p === '/fake-supabase/auth/v1/token') {
        const b = JSON.parse((await readBody(req)).toString());
        const id = String(b.refresh_token).replace('ref.', '');
        return json(res, 200, { access_token: `tok.${id}`, refresh_token: `ref.${id}`, expires_in: 3600, user: { id, email: 'x' } });
      }
      let m = p.match(/^\/fake-supabase\/rest\/v1\/([a-z_]+)$/);
      if (m) return await rest(req, res, url, m[1]);
      m = p.match(/^\/fake-supabase\/storage\/v1\/object\/(?:authenticated\/)?documents\/(.+)$/);
      if (m) {
        const uid = userFromReq(req);
        if (!uid) return json(res, 401, { message: 'unauthorized' });
        const key = decodeURIComponent(m[1]);
        if (key.split('/')[0] !== uid) return json(res, 403, { message: 'new row violates row-level security policy' });
        if (req.method === 'POST') { storage.set(key, await readBody(req)); return json(res, 200, { Key: key }); }
        if (req.method === 'GET') {
          const data = storage.get(key);
          if (!data) return json(res, 404, { message: 'Object not found' });
          res.writeHead(200, { 'Content-Type': 'application/pdf' });
          return res.end(data);
        }
      }
      // static files
      let file = path.join(PUBLIC, p === '/' ? 'index.html' : p);
      if (!file.startsWith(PUBLIC) || !existsSync(file) || statSync(file).isDirectory()) {
        if (p.startsWith('/app/') || p.startsWith('/lib/') || p.startsWith('/vendor/') || p.includes('.')) { res.writeHead(404); return res.end('not found'); }
        file = path.join(PUBLIC, 'index.html');
      }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] ?? 'application/octet-stream', 'Cache-Control': 'no-store' });
      res.end(readFileSync(file));
    } catch (e: any) {
      json(res, 500, { message: `fake backend error: ${e?.message ?? e}` });
    }
  });
  await new Promise<void>((r) => server.listen(port, '127.0.0.1', r));
  origin = `http://127.0.0.1:${(server.address() as any).port}`;
  return {
    origin, tables, storage, control, log,
    close: () => new Promise<void>((r) => server.close(() => r())),
  };
}
