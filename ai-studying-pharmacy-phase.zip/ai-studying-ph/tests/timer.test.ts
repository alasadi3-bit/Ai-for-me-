import test from 'node:test';
import assert from 'node:assert/strict';
import { initialTimer, start, pause, reset, elapsedMs, isRunning, formatElapsed, serialize, parse, pickNewer } from '../src/lib/timer';

test('start, run, pause, resume, reset', () => {
  let t = initialTimer;
  assert.equal(elapsedMs(t, 1_000), 0);
  t = start(t, 1_000);
  assert.ok(isRunning(t));
  assert.equal(elapsedMs(t, 61_000), 60_000);
  t = pause(t, 61_000);
  assert.ok(!isRunning(t));
  assert.equal(elapsedMs(t, 500_000), 60_000); // paused: does not advance
  t = start(t, 600_000);
  assert.equal(elapsedMs(t, 630_000), 90_000);
  t = reset();
  assert.equal(elapsedMs(t, 700_000), 0);
  assert.ok(!isRunning(t));
});

test('screen lock: elapsed time counts the whole locked period, with no ticks in between', () => {
  const t = start(initialTimer, 0);
  // iPad locked for 2 minutes; no interval ever fired; first read after unlock
  assert.equal(elapsedMs(t, 120_000), 120_000);
});

test('starting twice does not restart the run', () => {
  const a = start(initialTimer, 1_000);
  const b = start(a, 5_000);
  assert.equal(b.startedAt, 1_000);
});

test('persisted state survives serialize and parse, including a running timer', () => {
  const t = start({ accumulatedMs: 30_000, startedAt: null }, 10_000);
  const back = parse(serialize(t));
  assert.deepEqual(back, t);
  assert.equal(elapsedMs(back, 70_000), 90_000);
});

test('corrupt stored values fall back to a zero timer', () => {
  assert.deepEqual(parse('not json'), initialTimer);
  assert.deepEqual(parse(null), initialTimer);
  assert.deepEqual(parse('{"accumulatedMs":-5,"startedAt":null}'), initialTimer);
  assert.deepEqual(parse('{"accumulatedMs":"x","startedAt":null}'), initialTimer);
});

test('clock going backwards never gives negative time', () => {
  const t = start(initialTimer, 10_000);
  assert.equal(elapsedMs(t, 5_000), 0);
});

test('formatting', () => {
  assert.equal(formatElapsed(0), '00:00');
  assert.equal(formatElapsed(61_000), '01:01');
  assert.equal(formatElapsed(3_661_000), '1:01:01');
});

test('merging local and remote keeps the larger elapsed time', () => {
  const local = { accumulatedMs: 10_000, startedAt: null };
  const remote = { accumulatedMs: 50_000, startedAt: null };
  assert.deepEqual(pickNewer(local, remote, 0), remote);
  assert.deepEqual(pickNewer(remote, local, 0), remote);
});
