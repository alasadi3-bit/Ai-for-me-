import test from 'node:test';
import assert from 'node:assert/strict';
import {
  selectSourceContext, labelPassages, validatePreLesson, buildPreLessonRequest, parsePreLessonResponse,
  PRELESSON_TOOL, type PassageIn,
} from '../src/lib/prelesson';

const P = (id: string, page: number, text: string, kind: 'heading' | 'paragraph' = 'paragraph'): PassageIn => ({ id, page_index: page, kind, text });

const handout = [
  P('h-title', 1, 'Lecture 5: Aspirin', 'heading'),
  P('h-mech', 1, 'Aspirin irreversibly inhibits cyclooxygenase. Platelets cannot make new enzyme.'),
  P('h-dose', 1, 'Antiplatelet dose: 75 mg once daily.'),
];
const source = [
  P('s1', 57, 'Aspirin irreversibly inhibits cyclooxygenase, an enzyme needed for prostaglandin synthesis.'),
  P('s2', 57, 'Platelets lack a nucleus so the inhibition of platelet cyclooxygenase lasts for the life of the platelet.'),
  P('s3', 58, 'The antiplatelet dose is 75 mg once daily; analgesic doses are higher.'),
  P('s4', 90, 'Warfarin is a vitamin K antagonist used for anticoagulation.'),
];

test('keyword selection picks relevant source passages and not unrelated ones', () => {
  const ctx = selectSourceContext(handout, source, { perPassage: 2, minShared: 2 });
  const ids = ctx.map((p) => p.id);
  assert.ok(ids.includes('s1'));
  assert.ok(ids.includes('s3'));
  assert.ok(!ids.includes('s4'));
});

const H = labelPassages('H', handout);
const S = labelPassages('S', source);

test('valid grounded items keep their references (mapped to real passage ids)', () => {
  const c = validatePreLesson({
    mental_preparation: [{ title: 'Enzyme', text: 'Think of COX as a gatekeeper.', basis: 'document', refs: ['H2', 'S1'] }],
    prerequisites: [{ title: 'Prostaglandins', text: 'What prostaglandins do.', basis: 'general', refs: [] }],
    teaching_plan: [
      { title: 'Intro', text: 'Title', basis: 'document', refs: ['H1'] },
      { title: 'Mechanism', text: 'Explain COX inhibition', basis: 'document', refs: ['H2', 'S1', 'S2'] },
      { title: 'Dose', text: 'Dose', basis: 'document', refs: ['H3', 'S3'] },
    ],
  }, H, S);
  assert.deepEqual(c.mental_preparation[0].refs, ['h-mech', 's1']);
  assert.equal(c.mental_preparation[0].basis, 'document');
  assert.deepEqual(c.uncovered_handout_passage_ids, []);
});

test('invented references are removed and an unsupported "document" claim is downgraded to general', () => {
  const c = validatePreLesson({
    mental_preparation: [{ title: 'x', text: 'Claim with a fake source.', basis: 'document', refs: ['S99', 'H77'] }],
    prerequisites: [],
    teaching_plan: [],
  }, H, S);
  const it = c.mental_preparation[0];
  assert.equal(it.basis, 'general');
  assert.deepEqual(it.refs, []);
  assert.ok(it.flags.includes('invalid_reference_removed'));
  assert.ok(it.flags.includes('no_valid_reference_downgraded'));
});

test('general items never carry citations', () => {
  const c = validatePreLesson({
    mental_preparation: [{ title: 'x', text: 'General.', basis: 'general', refs: ['H1'] }],
    prerequisites: [], teaching_plan: [],
  }, H, S);
  assert.deepEqual(c.mental_preparation[0].refs, []);
});

test('handout passages not cited by the plan are listed as uncovered, not hidden', () => {
  const c = validatePreLesson({
    mental_preparation: [], prerequisites: [],
    teaching_plan: [{ title: 'Mechanism', text: 'Only this', basis: 'document', refs: ['H2'] }],
  }, H, S);
  assert.deepEqual(c.uncovered_handout_passage_ids, ['h-title', 'h-dose']);
});

test('empty sections produce a visible note', () => {
  const c = validatePreLesson({ mental_preparation: [], prerequisites: null, teaching_plan: 'bad' }, H, S);
  assert.equal(c.notes.length, 3);
  assert.deepEqual(c.uncovered_handout_passage_ids, ['h-title', 'h-mech', 'h-dose']);
});

test('request carries labels and the grounding rules; response parsing rejects junk', () => {
  const req = buildPreLessonRequest('m', H, S);
  assert.equal(req.tool_choice.name, PRELESSON_TOOL);
  assert.match(req.messages[0].content, /H2 \(paragraph, handout page 1\): Aspirin irreversibly/);
  assert.match(req.messages[0].content, /S3 \(source page 58\)/);
  assert.match(req.system, /Never invent labels, page numbers/);
  assert.ok('error' in parsePreLessonResponse({ content: [{ type: 'text', text: 'x' }] }));
  assert.ok('raw' in parsePreLessonResponse({ content: [{ type: 'tool_use', name: PRELESSON_TOOL, input: { teaching_plan: [] } }] }));
});
