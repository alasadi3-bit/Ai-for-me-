import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateOne, validateBatch, parseAnthropicResponse, chunkUnits, buildAnthropicRequest,
  numbersIn, protectedTermsIn, normaliseDigits, TOOL_NAME, SYSTEM_PROMPT,
} from '../src/lib/translation';

const EN = 'The antiplatelet dose is 75 mg once daily and COX-1 is inhibited.';
const GOOD = 'جرعة مضاد الصفيحات هي 75 ملغ مرة واحدة يوميًا ويتم تثبيط COX-1.';

test('good translation passes all checks with no flags', () => {
  const r = validateOne(EN, GOOD);
  assert.deepEqual(r.flags, []);
  assert.equal(r.checks.numbers_ok, true);
  assert.equal(r.checks.terms_ok, true);
});

test('changed dose is flagged (number missing and added)', () => {
  const r = validateOne(EN, GOOD.replace('75', '57'));
  assert.ok(r.flags.includes('numbers_missing'));
  assert.ok(r.flags.includes('numbers_added'));
  assert.deepEqual(r.checks.missing_numbers, ['75']);
});

test('Arabic-Indic digits are recognised as the same number', () => {
  const r = validateOne(EN, GOOD.replace('75', '٧٥'));
  assert.deepEqual(r.flags, []);
  assert.equal(normaliseDigits('٣٫٥'), '3.5');
});

test('dropped acronym is flagged', () => {
  const r = validateOne(EN, 'جرعة مضاد الصفيحات هي 75 ملغ مرة واحدة يوميًا ويتم تثبيط الإنزيم.');
  assert.ok(r.flags.includes('terms_missing'));
  assert.deepEqual(r.checks.missing_terms, ['COX-1']);
});

test('summary-like (far too short) output is flagged', () => {
  const longEn = 'Aspirin irreversibly inhibits cyclooxygenase, an enzyme needed for prostaglandin synthesis in many tissues.';
  const r = validateOne(longEn, 'الأسبرين يثبط الإنزيم.');
  assert.ok(r.flags.includes('possible_omission_or_summary'));
});

test('English copied back unchanged is flagged as not translated', () => {
  const r = validateOne('Platelets cannot make new enzyme.', 'Platelets cannot make new enzyme.');
  assert.ok(r.flags.includes('not_translated'));
});

test('number and term extraction helpers', () => {
  assert.deepEqual(numbersIn('300 to 900 mg every 4 to 6 hours, 0.5 mg/kg, 1,000 IU'), ['300', '900', '4', '6', '0.5', '1,000']);
  assert.deepEqual(protectedTermsIn('COX-1 reduces thromboxane A2; 5-HT3 and HIV, but not Aspirin or I.'), ['COX-1', 'A2', '5-HT3', 'HIV']);
});

const units = [
  { id: 'u1', text: 'Aspirin inhibits COX-1.' },
  { id: 'u2', text: 'The dose is 75 mg daily.' },
  { id: 'u3', text: 'Avoid in children under 16.' },
];

test('batch: complete, ordered result is accepted', () => {
  const v = validateBatch(units, [
    { id: 'u1', arabic: 'يثبط الأسبرين COX-1.' },
    { id: 'u2', arabic: 'الجرعة هي 75 ملغ يوميًا.' },
    { id: 'u3', arabic: 'يُتجنب في الأطفال دون سن 16.' },
  ]);
  assert.equal(v.accepted.length, 3);
  assert.equal(v.missing.length, 0);
  assert.ok(v.accepted.every((a) => a.flags.length === 0));
});

test('batch: a skipped sentence is reported missing, never silently accepted', () => {
  const v = validateBatch(units, [
    { id: 'u1', arabic: 'يثبط الأسبرين COX-1.' },
    { id: 'u3', arabic: 'يُتجنب في الأطفال دون سن 16.' },
  ]);
  assert.deepEqual(v.missing, [{ id: 'u2', reason: 'missing' }]);
  assert.equal(v.accepted.length, 2);
});

test('batch: empty and duplicated results are rejected; unexpected ids ignored', () => {
  const v = validateBatch(units, [
    { id: 'u1', arabic: '   ' },
    { id: 'u2', arabic: 'الجرعة هي 75 ملغ يوميًا.' },
    { id: 'u2', arabic: 'الجرعة 75.' },
    { id: 'u3', arabic: 'يُتجنب في الأطفال دون سن 16.' },
    { id: 'zzz', arabic: 'غير مطلوب' },
  ]);
  assert.deepEqual(v.missing, [
    { id: 'u1', reason: 'empty' },
    { id: 'u2', reason: 'duplicate' },
  ]);
  assert.deepEqual(v.unexpected, ['zzz']);
  assert.equal(v.accepted.length, 1);
});

test('response parsing: tool call accepted, truncated output rejected', () => {
  const ok = parseAnthropicResponse({
    stop_reason: 'tool_use',
    content: [{ type: 'tool_use', name: TOOL_NAME, input: { translations: [{ id: 'u1', arabic: 'x' }] } }],
  });
  assert.ok('translations' in ok && ok.translations.length === 1);
  assert.ok('error' in parseAnthropicResponse({ stop_reason: 'max_tokens', content: [] }));
  assert.ok('error' in parseAnthropicResponse({ stop_reason: 'end_turn', content: [{ type: 'text', text: 'hi' }] }));
  assert.ok('error' in parseAnthropicResponse(null));
});

test('request forces the tool and carries the strict rules', () => {
  const req = buildAnthropicRequest('some-model', units);
  assert.equal(req.tool_choice.name, TOOL_NAME);
  assert.equal(req.model, 'some-model');
  assert.match(SYSTEM_PROMPT, /Do NOT summarise/);
  assert.match(req.messages[0].content, /"id": "u1"/);
  assert.match(req.messages[0].content, /Aspirin inhibits COX-1\./);
});

test('chunking never splits or drops a unit and keeps order', () => {
  const many = Array.from({ length: 30 }, (_, i) => ({ id: `u${i}`, text: 'x'.repeat(400) }));
  const chunks = chunkUnits(many, 12, 3500);
  assert.deepEqual(chunks.flat().map((u) => u.id), many.map((u) => u.id));
  assert.ok(chunks.every((c) => c.length <= 12));
  assert.ok(chunks.length >= 3);
});
