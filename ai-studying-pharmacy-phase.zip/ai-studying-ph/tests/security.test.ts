// Server-side authentication boundary and "no secrets in the browser" checks.
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { bearerToken, publicConfig } from '../server/http';
import { handleTranslate } from '../server/translate';
import { handlePreLesson } from '../server/prelesson';

const ROOT = resolve(__dirname, '..');
const UUID = '11111111-1111-4111-8111-111111111111';
const SECRETS = { SUPABASE_URL: 'https://proj.supabase.co', SUPABASE_ANON_KEY: 'anon-public-key', SUPABASE_SERVICE_ROLE_KEY: 'SERVICE-ROLE-SECRET-VALUE', ANTHROPIC_API_KEY: 'sk-ant-SECRET-ANTHROPIC-VALUE-1234567890' };

describe('bearer token parsing', () => {
  it('accepts exactly "Bearer <token>"', () => {
    assert.equal(bearerToken('Bearer abc.def'), 'abc.def');
    assert.equal(bearerToken('bearer abc'), 'abc');
  });
  it('rejects everything else', () => {
    for (const bad of [undefined, null, '', 'Bearer', 'Bearer ', 'Basic abc', 'abc', 'Bearer a b', ['Bearer x'], 42]) {
      assert.equal(bearerToken(bad as any), null, JSON.stringify(bad));
    }
  });
});

describe('/api/config exposes only what is meant to be public', () => {
  it('never contains the service-role key or the Anthropic key, only a boolean for AI', () => {
    const r = publicConfig(SECRETS);
    const text = JSON.stringify(r.json);
    assert.ok(!text.includes('SERVICE-ROLE-SECRET-VALUE'));
    assert.ok(!text.includes('SECRET-ANTHROPIC'));
    assert.ok(!/sk-ant/.test(text));
    assert.deepEqual(Object.keys(r.json as object).sort(), ['aiConfigured', 'supabaseAnonKey', 'supabaseConfigured', 'supabaseUrl']);
    assert.equal((r.json as any).aiConfigured, true);
    assert.equal((r.json as any).supabaseAnonKey, 'anon-public-key');
  });
  it('reports "not configured" truthfully when credentials are missing (no placeholders)', () => {
    const r = publicConfig({}).json as any;
    assert.deepEqual(r, { supabaseUrl: null, supabaseAnonKey: null, supabaseConfigured: false, aiConfigured: false });
  });
});

describe('server routes require a signed-in user', () => {
  const noCalls = () => { throw new Error('the server must not call out without a user token'); };
  it('translate: no token -> 401 and no outbound request', async () => {
    const r = await handleTranslate({ env: SECRETS, fetchImpl: noCalls as any, token: null, body: { passageId: UUID } });
    assert.equal(r.status, 401);
  });
  it('prelesson: no token -> 401 and no outbound request', async () => {
    const r = await handlePreLesson({ env: SECRETS, fetchImpl: noCalls as any, token: null, body: { handoutId: UUID, sourceId: null } });
    assert.equal(r.status, 401);
  });
  it('malformed ids are rejected before any request is made', async () => {
    const t = await handleTranslate({ env: SECRETS, fetchImpl: noCalls as any, token: 'user-jwt', body: { passageId: "x' or 1=1" } });
    assert.equal(t.status, 400);
    const p = await handlePreLesson({ env: SECRETS, fetchImpl: noCalls as any, token: 'user-jwt', body: { handoutId: 'nope' } });
    assert.equal(p.status, 400);
  });
});

describe('the server acts as the user, never with a privileged key', () => {
  it('translate: every database request carries the user\'s JWT, never the service-role or anon key as identity; another user\'s passage is simply "not found"', async () => {
    const seen: { url: string; headers: any }[] = [];
    const fetchImpl = async (url: string, init: any) => { seen.push({ url, headers: init.headers }); return { ok: true, status: 200, json: async () => [], text: async () => '[]' }; };
    const r = await handleTranslate({ env: SECRETS, fetchImpl: fetchImpl as any, token: 'USER-JWT', body: { passageId: UUID } });
    assert.equal(r.status, 404, 'RLS returns no rows for someone else\'s passage');
    assert.ok(seen.length > 0);
    for (const s of seen) {
      assert.match(s.url, /^https:\/\/proj\.supabase\.co\/rest\/v1\//);
      assert.equal(s.headers.Authorization, 'Bearer USER-JWT');
      assert.equal(s.headers.apikey, 'anon-public-key');
      assert.ok(!JSON.stringify(s.headers).includes('SERVICE-ROLE'));
      assert.ok(!JSON.stringify(s.headers).includes('sk-ant'));
    }
    assert.ok(!seen.some((s) => /anthropic/i.test(s.url)), 'no AI call is made for a passage the user cannot see');
  });
});

describe('no secrets in code that ships to the browser or the repository', () => {
  function walk(dir: string, out: string[] = []): string[] {
    for (const f of readdirSync(dir)) {
      if (['node_modules', '.git', 'vendor', 'fixtures'].includes(f)) continue;
      const p = join(dir, f);
      if (statSync(p).isDirectory()) walk(p, out);
      else if (/\.(js|mjs|ts|json|html|css|webmanifest|sql|md)$/.test(f)) out.push(p);
    }
    return out;
  }
  const files = walk(ROOT).filter((f) => !f.endsWith('security.test.ts'));

  it('no Anthropic key values or JWT-shaped tokens anywhere in the project', () => {
    const bad: string[] = [];
    for (const f of files) {
      const t = readFileSync(f, 'utf8');
      if (/sk-ant-[A-Za-z0-9_-]{16,}/.test(t)) bad.push(relative(ROOT, f) + ': Anthropic key');
      if (/eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}/.test(t)) bad.push(relative(ROOT, f) + ': JWT-like token');
    }
    assert.deepEqual(bad, []);
  });

  it('browser code (public/) never mentions a service-role key', () => {
    const bad = files.filter((f) => relative(ROOT, f).startsWith('public/') && !relative(ROOT, f).startsWith('public/lib/') && /service[_-]?role/i.test(readFileSync(f, 'utf8')));
    assert.deepEqual(bad.map((f) => relative(ROOT, f)), []);
  });

  it('server code never reads a service-role environment variable', () => {
    const bad = files.filter((f) => /^(server|api)\//.test(relative(ROOT, f)) && /SERVICE_ROLE|SUPABASE_SERVICE/.test(readFileSync(f, 'utf8')));
    assert.deepEqual(bad.map((f) => relative(ROOT, f)), []);
  });

  it('the Anthropic key is only referenced by server code (and the setup screen as a variable NAME)', () => {
    const users = files.filter((f) => /ANTHROPIC_API_KEY/.test(readFileSync(f, 'utf8'))).map((f) => relative(ROOT, f));
    for (const u of users) assert.ok(/^(server|api|public\/app\/screens-auth\.js|public\/app\/screens-prelesson\.js|public\/app\/screens-library\.js|public\/app\/screens-study\.js|docs|README|tests|scripts)/.test(u), `unexpected reference: ${u}`);
    for (const u of users.filter((x) => x.startsWith('public/'))) {
      const t = readFileSync(join(ROOT, u), 'utf8');
      assert.ok(!/process\.env|ANTHROPIC_API_KEY\s*[:=]\s*['"`]/.test(t), `${u} must only mention the name inside a message`);
    }
  });

  it('.gitignore keeps environment files out of the repository', () => {
    assert.ok(existsSync(join(ROOT, '.gitignore')));
    assert.match(readFileSync(join(ROOT, '.gitignore'), 'utf8'), /^\.env/m);
  });
});
