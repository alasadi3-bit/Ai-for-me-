// Row Level Security, role and storage-policy tests.
//
// These run supabase/schema.sql + supabase/migrations/*.sql on a REAL PostgreSQL server
// (started temporarily by this test) and act as different users by switching to the
// `authenticated` / `anon` roles with a JWT-claims setting, exactly how PostgREST does it.
//
// What this proves: the SQL policies, grants, triggers and constraints.
// What this does NOT prove: PostgREST, Supabase Auth or the Storage API themselves. tests/sql/supabase-shim.sql
// is a stand-in for the few Supabase objects the SQL depends on. After setting up Supabase, repeat the
// manual checks in docs/supabase-setup.md ("Verify isolation with two accounts").
//
// Needs the PostgreSQL 16 server binaries (initdb, pg_ctl) and `psql`. Without them the suite is SKIPPED, not passed.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, chmodSync } from 'node:fs';
import { join, resolve } from 'node:path';

const PG_BIN = ['/usr/lib/postgresql/16/bin', '/usr/lib/postgresql/17/bin', '/usr/lib/postgresql/15/bin'].find((d) => existsSync(join(d, 'initdb')));
const HAVE_PG = !!PG_BIN && existsSync('/usr/bin/psql') && process.getuid?.() === 0 && spawnSync('id', ['postgres']).status === 0;
const SKIP = HAVE_PG ? false : 'PostgreSQL server binaries / postgres OS user not available (this suite needs them and was SKIPPED)';

const ROOT = resolve(__dirname, '..');
const A = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const B = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const ADM = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd';
const DOC_A = '11111111-1111-4111-8111-111111111111';
const DOC_B = '22222222-2222-4222-8222-222222222222';
const DOC_A2 = '11111111-1111-4111-8111-111111111112';
const P_A = '33333333-3333-4333-8333-333333333331';
const P_A2 = '33333333-3333-4333-8333-333333333332';
const P_B = '33333333-3333-4333-8333-333333333334';
const U_A = '44444444-4444-4444-8444-444444444441';
const U_B = '44444444-4444-4444-8444-444444444442';
const T_A = '55555555-5555-4555-8555-555555555551';
const T_B = '55555555-5555-4555-8555-555555555552';

let dir = '';
let sock = '';

function psql(sql: string): { ok: boolean; out: string; err: string } {
  const r = spawnSync('psql', ['-X', '-q', '-t', '-A', '-v', 'ON_ERROR_STOP=1', '-h', sock, '-U', 'postgres', '-d', 'testdb', '-f', '-'], { input: sql, encoding: 'utf8' });
  return { ok: r.status === 0, out: (r.stdout ?? '').trim(), err: (r.stderr ?? '').trim() };
}

/** Run SQL as `role` with a JWT subject; rolled back unless commit is true. */
function as(role: 'authenticated' | 'anon', uid: string | null, body: string, commit = false) {
  const claims = uid ? JSON.stringify({ sub: uid, role }) : '{}';
  return psql(`begin;\nset local role ${role};\nset local request.jwt.claims = '${claims}';\n${body}\n${commit ? 'commit' : 'rollback'};`);
}
const ok = (r: { ok: boolean; err: string }, msg = '') => assert.ok(r.ok, `${msg} expected success but got: ${r.err}`);
const denied = (r: { ok: boolean; err: string; out: string }, re: RegExp, msg = '') => {
  assert.equal(r.ok, false, `${msg} expected a denial but it SUCCEEDED (output: ${r.out})`);
  assert.match(r.err, re, `${msg} wrong error: ${r.err}`);
};
const DENY = /row-level security|permission denied|42501|does not exist or belongs to another user|violates check constraint/i;

describe('Supabase SQL: RLS, roles, storage (real PostgreSQL, Supabase shim)', { skip: SKIP }, () => {
  before(() => {
    dir = mkdtempSync('/tmp/aisph-pg-');
    chmodSync(dir, 0o777);
    sock = dir;
    const run = (cmd: string, args: string[]) => {
      const r = spawnSync('runuser', ['-u', 'postgres', '--', join(PG_BIN!, cmd), ...args], { encoding: 'utf8' });
      assert.equal(r.status, 0, `${cmd} failed: ${r.stderr}${r.stdout}`);
    };
    run('initdb', ['-D', join(dir, 'data'), '-A', 'trust', '-U', 'postgres', '--no-sync']);
    run('pg_ctl', ['-D', join(dir, 'data'), '-o', `-c listen_addresses='' -c unix_socket_directories='${dir}' -c fsync=off`, '-l', join(dir, 'log'), '-w', 'start']);
    const c = spawnSync('createdb', ['-h', sock, '-U', 'postgres', 'testdb'], { encoding: 'utf8' });
    assert.equal(c.status, 0, c.stderr);

    ok(psql(readFileSync(join(ROOT, 'tests/sql/supabase-shim.sql'), 'utf8')), 'shim');
    ok(psql(readFileSync(join(ROOT, 'supabase/schema.sql'), 'utf8')), 'schema.sql');
    const migs = readdirSync(join(ROOT, 'supabase/migrations')).filter((f) => f.endsWith('.sql')).sort();
    assert.ok(migs.length > 0);
    for (const m of migs) ok(psql(readFileSync(join(ROOT, 'supabase/migrations', m), 'utf8')), m);
    // Re-running must be safe (documented as idempotent).
    ok(psql(readFileSync(join(ROOT, 'supabase/schema.sql'), 'utf8')), 'schema.sql re-run');
    for (const m of migs) ok(psql(readFileSync(join(ROOT, 'supabase/migrations', m), 'utf8')), m + ' re-run');

    ok(psql(`
      insert into auth.users (id, email) values ('${A}','a@example.com'), ('${B}','b@example.com'), ('${ADM}','admin@example.com');
      update public.profiles set role = 'admin' where id = '${ADM}';
      insert into public.documents (id, owner, kind, title, file_name, storage_path) values
        ('${DOC_A}', '${A}', 'handout', 'A handout', 'a.pdf', '${A}/${DOC_A}.pdf'),
        ('${DOC_A2}', '${A}', 'source',  'A source',  'a2.pdf', '${A}/${DOC_A2}.pdf'),
        ('${DOC_B}', '${B}', 'handout', 'B handout', 'b.pdf', '${B}/${DOC_B}.pdf');
      insert into public.passages (id, owner, document_id, page_index, seq, raw_text, text) values
        ('${P_A}',  '${A}', '${DOC_A}',  1, 0, 'Aspirin inhibits COX.', 'Aspirin inhibits COX.'),
        ('${P_A2}', '${A}', '${DOC_A2}', 1, 0, 'Source text.', 'Source text.'),
        ('${P_B}',  '${B}', '${DOC_B}',  1, 0, 'B secret text.', 'B secret text.');
      insert into public.units (id, owner, passage_id, document_id, idx, text) values
        ('${U_A}', '${A}', '${P_A}', '${DOC_A}', 0, 'Aspirin inhibits COX.'),
        ('${U_B}', '${B}', '${P_B}', '${DOC_B}', 0, 'B secret text.');
      insert into public.translations (id, owner, unit_id, machine_text, model, prompt_version) values
        ('${T_A}', '${A}', '${U_A}', 'ar A', 'm', 'v1'),
        ('${T_B}', '${B}', '${U_B}', 'ar B', 'm', 'v1');
      insert into public.links (owner, handout_passage_id, source_passage_id) values ('${A}', '${P_A}', '${P_A2}');
      insert into public.study_progress (owner, handout_id, passage_index) values ('${B}', '${DOC_B}', 7);
      insert into storage.buckets (id, name, public) values ('documents', 'documents', false) on conflict do nothing;
      insert into storage.objects (bucket_id, name, owner) values
        ('documents', '${A}/${DOC_A}.pdf', '${A}'), ('documents', '${B}/${DOC_B}.pdf', '${B}');
    `), 'seed');
  });

  after(() => {
    if (!dir) return;
    spawnSync('runuser', ['-u', 'postgres', '--', join(PG_BIN!, 'pg_ctl'), '-D', join(dir, 'data'), '-m', 'immediate', 'stop']);
    rmSync(dir, { recursive: true, force: true });
  });

  // ------------------------------------------------------------- isolation
  it('a student sees only their own documents; the other student sees only theirs', () => {
    assert.equal(as('authenticated', A, 'select string_agg(id::text, \',\' order by id) from public.documents;').out, `${DOC_A},${DOC_A2}`);
    assert.equal(as('authenticated', B, 'select string_agg(id::text, \',\') from public.documents;').out, DOC_B);
  });

  it('every content table hides the other student\'s rows (select)', () => {
    for (const t of ['documents', 'document_pages', 'passages', 'units', 'translations', 'translation_edits', 'links', 'study_progress', 'prelessons']) {
      const r = as('authenticated', A, `select count(*) from public.${t} where owner = '${B}';`);
      ok(r, t);
      assert.equal(r.out, '0', `${t}: A can see B's rows`);
    }
    assert.equal(as('authenticated', A, `select count(*) from public.passages where id = '${P_B}';`).out, '0');
    assert.equal(as('authenticated', A, `select count(*) from public.translations where id = '${T_B}';`).out, '0');
  });

  it('the anonymous role can read nothing', () => {
    for (const t of ['documents', 'passages', 'units', 'translations', 'study_progress', 'profiles']) {
      denied(as('anon', null, `select * from public.${t};`), /permission denied/i, t);
    }
    assert.equal(as('anon', null, 'select count(*) from storage.objects;').out, '0');
  });

  it('a student cannot update or delete the other student\'s rows (0 rows affected, data intact)', () => {
    const u = as('authenticated', B, `update public.documents set title = 'hacked' where id = '${DOC_A}' returning id;`);
    ok(u); assert.equal(u.out, '');
    const d = as('authenticated', B, `delete from public.documents where id = '${DOC_A}' returning id;`);
    ok(d); assert.equal(d.out, '');
    const p = as('authenticated', B, `update public.passages set text = 'hacked' where id = '${P_A}' returning id;`);
    ok(p); assert.equal(p.out, '');
    assert.equal(psql(`select title from public.documents where id = '${DOC_A}';`).out, 'A handout');
    assert.equal(psql(`select count(*) from public.documents where id = '${DOC_A}';`).out, '1');
  });

  it('a student cannot insert a row owned by someone else (WITH CHECK)', () => {
    denied(as('authenticated', B, `insert into public.documents (owner, kind, title, file_name, storage_path) values ('${A}', 'source', 't', 'f.pdf', '${A}/x.pdf');`), DENY);
  });

  it('owner defaults to the caller; a row cannot be re-assigned to another user', () => {
    const r = as('authenticated', A, `insert into public.documents (kind, title, file_name, storage_path) values ('source', 't', 'f.pdf', '${A}/new.pdf') returning owner;`);
    ok(r); assert.equal(r.out, A);
    denied(as('authenticated', A, `update public.documents set owner = '${B}' where id = '${DOC_A}';`), DENY, 'reassign owner');
  });

  it('a student cannot attach their own rows to another student\'s parent rows', () => {
    denied(as('authenticated', B, `insert into public.passages (owner, document_id, page_index, seq, raw_text, text) values ('${B}', '${DOC_A}', 9, 0, 'x', 'x');`), DENY, 'passage on A doc');
    denied(as('authenticated', B, `insert into public.document_pages (owner, document_id, page_index) values ('${B}', '${DOC_A}', 9);`), DENY, 'page on A doc');
    denied(as('authenticated', B, `insert into public.units (owner, passage_id, document_id, idx, text) values ('${B}', '${P_A}', '${DOC_B}', 5, 'x');`), DENY, 'unit on A passage');
    denied(as('authenticated', B, `insert into public.translations (owner, unit_id, machine_text, model, prompt_version) values ('${B}', '${U_A}', 'x', 'm', 'v');`), DENY, 'translation on A unit');
    denied(as('authenticated', B, `insert into public.translation_edits (owner, translation_id, edited_text) values ('${B}', '${T_A}', 'x');`), DENY, 'edit on A translation');
    denied(as('authenticated', B, `insert into public.links (owner, handout_passage_id, source_passage_id) values ('${B}', '${P_A}', '${P_A2}');`), DENY, 'link between A passages');
    denied(as('authenticated', B, `insert into public.links (owner, handout_passage_id, source_passage_id) values ('${B}', '${P_B}', '${P_A2}');`), DENY, 'link to A source passage');
    denied(as('authenticated', B, `insert into public.study_progress (owner, handout_id) values ('${B}', '${DOC_A}');`), DENY, 'progress on A doc');
    denied(as('authenticated', B, `insert into public.prelessons (owner, handout_id, content, model, prompt_version) values ('${B}', '${DOC_A}', '{}', 'm', 'v');`), DENY, 'prelesson on A doc');
  });

  it('a student CAN build the same structure on their own parents (the trigger does not block normal use)', () => {
    ok(as('authenticated', A, `
      insert into public.passages (owner, document_id, page_index, seq, raw_text, text) values ('${A}', '${DOC_A}', 2, 0, 'ok', 'ok');
      insert into public.links (owner, handout_passage_id, source_passage_id) values ('${A}', '${P_A}', '${P_A}');
      insert into public.study_progress (owner, handout_id, source_id) values ('${A}', '${DOC_A}', '${DOC_A2}');`), 'own rows');
  });

  // ---------------------------------------------------------- append-only
  it('machine translations and corrections are append-only for clients (no UPDATE)', () => {
    denied(as('authenticated', A, `update public.translations set machine_text = 'edited' where id = '${T_A}';`), /permission denied/i, 'update translation');
    ok(as('authenticated', A, `insert into public.translation_edits (owner, translation_id, edited_text) values ('${A}', '${T_A}', 'my correction');`), 'insert edit');
    const e = as('authenticated', A, `insert into public.translation_edits (id, owner, translation_id, edited_text) values (gen_random_uuid(), '${A}', '${T_A}', 'c2') returning id;`);
    ok(e);
    denied(as('authenticated', A, `update public.translation_edits set edited_text = 'x';`), /permission denied/i, 'update edit');
    ok(as('authenticated', A, `insert into public.translations (owner, unit_id, machine_text, model, prompt_version) values ('${A}', '${U_A}', 'ar A v2', 'm', 'v2');`), 'new machine translation appended');
  });

  // -------------------------------------------------------------- storage path on documents
  it('a document cannot point at another user\'s folder or use path tricks', () => {
    denied(as('authenticated', A, `insert into public.documents (kind, title, file_name, storage_path) values ('source','t','f.pdf','${B}/${DOC_B}.pdf');`), /violates check constraint|documents_storage_path_owner/i, 'foreign folder');
    denied(as('authenticated', A, `insert into public.documents (kind, title, file_name, storage_path) values ('source','t','f.pdf','${A}/../${B}/x.pdf');`), /violates check constraint|documents_storage_path_owner/i, 'dot-dot');
  });

  // ---------------------------------------------------------- profiles & roles
  it('every auth user gets a profile and it is always a student at creation', () => {
    assert.equal(psql(`select role from public.profiles where id = '${A}';`).out, 'student');
    assert.equal(psql(`select role from public.profiles where id = '${B}';`).out, 'student');
    const n = psql(`insert into auth.users (id, email) values ('eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee', 'new@example.com'); select role, email from public.profiles where id = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee'; delete from auth.users where id = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';`);
    ok(n); assert.match(n.out, /student\|new@example.com/);
  });

  it('a student can read only their own profile', () => {
    assert.equal(as('authenticated', A, 'select count(*) from public.profiles;').out, '1');
    assert.equal(as('authenticated', A, `select count(*) from public.profiles where id = '${B}';`).out, '0');
  });

  it('a student can change their display name but NEVER their own role', () => {
    const n = as('authenticated', A, `update public.profiles set display_name = 'Ali' where id = '${A}' returning display_name;`);
    ok(n); assert.equal(n.out, 'Ali');
    denied(as('authenticated', A, `update public.profiles set role = 'admin' where id = '${A}';`), /permission denied/i, 'layer 2: column grant');
    denied(as('authenticated', A, `update public.profiles set role = 'admin', display_name = 'x' where id = '${A}';`), /permission denied/i, 'mixed update');
    assert.equal(psql(`select role from public.profiles where id = '${A}';`).out, 'student');
  });

  it('even if the column grant were ever widened by mistake, the trigger still blocks a role change (layer 3)', () => {
    const r = psql(`
      begin;
      grant update (role) on public.profiles to authenticated;
      set local role authenticated;
      set local request.jwt.claims = '{"sub":"${A}","role":"authenticated"}';
      update public.profiles set role = 'admin' where id = '${A}';
      rollback;`);
    denied(r, /roles cannot be changed through the API/i, 'layer 3');
    assert.equal(psql(`select role from public.profiles where id = '${A}';`).out, 'student');
  });

  it('a student cannot create, delete or edit someone else\'s profile', () => {
    denied(as('authenticated', A, `insert into public.profiles (id, email, role) values (gen_random_uuid(), 'x@example.com', 'admin');`), /permission denied|row-level security/i, 'insert');
    denied(as('authenticated', A, `delete from public.profiles where id = '${A}';`), /permission denied/i, 'delete own');
    const u = as('authenticated', A, `update public.profiles set display_name = 'x' where id = '${B}' returning id;`);
    ok(u); assert.equal(u.out, '');
  });

  it('is_admin() is false for students and true only for the promoted account; anon cannot call it', () => {
    assert.equal(as('authenticated', A, 'select public.is_admin();').out, 'f');
    assert.equal(as('authenticated', ADM, 'select public.is_admin();').out, 't');
    denied(as('anon', null, 'select public.is_admin();'), /permission denied/i, 'anon');
  });

  it('an admin can list profiles but gets NO access to students\' study content, and cannot self-promote further or edit others', () => {
    assert.equal(as('authenticated', ADM, 'select count(*) from public.profiles;').out, '3');
    for (const t of ['documents', 'passages', 'units', 'translations', 'links', 'study_progress']) {
      assert.equal(as('authenticated', ADM, `select count(*) from public.${t};`).out, '0', `admin sees ${t}`);
    }
    denied(as('authenticated', ADM, `update public.profiles set role = 'student' where id = '${ADM}';`), /permission denied/i, 'admin role edit via API');
    const u = as('authenticated', ADM, `update public.profiles set display_name = 'x' where id = '${A}' returning id;`);
    ok(u); assert.equal(u.out, '');
  });

  // --------------------------------------------------------------- storage
  it('private bucket: only the owner folder is readable; never public', () => {
    assert.equal(psql(`select public from storage.buckets where id = 'documents';`).out, 'f');
    assert.equal(psql(`select file_size_limit || ' ' || allowed_mime_types::text from storage.buckets where id = 'documents';`).out, '52428800 {application/pdf}');
    assert.equal(as('authenticated', A, 'select string_agg(name, \',\') from storage.objects;').out, `${A}/${DOC_A}.pdf`);
    assert.equal(as('authenticated', B, 'select string_agg(name, \',\') from storage.objects;').out, `${B}/${DOC_B}.pdf`);
    assert.equal(as('authenticated', ADM, 'select count(*) from storage.objects;').out, '0', 'admins do not get file access either');
  });

  it('storage writes are limited to the caller\'s own folder, with no path tricks', () => {
    ok(as('authenticated', A, `insert into storage.objects (bucket_id, name) values ('documents', '${A}/new.pdf');`), 'own folder');
    denied(as('authenticated', A, `insert into storage.objects (bucket_id, name) values ('documents', '${B}/evil.pdf');`), DENY, 'foreign folder');
    denied(as('authenticated', A, `insert into storage.objects (bucket_id, name) values ('documents', 'evil.pdf');`), DENY, 'root of bucket');
    denied(as('authenticated', A, `insert into storage.objects (bucket_id, name) values ('documents', '${A}/../${B}/evil.pdf');`), DENY, 'dot-dot');
    denied(as('anon', null, `insert into storage.objects (bucket_id, name) values ('documents', '${A}/anon.pdf');`), DENY, 'anon');
  });

  it('a student cannot overwrite or delete another student\'s file', () => {
    const u = as('authenticated', B, `update storage.objects set name = '${B}/stolen.pdf' where name = '${A}/${DOC_A}.pdf' returning id;`);
    ok(u); assert.equal(u.out, '');
    const d = as('authenticated', B, `delete from storage.objects where name = '${A}/${DOC_A}.pdf' returning id;`);
    ok(d); assert.equal(d.out, '');
    assert.equal(psql(`select count(*) from storage.objects where name = '${A}/${DOC_A}.pdf';`).out, '1');
    denied(as('authenticated', A, `update storage.objects set name = '${B}/moved.pdf' where name = '${A}/${DOC_A}.pdf';`), DENY, 'move into B folder (WITH CHECK)');
  });

  // ------------------------------------------------- progress persistence (study position + timer)
  it('study position and timer persist across separate sessions, update in place, and stay private', () => {
    ok(as('authenticated', A, `insert into public.study_progress (owner, handout_id, source_id, passage_index, source_page, timer_accumulated_ms, timer_started_at)
        values ('${A}', '${DOC_A}', '${DOC_A2}', 3, 12, 125000, '2026-10-13T10:00:00Z')
        on conflict (owner, handout_id) do update set passage_index = excluded.passage_index, source_page = excluded.source_page,
          timer_accumulated_ms = excluded.timer_accumulated_ms, timer_started_at = excluded.timer_started_at;`, true), 'first save');
    const r1 = as('authenticated', A, `select passage_index || '|' || source_page || '|' || timer_accumulated_ms || '|' || (timer_started_at is not null) from public.study_progress where handout_id = '${DOC_A}';`);
    assert.equal(r1.out, '3|12|125000|true');
    ok(as('authenticated', A, `insert into public.study_progress (owner, handout_id, passage_index, timer_accumulated_ms, timer_started_at)
        values ('${A}', '${DOC_A}', 4, 190000, null)
        on conflict (owner, handout_id) do update set passage_index = excluded.passage_index,
          timer_accumulated_ms = excluded.timer_accumulated_ms, timer_started_at = excluded.timer_started_at;`, true), 'second save (upsert)');
    const r2 = as('authenticated', A, `select count(*) || '|' || max(passage_index) || '|' || max(timer_accumulated_ms) || '|' || bool_and(timer_started_at is null) from public.study_progress where handout_id = '${DOC_A}';`);
    assert.equal(r2.out, '1|4|190000|true', 'upsert must update the one row, not add another');
    assert.equal(as('authenticated', B, `select count(*) from public.study_progress where handout_id = '${DOC_A}';`).out, '0');
    denied(as('authenticated', B, `insert into public.study_progress (owner, handout_id, passage_index) values ('${B}', '${DOC_A}', 0) on conflict (owner, handout_id) do update set passage_index = 0;`), DENY, 'B writing progress for A doc');
    assert.equal(psql(`select passage_index from public.study_progress where owner = '${A}' and handout_id = '${DOC_A}';`).out, '4');
  });

  it('manual links and translation corrections persist across sessions', () => {
    ok(as('authenticated', A, `insert into public.links (owner, handout_passage_id, source_passage_id, method, status) values ('${A}', '${P_A2}', '${P_A}', 'manual', 'manual');
        insert into public.translation_edits (owner, translation_id, edited_text) values ('${A}', '${T_A}', 'persisted correction');`, true));
    assert.equal(as('authenticated', A, `select count(*) from public.links where method = 'manual';`).out, '2');
    assert.equal(as('authenticated', A, `select edited_text from public.translation_edits order by created_at desc limit 1;`).out, 'persisted correction');
    assert.equal(as('authenticated', B, `select count(*) from public.links;`).out, '0');
  });

  // ------------------------------------------------------------- deletion
  it('deleting a document removes only its own dependents', () => {
    const before = psql(`select count(*) from public.passages where owner = '${B}';`).out;
    ok(as('authenticated', A, `delete from public.documents where id = '${DOC_A}';`, true), 'delete');
    assert.equal(psql(`select count(*) from public.passages where document_id = '${DOC_A}';`).out, '0');
    assert.equal(psql(`select count(*) from public.units where document_id = '${DOC_A}';`).out, '0');
    assert.equal(psql(`select count(*) from public.passages where owner = '${B}';`).out, before, 'B data untouched');
  });
});
