# Supabase setup (Phase 2) — works from an iPad browser

Nothing here needs a terminal. You will copy two values from Supabase into Vercel and paste two SQL files into the Supabase SQL editor.

> **Never** paste the `service_role` key anywhere in this project. The app does not use it and the tests fail if the code ever mentions it. Only the **anon / public** key is used, and Row Level Security (RLS) is what protects the data.

## 1. Create the project
1. supabase.com → **New project**. Choose a strong database password and save it in your password manager (the app never needs it).
2. Wait until the project is ready.

## 2. Create the tables, policies and storage rules
Open **SQL Editor → New query**, paste the whole file, press **Run**. Do these in order:
1. `supabase/schema.sql` (nine study tables, RLS, private `documents` bucket).
2. `supabase/migrations/0002_profiles_roles_hardening.sql` (profiles and roles, parent-ownership triggers, storage limits).

Both files are safe to run again. If you ever re-run `schema.sql`, run `0002` again afterwards.

Expected result: "Success. No rows returned." If you see an error, copy the exact message and stop; do not continue to the next step.

## 3. Sign-in emails must contain the code
The app signs in with a one-time code (this is also how a new student registers).
1. **Authentication → Email Templates**.
2. Open **Magic Link** and **Confirm signup**. Each body must contain `{{ .Token }}` (for example: `Your sign-in code: {{ .Token }}`). Save both.
3. **Authentication → Providers → Email**: enabled. Keep "Confirm email" on.
4. **Authentication → URL Configuration → Site URL**: your Vercel address (once it exists).

## 4. Copy the two public values
**Project Settings → API**:
* **Project URL** → this is `SUPABASE_URL`
* **anon public** key → this is `SUPABASE_ANON_KEY`

Do not copy the `service_role` key.

## 5. Put them in Vercel (you type them; nobody else needs to see them)
Vercel → your project → **Settings → Environment Variables**. Add for Production, Preview and Development:

| Name | Value | Needed now? |
|---|---|---|
| `SUPABASE_URL` | the Project URL | yes |
| `SUPABASE_ANON_KEY` | the anon public key | yes |
| `ANTHROPIC_API_KEY` | your Anthropic key | **not yet** (Phase 3). Without it the app says "AI is not configured". |

Then **Deployments → ⋯ → Redeploy**. Until both Supabase values are set, the app shows "The server is not configured yet." and does not pretend to sign anyone in.

## 6. Make yourself an administrator (optional, later)
Nobody can grant themselves admin through the app: the API refuses any role change. Roles are changed only here, in the SQL editor, which runs with database-owner rights:

```sql
-- promote
update public.profiles set role = 'admin' where email = 'you@example.com';
-- demote
update public.profiles set role = 'student' where email = 'you@example.com';
```

The person must have signed in at least once so that their profile exists. In this phase an administrator can only **list profiles**. Admins deliberately cannot read students' documents, passages, translations or files.

## 7. Verify isolation with two accounts (do this once — it checks real Supabase, which the automated tests cannot)
1. Sign in as **account A** (your email). Upload any PDF. Note its title.
2. Sign out. Sign in as **account B** (a second email address).
3. B must see **no documents** in the library and the library must show "No documents yet."
4. In the Supabase dashboard open **Storage → documents**: the file must be inside a folder named with A's user id, and the bucket must be marked **Private**.
5. Optional strict check, SQL editor:
   ```sql
   select count(*) from public.documents;          -- as database owner you see every row (expected: A's rows)
   select tablename, rowsecurity from pg_tables where schemaname = 'public';   -- every row must say true
   ```
6. Sign in as A again: the document, your study position and timer are still there (they are saved in your account).

If step 3 ever shows A's document to B, stop using the app and tell me; do not upload real material.

## What is real and what is not
* Real and tested on a real PostgreSQL server: the table policies, role protection, storage-path rules and progress persistence (`tests/rls.test.ts`).
* Tested only with a stand-in: Supabase's own Auth service, REST layer and Storage API. Step 7 above is the check for those.
* Not built: administrator screens, importing the local preview data into an account, password sign-in.
