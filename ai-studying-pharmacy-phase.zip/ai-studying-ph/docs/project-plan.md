# AI for Studying Pharmacy — Project Plan (v0.4)

Status: Final requirements baseline. **Nothing has been built.** Earlier versions are preserved unchanged: `project-plan-v0.1-backup.md`, `project-plan-v0.2-backup.md`, `project-plan-v0.3-backup.md`.

---

## 0. What changed in v0.4

- Added **Section 4A: the complete first study experience** as the single acceptance goal, with the final screen flow and one worked example screen.
- Defined exactly what "analyze both documents" means in the first version (extraction, structure, flags; **not** automatic matching).
- Added **Section 11A**: for every milestone, what is functional, what is shown as an honest "not implemented" placeholder, and what is a mockup.
- No other requirement changed from v0.3.

## 0A. What changed in v0.3 (kept for history)

1. **M0 now tests all three material types** (text PDF, slides, scanned page/image) and reports each separately. Only the text PDF is built in M1. Slides and scans are built later, after the M0 report decides how and when.
2. **Complete, faithful literal translation is a strict acceptance criterion** (Section 6), tested sentence by sentence.
3. **Automatic matching and manual matching are separate, honestly labelled features.** The first usable version uses **manual** matching only. Automatic matching is a later milestone, and the app says "not implemented / not run" until it is built and tested.
4. **The first usable version is narrowed** to: source + handout, split study screen, English with literal Arabic beneath, pre-lesson preparation and plan, simple top timer.
5. **An exact acceptance checklist** for the first usable version is in Section 12.

Kept from earlier versions: Next.js PWA, Supabase, Vercel + GitHub, iPad browser-based development, secret keys only on the server, never fabricate citations or page numbers.

## 1. Repository inspection

- No repository, code, or sample documents exist yet. Only the plan files exist.
- Nothing has been deleted or overwritten without a backup.

---

## 2. Decisions (proposed)

| # | Decision | Why |
|---|----------|-----|
| D1 | Next.js (React + TypeScript) PWA, installable on iPad | Runs in Safari, no local setup, server routes hide secrets, Capacitor wrap possible later |
| D2 | Supabase: Auth, Postgres, private Storage (pgvector added when automatic matching starts) | One service for login, files, data; Row Level Security keeps documents private |
| D3 | Vercel + GitHub; edit in the browser (github.dev / Codespaces) | No terminal; each commit deploys to a live URL you test on the iPad |
| D4 | Files upload directly from iPad to Supabase Storage (signed upload) | Serverless request-size limits |
| D5 | Resumable, page-batched processing with state saved in the database | Serverless time limits; survives iPad sleep or lost connection |
| D6 | **Extraction providers behind one interface:** text-PDF, slide, and OCR providers are separate | Lets slides and scans be added without redesign |
| D7 | **Original extracted text is stored verbatim and never edited by AI.** Any cleaning is a separate display field | No summaries replacing original text |
| D8 | **Two page references:** physical PDF page / slide index (reliable) and printed page label (detected, "unverified" until you confirm) | Textbooks have front matter; printed page 43 may be PDF page 57 |
| D9 | **Sentence-level units.** Every passage is split by deterministic code into numbered units; the English unit text is the extracted text exactly, and each unit gets its own Arabic translation | Makes "every sentence, in order" testable |
| D10 | Translation output is keyed by unit ID and checked by code for completeness (Section 6) | A missing or merged sentence cannot pass silently |
| D11 | **Matching has an explicit `method`: `manual`, `auto`, or `none`**, and an explicit status shown in the UI | Honest labelling (Section 7) |
| D12 | Timer is client-side, computed from saved timestamps | iPad Safari suspends background timers |
| D13 | All AI calls and secret keys stay on the server | Unchanged |

## 3. Assumptions (please verify)

- A1. Single user at first, built with login and private per-user data.
- A2. Your materials are legally yours for personal study; files stay private.
- A3. Source and handout text are **English**; Arabic is the translation layer.
- A4. Passage text will be sent to an AI provider for translation and pre-lesson planning. You accept that.
- A5. You can create accounts on GitHub, Supabase, Vercel, and the Anthropic API (with a monthly spending limit).
- A6. You read Arabic and will review translation samples (only you can judge Arabic medical wording).

## 4. Unresolved questions

1. Can you provide, for M0: **(a)** a text PDF source excerpt (10–30 pages) and its handout; **(b)** a **slide deck or slide PDF** (10–30 slides); **(c)** a **scanned page or photo** (ideally 3+ pages, one a typical phone photo)?
2. Which subject and lecture is the first real study case?
3. Should an English **sentence unit** keep drug and technical terms in English inside the Arabic (my recommendation, e.g. Arabic text with the English term in parentheses), or translate every term?
4. Monthly **budget** ceiling for AI, OCR, and hosting?
5. Are your textbooks two-column, with many tables, structures, or figures that matter?

---

## 4A. The complete first study experience (the acceptance goal)

**Goal statement.** A student uploads a primary source and a handout. Both are analyzed. The student manually links handout passages to source passages. The student sees mental preparation, prerequisite concepts, and a clear teaching plan before the lesson. Then the student studies on a split screen, with the source on one side and the handout on the other, where **every original English sentence has its faithful Arabic translation directly underneath**. A simple study timer stays at the top throughout.

**"Analyze both documents" means, in the first version:**
- extract the original English text with physical page references,
- detect structure (headings, passages, sentences) with deterministic code,
- flag uncertain extraction (garbled text, suspect reading order, empty pages),
- AI is used only for the literal translation and the pre-lesson content.

It does **not** mean automatic matching. Linking is manual until M4 is built and tested.

**Screen flow of the final first usable version**

1. **Library.** Upload a primary source PDF and a handout PDF. Each shows a status.
2. **Analysis progress.** Page-by-page progress for each file, resumable. Ends with a summary: pages, passages, sentences, flagged items.
3. **Document check** (optional, recommended once). Original PDF page beside extracted text; confirm printed page labels; review flags.
4. **Pre-lesson.** Three cards, in order: *Mental preparation*, *Prerequisite concepts*, *Teaching plan*. Each item says "from your documents (passage reference)" or "general background". Button: **Start studying**.
5. **Study screen.** The timer bar sits on top. Below it, source panel (left) and handout panel (right). The handout is walked through passage by passage. Every English sentence has its Arabic directly below it. Inline flags appear where needed. A banner states the matching state: "Automatic matching: not implemented".
6. **Link sheet.** On a handout passage, tap **Link to source**, pick the source passage(s) with the page picker, confirm. The passage shows "Manual link". Unlinked passages show "Not linked".
7. **Original page view.** From any passage, open the real PDF page.
8. **Leave and resume.** Closing the app saves the position; reopening returns to the same passage, and the timer stays correct.

**Worked example: the study screen of the finished first usable version**

(Fake sample text, for illustration only. In the real app the text comes from your uploaded files.)

```
┌───────────────────────────────────────────────────────────────────┐
│  ⏱ 12:41      [ Start ]  [ Pause ]  [ Reset ]                     │
│  Automatic matching: not implemented                              │
├──────────────────────────────┬────────────────────────────────────┤
│  PRIMARY SOURCE              │  HANDOUT   Passage 3 of 24         │
│  Source p. 57 (printed 43 ?) │  Handout p. 2                      │
│                              │  Link status: ● Manual link        │
│  Aspirin irreversibly        │  Aspirin dose: 75 mg once daily.   │
│  inhibits cyclooxygenase.    │  الجرعة هي 75 ملغ مرة واحدة يوميًا.   │
│  يثبّط الأسبرين إنزيم          │                                    │
│  الأكسجيناز الحلقي بشكل       │  ⚠ Check numbers / terms           │
│  لا رجعي.                     │  (flag example)                    │
│                              │                                    │
│  Low-dose aspirin is         │  [ Link to source ] [ View page ]  │
│  commonly 75 to 100 mg daily.│                                    │
│  تبلغ جرعة الأسبرين المنخفضة   │                                    │
│  عادةً 75 إلى 100 ملغ يوميًا. │                                    │
├──────────────────────────────┴────────────────────────────────────┤
│        [ ◀ Previous passage ]            [ Next passage ▶ ]       │
└───────────────────────────────────────────────────────────────────┘
```

Each English sentence is followed immediately by its own Arabic line. Nothing is summarized. Portrait mode stacks the two panels with a switch.

---

## 5. Scope of the first usable version

**Included**
1. Upload a primary source PDF and a handout PDF (text-based).
2. Extract original English with physical page references.
3. Split study screen: primary source panel and handout panel.
4. Original English with its literal Arabic translation directly beneath each sentence.
5. Pre-lesson preparation: mental preparation, prerequisite concepts, teaching plan.
6. Simple start / pause / reset timer at the top.
7. **Manual** linking of handout passages to source passages.
8. View the original PDF page for any passage.
9. Passage-by-passage navigation through the handout; saved position.

**Explicitly not in the first usable version:** automatic matching, AI explanations and checkpoint questions (lesson loop), slides and scans support, dashboards, tasks, calendar, spaced repetition, drug encyclopedia, research tools.

---

## 6. Faithful literal translation (strict acceptance criterion)

**Rules**
- R1. Every extracted English sentence is preserved, in extraction order, exactly as extracted.
- R2. Its Arabic translation is placed **directly below that sentence**, then the next sentence follows.
- R3. Translation is literal and complete. **Never a summary, paraphrase, merge, or shortening.** The prompt forbids it and the checks below enforce it.
- R4. Uncertain extraction or uncertain translation is **flagged visibly**, never guessed or silently corrected.

**How the rules are enforced**
- *Segmentation is code, not AI.* A deterministic splitter handles abbreviations (e.g. "Fig.", "i.e.", "mg."), lists, headings, and table rows. Text it cannot split cleanly becomes a "fragment" unit. It is still translated. Nothing is dropped.
- *Completeness check (English):* joining all units of a passage (whitespace-normalized) must equal the passage's raw text. If not, processing fails and the passage is flagged.
- *Completeness check (Arabic):* the AI must return exactly one translation per unit ID. A missing, empty, or duplicated ID is flagged **"Translation missing — not shown as complete"**. A blank is never displayed.
- *Number / unit / term check:* every digit sequence, unit, and Latin-script technical term in the English must appear in the Arabic (Western digits kept). Failures are flagged "check numbers / terms".
- *Possible-omission check:* an Arabic-to-English length ratio outside the expected band, or an independent second AI pass that compares each pair and lists omitted or added content, flags the unit "possible omission or summary". Flagged units are shown with the original text and a warning. They are not auto-fixed.
- *Extraction-uncertainty flags:* garbled characters, broken ligatures or hyphenation, suspected wrong reading order (multi-column), low OCR confidence, and very short or empty pages are flagged "Check original page". The extracted text is still shown verbatim, and its translation is labelled "translated from uncertain text".
- *Label:* every translation is marked "machine translation, not reviewed" until you mark it reviewed. You can edit a translation; the edit is stored separately and the original machine output is kept.
- *Display rule:* no English sentence is ever displayed without either its Arabic translation or a visible reason it is missing.

**Honest limit:** no automated check can guarantee a perfect translation. The criterion is: nothing is dropped or summarized silently, every problem the checks can detect is visible, and you verify a sample (Section 12, items 14–20).

---

## 7. Matching: automatic and manual kept separate

| Label shown in the app | Meaning | When it exists |
|---|---|---|
| **Matching: not run** | No automatic matching has been performed | Default in first usable version |
| **Manual link** | You linked handout passage to source passage(s) yourself | Available from M1 |
| **Auto — verified text** | Automatic; code confirmed near-verbatim text overlap | Only after automatic matching is built and tested (M4) |
| **Auto — uncertain** | Automatic; evidence incomplete or failed a check | M4 |
| **Auto — rejected by you** / **Auto — confirmed by you** | Your decision on an automatic result | M4 |
| **No source match found** | Automatic run completed and found nothing valid | M4 |
| **Not linked** | Not matched and not run (first usable version) | Default |

**Rules**
- A visible banner on the study screen shows the matching state: "Automatic matching: not implemented" until M4 passes its tests, then "Run on N of M handout passages; X verified, Y uncertain, Z none".
- The app never says "matching complete" unless every handout passage has a recorded outcome and the M4 acceptance test has passed.
- Automatic and manual results are stored with their `method`, never mixed in counts.
- **Automatic matching design (M4, not built yet):** retrieve candidate passages (embeddings + keywords), AI judge chooses only from candidate IDs and quotes evidence, code validates IDs and checks quotes are real substrings, numbers and doses are compared, differences are typed and tied to validated text. Result is scored against a hand-built reference set from M0 before you rely on it.

**Page-reference rules:** a page number is stored only from the file's own page record, never from model memory; printed labels stay "unverified" until you confirm; "View original" opens the real PDF at the physical page.

---

## 8. Services, limitations, likely costs — by material type

**Prices are rough, from memory, and not verified today. M0 measures real figures on your samples. No money is committed before you see them.**

M0 will report, **separately for each of the three types**: extraction method used, text fidelity (checked against the rendered page image), page/slide reference reliability, reading order, tables/figures, limitations, and estimated processing cost (extraction + translation + pre-lesson planning, per page or slide and per lecture).

| Type | Likely method | Expected limitations | Likely extraction cost | Built in |
|---|---|---|---|---|
| **Text PDF** | Free parsing library (pdf.js / `unpdf`) | Two-column reading order, tables, hyphenation, headers/footers; figures and chemical structures are images, not text | Free | **M1** |
| **Slides** (PowerPoint file or slide PDF) | PPTX: read text per slide plus speaker notes (free). Slide PDF: one page = one slide | Fragmentary text, text inside images missing, hidden slides, animations; slide numbers may differ from file order | Free for text-based slides; image-only slides need OCR | **After M0 report** (tentatively M6) |
| **Scanned page / image** | A real OCR service (Google Document AI, Azure Read, or AWS Textract), with per-word confidence | OCR errors on poor photos, skew, handwriting, tables; needs a cloud account with billing | Typically around $1.50 per 1,000 pages for basic OCR; a few hundred pages is roughly under a dollar | **After M0 report** (tentatively M6) |

**M0 honesty notes:** I can inspect and extract your samples in my own workspace. If my workspace cannot run a given OCR engine, I will say so and report only what I could test, rather than assume. Cloud OCR quality cannot be confirmed without a small test on your own cloud account; the plan lists that as an optional step.

**Translation and planning (all types):** cost depends on sentence count. I will count real sentences and tokens in your sample, give a per-lecture estimate, and set a spending cap before M2. Cached results are never regenerated.

**Other services:** Supabase free tier to start (storage and file-size limits, pauses inactive projects; a textbook may need a paid plan, roughly $25/month). Vercel free tier to start (short function limits, hence page batching; roughly $20/month if upgraded). Embeddings for M4 cost very little; the Anthropic API has no embedding model, so M4 uses Supabase's built-in model or a second provider.

**Privacy:** passage text is sent to the AI provider. Check its current data-use terms before uploading anything.

---

## 9. Data model (first usable version)

- `documents` (owner, kind: source|handout, title, subject, file path, file type, status, page count)
- `document_pages` (document, physical index, printed label, label_verified, raw_text, extraction_method, quality flags)
- `passages` (document, page start/end, order, heading path, raw_text, extraction_flags)
- `units` (passage, index, english_text, kind: sentence|fragment) — English exactly as extracted
- `translations` (unit, arabic_text, model, prompt version, checks: complete / numbers / terms / omission, flags, reviewed_by_user, user_edit)
- `links` (handout passage, source passage, method: manual|auto, status, created_by, note)
- `lesson_plans` (handout, mental_prep, prerequisites, teaching_plan, each item labelled "from your documents" or "general background")
- `study_progress` (user, handout, current passage, last opened)
- `processing_jobs` (document, step, page cursor, status, error)

Added later: embeddings and auto-match tables (M4), explanation and question tables (M5), OCR and slide fields used by their providers (M6). No productivity tables yet.

## 10. Screens (first usable version)

1. Login (email code)
2. Library: documents, upload, processing status
3. Document check: original PDF page beside extracted text, quality flags, printed-label confirmation
4. Pre-lesson: mental preparation, prerequisites, teaching plan
5. **Study screen**
   - Top bar: timer with **Start / Pause / Reset** and elapsed time
   - Left panel: primary source. Right panel: handout. Portrait: stacked with a switch.
   - Each sentence: English original, Arabic literal translation directly below
   - Flags inline: "Check original page", "Translation missing", "Check numbers / terms", "Possible omission"
   - Link status per handout passage: "Manual link" or "Not linked", plus the matching banner (Section 7)
   - Source panel: manual page picker and "link this passage" action
   - Previous / Next handout passage; "View original page"

## 11. Real versus mockup

| Item | Status |
|---|---|
| Upload, login, storage, text-PDF extraction, page refs | **Real**, M1 |
| Split study screen, timer, original-page view, manual links | **Real**, M1 |
| Sentence segmentation + literal Arabic with checks | **Real**, M2 |
| Pre-lesson preparation and plan | **Real**, M3 |
| Automatic matching | **Not built** until M4; UI says so |
| Slide and scan processing | **Not built** until M6; M0 only tests feasibility |
| Optional layout preview in M0 | **MOCKUP**, fake text, bannered "MOCKUP — not functional" |

---

## 11A. Milestone by milestone: functional, not implemented, mockup

**Rule:** the app never shows invented sample content as if it were real. Anything not yet built is shown as a clearly labelled placeholder (for example "Arabic translation: not implemented yet"), never as fake output.

| Milestone | Functional (real, tested) | Not implemented (shown as a labelled placeholder or absent) | Mockup |
|---|---|---|---|
| **M0** | No app. Real inspection of your three sample types, feasibility report, cost estimates, reference set | The whole app | Optional layout preview, bannered "MOCKUP — not functional", fake text |
| **M1** | Login, install, upload of source and handout, text-PDF extraction with physical page references, passage structure, quality flags, document check, **split study screen with original English**, passage navigation, **manual links**, original-page view, **top timer**, saved position, retry of failed pages | Arabic line shows "Translation not implemented yet (M2)". Pre-lesson shows "Not implemented yet (M3)". Matching banner reads "Automatic matching: not implemented". Scanned or slide material is detected and reported as "not supported yet", not silently mis-read | None in the app |
| **M2** | Everything in M1, plus **sentence units and faithful literal Arabic directly below every English sentence**, with completeness, number/term and omission checks, flags, review and edit | Pre-lesson ("Not implemented yet (M3)"). Automatic matching. Slides and scans | None |
| **M3 = first usable version** | Everything in M2, plus **mental preparation, prerequisite concepts, and teaching plan** shown before the study screen, with source labels | Automatic matching ("not implemented"), AI lesson explanations and questions, slides and scans | None |
| **M4** | Adds **automatic matching**, labelled as automatic, with validation, reference-set scoring, and your confirm/reject | Lesson loop, slides and scans | None |
| **M5** | Adds AI explanations, Arabic explanation, checkpoint questions, high-yield notes, discrepancy recap | Slides and scans | None |
| **M6** | Adds slide and scanned-material support, as decided after M0 | Nothing from the core workflow | None |
| **M7** | Hardening: errors, retries, spending caps, backups, privacy | — | None |

---

## 12. Acceptance checklist — first usable version (end of M3)

The acceptance goal is the complete experience described in Section 4A. Every item below must pass.

Test material: the real text-PDF sample source and handout from M0. Every item is pass/fail. The version is not "usable" until all items pass.

**Upload and storage**
1. I can sign in on my iPad and install the app to the Home Screen.
2. I can upload a source PDF and a handout PDF from the iPad; both appear in the Library with a processing status.
3. Files are private: a second test account cannot see them.
4. If processing stops (iPad locked, connection lost), reopening the app resumes without restarting or losing pages.

**Extraction and page references**
5. Every page of both documents is processed, and the page count matches the PDF.
6. For 10 randomly chosen pages, extracted text matches the page image; every difference is either fixed in code or visibly flagged.
7. Each passage shows its physical PDF page; shown page numbers match the real PDF page every time.
8. Printed page labels are shown as "unverified" until I confirm them.
9. "View original page" opens the real PDF at the correct page for any passage.
10. Garbled, empty, or suspect-order pages show "Check original page". Nothing is silently corrected.

**Split study screen**
11. Source panel and handout panel are side by side in landscape and stacked with a switch in portrait.
12. The handout is walked through passage by passage with Previous / Next; the app reopens at my last position.
13. The source panel shows the source text I choose by page picker or manual link.

**Literal translation (Section 6)**
14. Every extracted English sentence of the handout is displayed, in extraction order, exactly as extracted. A code check shows the joined units equal the passage text, with zero mismatches.
15. Each English sentence has its Arabic translation directly below it, or a visible flag explaining why not. No sentence is shown without one or the other.
16. Unit and translation counts match exactly (N English units, N Arabic results). Any missing, duplicate, or empty result is flagged "Translation missing".
17. I read 30 randomly chosen sentence pairs. **Zero** are summaries, merges, or omissions of content, and any I find are flagged or fixed before approval.
18. Every number, unit, and technical term in the English appears in the Arabic; failures are flagged.
19. Every translation is labelled "machine translation, not reviewed" until I mark it reviewed; my edits are stored without overwriting the original output.
20. The same checks pass on source passages that are displayed in the source panel.

**Matching honesty**
21. The study screen banner reads "Automatic matching: not implemented".
22. A handout passage is either "Manual link" (created by me) or "Not linked". No result is labelled automatic, verified, or complete.
23. I can create, change, and remove a manual link, and the label updates correctly.

**Pre-lesson**
24. Before the study screen, I see mental preparation, prerequisite concepts, and a teaching plan for the handout.
25. The plan references every handout heading or passage (code-checked); none is missing.
26. Each plan item is labelled "from your documents" (with passage reference) or "general background"; no invented citations or page numbers.
27. The pre-lesson content is separate from the original text; it never replaces it.

**Timer**
28. A start / pause / reset timer is at the top of the study screen and stays visible.
29. Start, pause, and reset work; elapsed time stays correct after locking the iPad for 2 minutes and after switching apps.
30. Reset returns to 0:00 and requires nothing else.

**Safety and cost**
31. No secret key appears in the browser (checked in the delivered code and network requests).
32. Spending cap is set; translation and planning for the sample lecture cost within the estimate I approved.
33. Failed pages or units can be retried individually without redoing the whole document.

---

## 13. Revised milestone sequence

| Milestone | Deliverable | Test |
|---|---|---|
| **M0 — Feasibility + setup** (no app) | You send three samples: text PDF + handout, slide deck/PDF, scanned page/image. I report **per type**: extraction quality, page/slide references, limitations, processing cost estimate. I also build a small hand-checked reference matching for later testing and count real sentences and tokens for the translation estimate. Optional MOCKUP of the split screen. Accounts setup guide. **Decision point:** you approve the approach and when slides and scans get built | You read the report and decide |
| **M1 — Upload-to-study flow** | Items 1–13 and 28–31 of the checklist: login, upload, text-PDF extraction with physical page refs, document check, split study screen (English only), manual links, original-page view, top timer, saved position | Checklist items 1–13, 21–23, 28–31 |
| **M2 — Faithful literal Arabic** | Sentence units, translation with all Section 6 checks, flags, review/edit | Checklist items 14–20, 32–33 |
| **M3 — Pre-lesson** | Mental preparation, prerequisites, teaching plan with source labels | Checklist items 24–27 |
| **— First usable version (all 33 items pass) —** | | |
| **M4 — Automatic matching** | Retrieve, judge, validate; honest labels; differences; unmatched lists; match review; scored against the M0 reference set | Reference-set score; no invalid ID or quote passes; labels per Section 7 |
| **M5 — Lesson loop** | Passage-by-passage explanation (English and Arabic explanation), checkpoint questions, high-yield notes, discrepancy recap | One full lecture end to end |
| **M6 — Slides and scans** | Slide provider and OCR provider as chosen after M0, with low-confidence flags and the same checks | Slide deck and scanned pages pass the checklist items 5–10, 14–20 |
| **M7 — Hardening** | Error handling, retries, spending caps, backups, privacy check | Checklist pass |

**Deferred until the core study workflow works:** dashboard, task management, calendar and rescheduling, spaced repetition, reminders, mastery analytics, drug knowledge system, body systems and clinical pharmacy, research tools, curriculum map, Capacitor wrap.

## 14. Risks

- **Extraction problems on complex layouts, slides, or scans** → M0 tests all three; flags; document-check screen.
- **Silent translation loss** → deterministic segmentation, per-unit IDs, completeness and omission checks, 30-pair human review.
- **Overstating matching** → explicit `method`, honest labels, banner, no "complete" until tested.
- **Arabic medical wording errors** → literal policy, terms handling, reviewed flag, your edits.
- **Cost surprises** → measured in M0, spending cap, cached results.
- **Scope creep** → Section 5 exclusions and deferred list.

## 15. Next step

This version is the requirements baseline. M0 begins when you send the three sample files (Section 4, question 1) and answer the remaining questions in Section 4. M0 produces a report only. No app implementation begins before you have read the M0 report.
