import { publicConfig } from '../server/http';

// Tells the browser which Supabase project to talk to. Contains no secret.
export default function handler(_req: any, res: any) {
  const r = publicConfig(process.env as any);
  res.statusCode = r.status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(r.json));
}
