import { preLessonHandler } from '../server/http';
export default preLessonHandler;
