import { translateHandler } from '../server/http';
export default translateHandler;
