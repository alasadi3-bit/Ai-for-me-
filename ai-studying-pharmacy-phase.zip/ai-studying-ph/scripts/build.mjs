// Build step (runs on Vercel after `npm install`, or locally with `node scripts/build.mjs`).
// No bundler: it
//   1. transpiles src/lib/*.ts to browser ES modules in public/lib/ (type stripping only),
//   2. copies pdf.js (reader + worker) into public/vendor/,
//   3. writes public/build-info.json.
// The page code in public/app/ is plain JavaScript that imports those modules directly.
import { createRequire } from 'node:module';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const pub = join(root, 'public');

function loadTypeScript() {
  try {
    return require('typescript');
  } catch {
    // Local sandbox fallback only: a globally installed copy.
    const g = process.env.TS_FALLBACK_DIR;
    if (g && existsSync(g)) return require(g);
    throw new Error('The "typescript" package is not installed. Run `npm install` first.');
  }
}
const ts = loadTypeScript();

// 1. src/lib/*.ts -> public/lib/*.js
const outLib = join(pub, 'lib');
rmSync(outLib, { recursive: true, force: true });
mkdirSync(outLib, { recursive: true });
const srcLib = join(root, 'src/lib');
let count = 0;
for (const f of readdirSync(srcLib)) {
  if (!f.endsWith('.ts')) continue;
  const input = readFileSync(join(srcLib, f), 'utf8');
  const out = ts.transpileModule(input, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, verbatimModuleSyntax: false },
    fileName: f,
  });
  // Browsers need explicit extensions on relative imports.
  const js = out.outputText.replace(/(from\s+['"])(\.{1,2}\/[^'"]+?)(['"])/g, (m, a, spec, c) => (/\.[a-z]+$/i.test(spec) ? m : `${a}${spec}.js${c}`));
  writeFileSync(join(outLib, f.replace(/\.ts$/, '.js')), js);
  count++;
}
console.log(`[build] transpiled ${count} modules to public/lib`);

// 2. pdf.js
const vendor = join(pub, 'vendor');
mkdirSync(vendor, { recursive: true });
// The LEGACY build comes first on purpose: the modern build needs very recent JavaScript features
// (for example Map.prototype.getOrInsertComputed) that older iPad Safari versions do not have, which makes
// pages fail to read or render. The legacy build bundles the needed fallbacks. The modern build is only a fallback.
const pdfDirs = ['node_modules/pdfjs-dist/legacy/build', 'node_modules/pdfjs-dist/build'].map((d) => join(root, d));
const base = pdfDirs.find((d) => existsSync(join(d, 'pdf.min.mjs')) && existsSync(join(d, 'pdf.worker.min.mjs')));
if (!base) {
  console.error('[build] pdfjs-dist not found. Run `npm install` first.');
  process.exit(1);
}
cpSync(join(base, 'pdf.min.mjs'), join(vendor, 'pdf.min.mjs'));
cpSync(join(base, 'pdf.worker.min.mjs'), join(vendor, 'pdf.worker.min.mjs'));
console.log('[build] copied pdf.js from', base);

// 3. build info
writeFileSync(join(pub, 'build-info.json'), JSON.stringify({ builtAt: new Date().toISOString() }));
console.log('[build] done');
