"""Generate small test PDFs (original text, no third-party content).

Run:  python3 scripts/make-fixtures.py
Writes tests/fixtures/{source,handout,scanned}.pdf. These are used only by the
automated tests; they are not part of the shipped app.
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(__file__), '..', 'tests', 'fixtures')
os.makedirs(OUT, exist_ok=True)
W, H = A4


def lines(c, x, y, rows, size=10.5, leading=14):
    c.setFont('Helvetica', size)
    for r in rows:
        c.drawString(x, y, r)
        y -= leading
    return y


def footer(c, label):
    c.setFont('Helvetica', 9)
    c.drawString(W / 2 - 4, 30, label)


# ----------------------------------------------------------------- source.pdf
c = canvas.Canvas(os.path.join(OUT, 'source.pdf'), pagesize=A4)

# page 1: headings, paragraphs, hyphenation, printed page label 43
c.setFont('Helvetica-Bold', 20)
c.drawString(72, H - 90, 'Chapter 3: Anti-inflammatory Drugs')
c.setFont('Helvetica-Bold', 14)
c.drawString(72, H - 125, '3.1 Aspirin')
y = lines(c, 72, H - 155, [
    'Aspirin irreversibly inhibits cyclooxygenase, an enzyme needed for prostaglandin',
    'synthesis. The inhibi-',
    'tion of platelet cyclooxygenase lasts for the life of the platelet. Low-dose aspirin',
    'is commonly 75 to 100 mg daily.',
])
y -= 14
y = lines(c, 72, y, [
    'Common adverse effects include gastric irritation and bleeding. Patients with',
    'asthma may react badly, e.g. with bronchospasm. See Fig. 2 for the pathway.',
])
footer(c, '43')
c.showPage()

# page 2: list items, numbers and units, acronyms
c.setFont('Helvetica-Bold', 14)
c.drawString(72, H - 90, '3.2 Dosing and Selectivity')
y = lines(c, 72, H - 120, [
    'The antiplatelet dose is 75 mg once daily. The analgesic dose is 300 to 900 mg',
    'every 4 to 6 hours. Doses above 4 g per day are not recommended.',
])
y -= 14
y = lines(c, 72, y, [
    '• COX-1 inhibition reduces thromboxane A2 in platelets.',
    '• COX-2 inhibition reduces inflammatory prostaglandins.',
    '• The ratio of 0.5 mg/kg applies to children only when prescribed.',
])
footer(c, '44')
c.showPage()

# page 3: two columns, text stream order = left column then right column
c.setFont('Helvetica-Bold', 14)
c.drawString(72, H - 90, '3.3 Comparison')
yl = lines(c, 72, H - 120, [
    'Left column paragraph one starts here and',
    'continues for a second line of text.',
], size=10.5)
yr = lines(c, 320, H - 120, [
    'Right column paragraph begins here and',
    'also continues for a second line.',
], size=10.5)
footer(c, '45')
c.showPage()

# page 4: image-only page (no text layer)
c.setFillGray(0.8)
c.rect(100, 300, 300, 200, fill=1)
c.showPage()
c.save()

# --------------------------------------------------------------- handout.pdf
c = canvas.Canvas(os.path.join(OUT, 'handout.pdf'), pagesize=A4)
c.setFont('Helvetica-Bold', 22)
c.drawString(72, H - 90, 'Lecture 5: Aspirin')
c.setFont('Helvetica-Bold', 15)
c.drawString(72, H - 130, 'Mechanism')
y = lines(c, 72, H - 160, [
    'Aspirin irreversibly inhibits cyclooxygenase (COX).',
    'Platelets cannot make new enzyme.',
], size=12, leading=17)
c.setFont('Helvetica-Bold', 15)
c.drawString(72, y - 20, 'Dose')
lines(c, 72, y - 50, [
    'Antiplatelet dose: 75 mg once daily.',
], size=12, leading=17)
footer(c, '1')
c.showPage()
c.save()

# -------------------------------------------------------------- scanned.pdf
img = Image.new('RGB', (1240, 1754), 'white')
d = ImageDraw.Draw(img)
d.text((120, 200), 'This page is a picture of text, not real text.', fill='black')
img_path = os.path.join(OUT, '_scan.png')
img.save(img_path)
c = canvas.Canvas(os.path.join(OUT, 'scanned.pdf'), pagesize=A4)
for _ in range(3):
    c.drawImage(img_path, 0, 0, width=W, height=H)
    c.showPage()
c.save()
os.remove(img_path)
print('fixtures written to', os.path.abspath(OUT))
