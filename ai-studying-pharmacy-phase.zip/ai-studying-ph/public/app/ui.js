import { h } from './dom.js';
import { FLAG_LABELS } from '/lib/translation.js';

// Flags raised while extracting text from the PDF.
export const EXTRACTION_FLAGS = {
  garbled: ['warn', 'Garbled characters were found in the extracted text'],
  garbled_font: ['warn', 'The PDF font produced unreadable characters'],
  low_text_quality: ['warn', 'The extracted text has low quality'],
  no_text_layer: ['warn', 'This page has no extractable text'],
  order_jump_or_columns: ['warn', 'The reading order may be wrong (columns or layout)'],
  possible_table_or_columns: ['warn', 'This may be a table or multi-column layout'],
  extraction_failed: ['warn', 'Extraction failed for this page'],
  sentence_split_fallback: ['warn', 'Sentences could not be split reliably here'],
  dehyphenated: ['info', 'A hyphenated line break was joined'],
  continues_previous_page: ['info', 'Continues from the previous page'],
  continues_next_page: ['info', 'Continues on the next page'],
  page_number_line_excluded: ['info', 'A page-number line was left out of the paragraphs'],
};

export function isWarning(flag) {
  const info = EXTRACTION_FLAGS[flag];
  return !info || info[0] === 'warn';
}
export function flagText(flag) {
  return EXTRACTION_FLAGS[flag]?.[1] ?? FLAG_LABELS[flag] ?? flag.replace(/_/g, ' ');
}

export function badge(text, tone = 'neutral', title) {
  return h('span', { class: `badge badge-${tone}`, title }, text);
}

export function notice(tone, ...children) {
  return h('div', { class: `notice notice-${tone}`, role: tone === 'error' ? 'alert' : 'status' }, ...children);
}

export function button(label, onClick, { kind = 'secondary', disabled = false, title, pressed } = {}) {
  return h(
    'button',
    { type: 'button', class: `btn btn-${kind}`, onclick: onClick, disabled, title, 'aria-pressed': pressed === undefined ? undefined : String(pressed) },
    label,
  );
}

export function spinner(label) {
  return h('div', { class: 'loading', role: 'status' }, h('span', { class: 'spin', 'aria-hidden': 'true' }), label);
}

export function pageRef(kind, pageIndex, printedLabel) {
  const base = `${kind} PDF page ${pageIndex}`;
  return printedLabel ? `${base} (printed ${printedLabel}, unverified)` : base;
}

export function errorMessage(e) {
  return e instanceof Error ? e.message : String(e);
}
