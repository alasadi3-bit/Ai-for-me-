import { h, mount } from './dom.js';
import { notice, button, errorMessage } from './ui.js';
import { sendCode, verifyCode } from './api.js';

export function setupNeededScreen(root, cfg) {
  mount(
    root,
    h('main', { class: 'page narrow' },
      h('h1', null, 'AI for Studying Pharmacy'),
      notice('warn', h('strong', null, 'The server is not configured yet.')),
      h('p', null, 'Nothing can be uploaded or saved until these environment variables are set in Vercel (Project, Settings, Environment Variables), followed by a redeploy:'),
      h('ul', null,
        h('li', null, h('code', null, 'SUPABASE_URL'), cfg.supabaseUrl ? ' (set)' : ' (missing)'),
        h('li', null, h('code', null, 'SUPABASE_ANON_KEY'), cfg.supabaseAnonKey ? ' (set)' : ' (missing)'),
        h('li', null, h('code', null, 'ANTHROPIC_API_KEY'), cfg.aiConfigured ? ' (set)' : ' (missing; needed for Arabic translation and the pre-lesson)'),
      ),
      h('p', { class: 'muted' }, 'See README.md, "Setup on an iPad".'),
    ),
  );
}

export function signInScreen(root, { onSignedIn, message }) {
  let email = '';
  let stage = 'email';
  let busy = false;
  let error = message || '';
  let info = '';

  const render = () => {
    const emailInput = h('input', {
      type: 'email', inputmode: 'email', autocomplete: 'email', autocapitalize: 'off', required: true,
      placeholder: 'you@example.com', value: email, disabled: stage === 'code' || busy, 'aria-label': 'Email address',
    });
    const codeInput = h('input', {
      type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: 'Code from the email',
      'aria-label': 'Sign-in code', maxlength: '12',
    });
    const submit = async (ev) => {
      ev.preventDefault();
      if (busy) return;
      error = '';
      info = '';
      busy = true;
      render();
      try {
        if (stage === 'email') {
          email = emailInput.value.trim();
          await sendCode(email);
          stage = 'code';
          info = `A sign-in email was sent to ${email}. Enter the code it contains.`;
        } else {
          await verifyCode(email, codeInput.value);
          busy = false;
          onSignedIn();
          return;
        }
      } catch (e) {
        error = errorMessage(e);
      }
      busy = false;
      render();
    };
    mount(
      root,
      h('main', { class: 'page narrow' },
        h('h1', null, 'AI for Studying Pharmacy'),
        h('p', { class: 'muted' }, 'Sign in with a one-time code sent to your email.'),
        error && notice('error', error),
        info && notice('info', info),
        h('form', { class: 'stack', onsubmit: submit },
          emailInput,
          stage === 'code' && codeInput,
          h('button', { type: 'submit', class: 'btn btn-primary', disabled: busy }, busy ? 'Please wait...' : stage === 'email' ? 'Send code' : 'Sign in'),
          stage === 'code' && button('Use a different email', () => { stage = 'email'; error = ''; info = ''; render(); }),
        ),
        h('p', { class: 'muted small' }, 'If the email contains a link but no code, the Supabase email template must include {{ .Token }}. See README.md.'),
      ),
    );
    (stage === 'email' ? emailInput : codeInput).focus?.();
  };
  render();
}
