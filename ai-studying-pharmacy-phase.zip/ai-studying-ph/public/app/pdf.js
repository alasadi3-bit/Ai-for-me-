// pdf.js loading, per-document caching, and rendering one original page to a canvas.
import { downloadFile } from './api.js';

let pdfjsPromise = null;
function loadPdfjs() {
  if (!pdfjsPromise) {
    pdfjsPromise = import('/vendor/pdf.min.mjs').then((m) => {
      m.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.mjs';
      return m;
    });
  }
  return pdfjsPromise;
}

const bytesCache = new Map(); // documentId -> Uint8Array (kept for this tab only)
const docCache = new Map(); // documentId -> pdf.js document

export function rememberBytes(documentId, bytes) {
  bytesCache.set(documentId, bytes);
}

export async function openDocument(documentId, storagePath) {
  if (docCache.has(documentId)) return docCache.get(documentId);
  let bytes = bytesCache.get(documentId);
  if (!bytes) {
    bytes = await downloadFile(storagePath);
    bytesCache.set(documentId, bytes);
  }
  const pdfjs = await loadPdfjs();
  // pdf.js takes ownership of the buffer it is given, so hand it a copy.
  const doc = await pdfjs.getDocument({ data: bytes.slice(0), isEvalSupported: false }).promise;
  docCache.set(documentId, doc);
  return doc;
}

export async function renderPage(doc, pageNumber, canvas, maxWidth) {
  const page = await doc.getPage(pageNumber);
  const base = page.getViewport({ scale: 1 });
  const scale = Math.min(2.2, Math.max(0.5, maxWidth / base.width));
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const viewport = page.getViewport({ scale: scale * dpr });
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);
  canvas.style.width = `${Math.floor(viewport.width / dpr)}px`;
  canvas.style.height = `${Math.floor(viewport.height / dpr)}px`;
  await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
}
