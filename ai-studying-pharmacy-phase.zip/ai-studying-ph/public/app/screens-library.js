import { h, mount } from './dom.js';
import { badge, button, notice, errorMessage } from './ui.js';
import { currentUser, db, loadProfile, signOut } from './api.js';
import { createDocument, processDocument, retryFailedPages } from './processing.js';

const STATUS_TONE = { uploaded: 'neutral', processing: 'info', processed: 'ok', failed: 'error', unsupported: 'warn' };
const STATUS_TEXT = {
  uploaded: 'Uploaded, not processed yet',
  processing: 'Processing',
  processed: 'Processed',
  failed: 'Failed',
  unsupported: 'Not supported',
};

export async function libraryScreen(root, { cfg, navigate, onSignedOut }) {
  const state = {
    docs: [],
    failedCounts: new Map(),
    pages: new Map(), // docId -> [{page_index,status,error}]
    openDetails: new Set(),
    profile: null,
    progress: new Map(), // docId -> {done,total,failed}
    busy: new Set(),
    errors: new Map(), // docId or 'upload-source'/'upload-handout' -> message
    loadError: '',
    pick: { handout: '', source: '' },
  };
  const stops = new Map();
  const uploadInputs = {};
  pageStateRef = state;

  async function reload() {
    try {
      state.docs = await db.getAll('documents?select=id,kind,title,file_name,storage_path,status,status_message,pages_total,pages_done,created_at&order=created_at.desc');
      const allPages = await db.getAll('document_pages?select=document_id,page_index,status,error&order=page_index.asc');
      state.failedCounts = new Map();
      state.pages = new Map();
      for (const f of allPages) {
        if (!state.pages.has(f.document_id)) state.pages.set(f.document_id, []);
        state.pages.get(f.document_id).push(f);
        if (f.status === 'failed') state.failedCounts.set(f.document_id, (state.failedCounts.get(f.document_id) ?? 0) + 1);
      }
      state.profile = await loadProfile();
      state.loadError = '';
    } catch (e) {
      state.loadError = errorMessage(e);
    }
    render();
  }

  async function run(doc, fn) {
    if (state.busy.has(doc.id)) return;
    state.busy.add(doc.id);
    state.errors.delete(doc.id);
    render();
    try {
      await fn();
    } catch (e) {
      state.errors.set(doc.id, errorMessage(e));
    }
    state.busy.delete(doc.id);
    state.progress.delete(doc.id);
    await reload();
  }

  const onProgress = (doc) => (p) => {
    state.progress.set(doc.id, p);
    render();
  };

  async function upload(kind, fileInput, titleInput) {
    const key = `upload-${kind}`;
    const file = fileInput.files?.[0];
    state.errors.delete(key);
    if (!file) {
      state.errors.set(key, 'Choose a PDF file first.');
      render();
      return;
    }
    state.busy.add(key);
    render();
    let doc = null;
    try {
      doc = await createDocument(kind, file, titleInput.value.trim());
    } catch (e) {
      state.errors.set(key, errorMessage(e));
    }
    state.busy.delete(key);
    await reload();
    if (doc) {
      const row = state.docs.find((d) => d.id === doc.id) ?? doc;
      await run(row, async () => {
        await processDocument(row, { onProgress: onProgress(row), shouldStop: () => stops.get(row.id) === true });
      });
    }
  }

  function uploadCard(kind, label, help) {
    const key = `upload-${kind}`;
    // The inputs are created once and re-used on every render. Re-creating them would silently drop a
    // file the student already chose whenever the screen refreshes (for example when the document
    // list finishes loading a moment after the file was picked).
    if (!uploadInputs[kind]) {
      uploadInputs[kind] = {
        fileInput: h('input', { type: 'file', accept: 'application/pdf,.pdf', 'aria-label': `${label} PDF file` }),
        titleInput: h('input', { type: 'text', placeholder: 'Title (optional)', 'aria-label': `${label} title` }),
      };
    }
    const { fileInput, titleInput } = uploadInputs[kind];
    const busy = state.busy.has(key);
    return h('section', { class: 'card' },
      h('h3', null, label),
      h('p', { class: 'muted small' }, help),
      state.errors.get(key) && notice('error', state.errors.get(key)),
      h('div', { class: 'stack' }, fileInput, titleInput,
        h('button', { type: 'button', class: 'btn btn-primary', disabled: busy, onclick: () => upload(kind, fileInput, titleInput) }, busy ? 'Uploading...' : `Upload ${label.toLowerCase()}`)),
    );
  }

  function docRow(doc) {
    const prog = state.progress.get(doc.id);
    const busy = state.busy.has(doc.id);
    const failedCount = state.failedCounts.get(doc.id) ?? 0;
    const pct = prog ? Math.round((prog.done / prog.total) * 100) : doc.pages_total ? Math.round(((doc.pages_done ?? 0) / doc.pages_total) * 100) : 0;
    const canProcess = (doc.status === 'uploaded' || doc.status === 'processing' || doc.status === 'failed') && !busy;
    return h('li', { class: 'docrow', 'data-doc-id': doc.id },
      h('div', { class: 'docrow-head' },
        h('strong', null, doc.title),
        badge(doc.kind === 'source' ? 'Primary source' : 'Lecture handout', 'neutral'),
        badge(busy && prog ? 'Processing' : (doc.status === 'processed' && failedCount > 0 ? 'Processed with errors' : STATUS_TEXT[doc.status] ?? doc.status), busy ? 'info' : (doc.status === 'processed' && failedCount > 0 ? 'warn' : STATUS_TONE[doc.status] ?? 'neutral')),
      ),
      h('div', { class: 'muted small' }, doc.file_name, pageSummary(doc)),
      pageResults(doc),
      (busy || doc.status === 'processing') && doc.pages_total
        ? h('div', { class: 'progress', role: 'progressbar', 'aria-valuenow': pct, 'aria-valuemin': 0, 'aria-valuemax': 100 }, h('div', { class: 'progress-bar', style: `width:${pct}%` }))
        : null,
      doc.status_message && notice(doc.status === 'unsupported' || doc.status === 'failed' ? 'warn' : 'info', doc.status_message),
      state.errors.get(doc.id) && notice('error', state.errors.get(doc.id)),
      h('div', { class: 'row gap' },
        canProcess && button(doc.status === 'uploaded' ? 'Process' : doc.status === 'failed' ? 'Retry' : 'Resume', () =>
          run(doc, () => processDocument(doc, { onProgress: onProgress(doc), shouldStop: () => stops.get(doc.id) === true }))),
        busy && prog && button('Pause', () => stops.set(doc.id, true)),
        failedCount > 0 && !busy && button(`Retry failed pages (${failedCount})`, () => run(doc, () => retryFailedPages(doc, onProgress(doc)))),
      ),
    );
  }

  function pairPicker() {
    const ready = (kind) => state.docs.filter((d) => d.kind === kind && d.status === 'processed');
    const handouts = ready('handout');
    const sources = ready('source');
    if (!state.pick.handout || !handouts.some((d) => d.id === state.pick.handout)) state.pick.handout = handouts[0]?.id ?? '';
    if (state.pick.source && !sources.some((d) => d.id === state.pick.source)) state.pick.source = '';
    if (!state.pick.source && sources[0]) state.pick.source = sources[0].id;
    const hSel = h('select', { 'aria-label': 'Lecture handout', onchange: (e) => (state.pick.handout = e.target.value) },
      handouts.map((d) => h('option', { value: d.id, selected: d.id === state.pick.handout }, d.title)));
    const sSel = h('select', { 'aria-label': 'Primary source', onchange: (e) => (state.pick.source = e.target.value) },
      h('option', { value: '' }, 'No primary source (handout only)'),
      sources.map((d) => h('option', { value: d.id, selected: d.id === state.pick.source }, d.title)));
    return h('section', { class: 'card card-accent' },
      h('h3', null, 'Study a lesson'),
      !handouts.length
        ? h('p', { class: 'muted' }, 'Upload and process a lecture handout first. A primary source is recommended.')
        : h('div', { class: 'stack' },
            h('label', null, 'Lecture handout (defines the scope)', hSel),
            h('label', null, 'Primary source (main learning material)', sSel),
            h('button', { type: 'button', class: 'btn btn-primary', onclick: () => navigate(`#/prelesson/${state.pick.handout}/${state.pick.source || 'none'}`) }, 'Prepare lesson'),
            h('button', { type: 'button', class: 'btn btn-secondary', onclick: () => navigate(`#/study/${state.pick.handout}/${state.pick.source || 'none'}`) }, 'Go straight to the study screen'),
          ),
    );
  }

  function render() {
    const user = currentUser();
    mount(
      root,
      h('header', { class: 'topbar' },
        h('h1', { class: 'title' }, 'Library'),
        h('div', { class: 'row gap' }, h('span', { class: 'muted small' }, (user?.email ?? '') + (state.profile ? ` \u00b7 ${state.profile.role === 'admin' ? 'Administrator' : 'Student'}` : '')), button('Sign out', () => { signOut(); onSignedOut(); })),
      ),
      h('main', { class: 'page' },
        !cfg.aiConfigured && notice('warn', 'AI is not configured on the server (ANTHROPIC_API_KEY is missing). Uploading and reading work, but Arabic translation and the pre-lesson will not.'),
        state.loadError && notice('error', state.loadError, ' ', button('Retry', reload)),
        h('div', { class: 'grid2' },
          uploadCard('source', 'Primary source', 'The detailed textbook or reference. Text-based PDF only for now.'),
          uploadCard('handout', 'Lecture handout', 'The lecturer’s slides or summary, exported as a text-based PDF.'),
        ),
        pairPicker(),
        h('h2', null, 'Your documents'),
        state.docs.length ? h('ul', { class: 'doclist' }, state.docs.map(docRow)) : h('p', { class: 'muted' }, 'No documents yet.'),
      ),
    );
  }

  render();
  await reload();
  // A document left in "processing" by an interrupted session is offered for Resume, never resumed silently.
}

let pageStateRef = { pages: new Map(), openDetails: new Set() };
function pageCounts(docId) {
  const rows = pageStateRef.pages.get(docId) ?? [];
  return { rows, ok: rows.filter((r) => r.status === 'ok').length, empty: rows.filter((r) => r.status === 'empty').length, failed: rows.filter((r) => r.status === 'failed').length };
}
function pageSummary(doc) {
  const c = pageCounts(doc.id);
  if (!c.rows.length) return doc.pages_total ? ` \u00b7 ${doc.pages_total} pages, none read yet` : '';
  const total = doc.pages_total ?? c.rows.length;
  return ` \u00b7 ${total} pages: ${c.ok} text extracted, ${c.empty} empty, ${c.failed} extraction error${c.failed === 1 ? '' : 's'}` + (c.rows.length < total ? `, ${total - c.rows.length} not read yet` : '');
}
const RESULT = {
  ok: ['Text extracted', 'ok'],
  empty: ['Empty page (no text)', 'warn'],
  failed: ['Extraction error', 'error'],
};
function pageResults(doc) {
  const c = pageCounts(doc.id);
  if (!c.rows.length) return null;
  const d = h('details', { class: 'pageresults', open: c.failed > 0 || doc.status === 'unsupported' || pageStateRef.openDetails.has(doc.id) },
    h('summary', null, `Page results (${c.rows.length})`),
    h('ul', { class: 'pagelist' }, c.rows.map((r) => {
      const [label, tone] = r.status === 'empty' && doc.status === 'unsupported' ? ['Unsupported: scanned / image page', 'warn'] : (RESULT[r.status] ?? [r.status, 'neutral']);
      return h('li', { class: 'pagerow' }, h('span', null, `Page ${r.page_index}`), badge(label, tone),
        r.status === 'failed' ? h('span', { class: 'muted small pageerr' }, r.error || 'unknown error') : null);
    })));
  d.addEventListener('toggle', () => { if (d.open) pageStateRef.openDetails.add(doc.id); else pageStateRef.openDetails.delete(doc.id); });
  return d;
}
