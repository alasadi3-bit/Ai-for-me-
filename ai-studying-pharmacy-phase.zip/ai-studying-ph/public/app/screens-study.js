import { h, mount, clear } from './dom.js';
import { badge, button, notice, spinner, errorMessage, flagText, isWarning, pageRef } from './ui.js';
import { callServer, currentUser, db, getByIds } from './api.js';
import { openDocument, renderPage } from './pdf.js';
import { elapsedMs, formatElapsed, initialTimer, isRunning, parse, pause, pickNewer, reset, serialize, start } from '/lib/timer.js';

const PASSAGE_COLS = 'id,document_id,page_index,seq,kind,heading_path,flags';

export async function studyScreen(root, { handoutId, sourceId, cfg, navigate }) {
  mount(root, h('main', { class: 'page' }, spinner('Opening your study screen...')));

  // ---------------------------------------------------------------- load
  let hDoc, sDoc = null, hPages, sPages = new Map(), hPassages, links, progress;
  try {
    [hDoc] = await db.get(`documents?id=eq.${handoutId}&select=id,title,storage_path,status,pages_total`);
    if (!hDoc) throw new Error('That handout was not found.');
    if (sourceId) {
      [sDoc] = await db.get(`documents?id=eq.${sourceId}&select=id,title,storage_path,status,pages_total`);
      if (!sDoc) throw new Error('That primary source was not found.');
    }
    const pageMap = async (docId) =>
      new Map((await db.getAll(`document_pages?document_id=eq.${docId}&select=page_index,printed_label,status,flags`)).map((p) => [p.page_index, p]));
    hPages = await pageMap(handoutId);
    if (sDoc) sPages = await pageMap(sourceId);
    hPassages = await db.getAll(`passages?document_id=eq.${handoutId}&select=${PASSAGE_COLS}&order=page_index.asc,seq.asc`);
    const hIds = new Set(hPassages.map((p) => p.id));
    links = (await db.getAll('links?select=id,handout_passage_id,source_passage_id,method,status')).filter((l) => hIds.has(l.handout_passage_id));
    [progress] = await db.get(`study_progress?handout_id=eq.${handoutId}&select=*`);
  } catch (e) {
    mount(root,
      h('header', { class: 'topbar' }, button('Library', () => navigate('#/library'))),
      h('main', { class: 'page' }, notice('error', errorMessage(e)), button('Try again', () => navigate(location.hash || '#/library'))));
    return () => {};
  }
  if (!hPassages.length) {
    mount(root,
      h('header', { class: 'topbar' }, button('Library', () => navigate('#/library'))),
      h('main', { class: 'page' }, notice('warn', 'This handout has no extracted passages, so there is nothing to study. Check the document in the Library.')));
    return () => {};
  }

  // --------------------------------------------------------------- state
  const user = currentUser();
  let idx = Math.min(Math.max(progress?.passage_index ?? 0, 0), hPassages.length - 1);
  let srcMode = 'linked';
  let srcPage = progress?.source_page ?? 1;
  const timerKey = `aisph.timer.${handoutId}`;
  let remoteTimer = progress
    ? { accumulatedMs: Number(progress.timer_accumulated_ms) || 0, startedAt: progress.timer_started_at ? Date.parse(progress.timer_started_at) : null }
    : initialTimer;
  let localTimer = initialTimer;
  try { localTimer = parse(localStorage.getItem(timerKey)); } catch { /* storage blocked */ }
  let timer = pickNewer(localTimer, remoteTimer, Date.now());
  let activeTab = 'handout';
  let disposed = false;

  // ------------------------------------------------------------ persistence
  const saveState = h('span', { class: 'muted small', 'aria-live': 'polite' });
  let saveTimer = null;
  const setSaved = (text, tone) => { saveState.textContent = text; saveState.className = `small ${tone === 'error' ? 'text-error' : 'muted'}`; };

  async function saveNow() {
    try {
      localStorage.setItem(timerKey, serialize(timer));
    } catch { /* ignore */ }
    try {
      await db.upsert('study_progress', {
        owner: user.id, handout_id: handoutId, source_id: sourceId ?? null, passage_index: idx, source_page: srcPage,
        timer_accumulated_ms: Math.round(timer.accumulatedMs),
        timer_started_at: timer.startedAt ? new Date(timer.startedAt).toISOString() : null,
        updated_at: new Date().toISOString(),
      }, 'owner,handout_id');
      setSaved('Progress saved', 'ok');
    } catch (e) {
      setSaved(`Not saved: ${errorMessage(e)}`, 'error');
    }
  }
  function saveSoon(ms = 700) {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNow, ms);
  }

  // ----------------------------------------------------------------- timer
  const clock = h('output', { class: 'clock', 'aria-label': 'Study timer', 'aria-live': 'off' });
  const startBtn = button('Start', () => { timer = start(timer, Date.now()); paint(); saveNow(); }, { kind: 'primary' });
  const pauseBtn = button('Pause', () => { timer = pause(timer, Date.now()); paint(); saveNow(); });
  const resetBtn = button('Reset', () => { timer = reset(); paint(); saveNow(); });
  function paint() {
    clock.textContent = formatElapsed(elapsedMs(timer, Date.now()));
    startBtn.disabled = isRunning(timer);
    pauseBtn.disabled = !isRunning(timer);
    clock.classList.toggle('running', isRunning(timer));
  }
  const tick = setInterval(paint, 500);
  const onVisible = () => paint();
  document.addEventListener('visibilitychange', onVisible);
  window.addEventListener('pageshow', onVisible);
  const onHide = () => { if (document.visibilityState === 'hidden') saveNow(); };
  document.addEventListener('visibilitychange', onHide);

  // ------------------------------------------------- original page viewer
  function showOriginal(doc, pageIndex) {
    let current = pageIndex;
    const total = doc.pages_total || current;
    const canvas = h('canvas', { class: 'pdfcanvas', role: 'img', 'aria-label': 'Original PDF page' });
    const status = h('div', { class: 'muted small', 'aria-live': 'polite' });
    const label = h('strong', null);
    const overlay = h('div', { class: 'overlay', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Original PDF page' });
    const close = () => overlay.remove();
    async function draw() {
      label.textContent = `${doc.title}: PDF page ${current} of ${total}`;
      status.textContent = 'Loading the original page...';
      try {
        const pdf = await openDocument(doc.id, doc.storage_path);
        await renderPage(pdf, current, canvas, Math.min(window.innerWidth - 32, 900));
        status.textContent = '';
      } catch (e) {
        status.textContent = `Could not show this page: ${errorMessage(e)}`;
        status.className = 'text-error small';
      }
    }
    overlay.append(
      h('div', { class: 'overlay-bar' },
        label,
        h('div', { class: 'row gap' },
          button('Previous page', () => { if (current > 1) { current--; draw(); } }),
          button('Next page', () => { if (current < total) { current++; draw(); } }),
          button('Close', close, { kind: 'primary' }))),
      status,
      h('div', { class: 'overlay-body' }, canvas));
    overlay.addEventListener('keydown', (e) => e.key === 'Escape' && close());
    document.body.append(overlay);
    draw();
  }

  // -------------------------------------------------------------- translation
  const attempts = new Map(); // passageId -> {state, message, failed:Map}
  const inflight = new Map();

  function translatePassage(passageId) {
    if (inflight.has(passageId)) return inflight.get(passageId);
    const p = (async () => {
      try {
        const res = await callServer('translate', { passageId });
        const failed = new Map((res.failed ?? []).map((f) => [f.unitId, f.reason]));
        attempts.set(passageId, { state: failed.size ? 'partial' : 'done', failed });
      } catch (e) {
        attempts.set(passageId, { state: 'error', message: errorMessage(e), failed: new Map() });
      } finally {
        inflight.delete(passageId);
      }
    })();
    inflight.set(passageId, p);
    return p;
  }

  async function loadTranslations(units) {
    const trs = units.length ? await getByIds('translations', 'unit_id', units.map((u) => u.id), 'id,unit_id,machine_text,flags,checks,model,created_at') : [];
    const latest = new Map();
    for (const t of trs.sort((a, b) => (a.created_at < b.created_at ? 1 : -1))) if (!latest.has(t.unit_id)) latest.set(t.unit_id, t);
    const edits = latest.size ? await getByIds('translation_edits', 'translation_id', [...latest.values()].map((t) => t.id), 'id,translation_id,edited_text,created_at') : [];
    const latestEdit = new Map();
    for (const e of edits.sort((a, b) => (a.created_at < b.created_at ? 1 : -1))) if (!latestEdit.has(e.translation_id)) latestEdit.set(e.translation_id, e);
    return { latest, latestEdit };
  }

  // --------------------------------------------------------- passage view
  function passageView(passage, doc, pagesMap, { actions = [] } = {}) {
    const page = pagesMap.get(passage.page_index);
    const root = h('article', { class: `passage ${passage.kind === 'heading' ? 'is-heading' : ''}`, 'data-passage-id': passage.id });
    const warnFlags = [...new Set([...(passage.flags ?? []), ...(page?.flags ?? [])])].filter(isWarning);
    const infoFlags = (passage.flags ?? []).filter((f) => !isWarning(f));
    const body = h('div', { class: 'units' }, spinner('Loading text...'));
    const caption = h('div', { class: 'muted small' });

    root.append(...[
      h('div', { class: 'passage-head' },
        h('span', { class: 'pageref' }, pageRef(doc === hDoc ? 'Handout' : 'Source', passage.page_index, page?.printed_label)),
        h('div', { class: 'row gap wrap' },
          button('View original page', () => showOriginal(doc, passage.page_index), { kind: warnFlags.length ? 'primary' : 'secondary', title: 'Open the real PDF page' }),
          ...actions)),
      warnFlags.length ? h('div', { class: 'flags' }, warnFlags.map((f) => badge(`⚠ ${flagText(f)}`, 'warn')), badge('Check original page', 'warn')) : null,
      infoFlags.length ? h('div', { class: 'flags' }, infoFlags.map((f) => badge(flagText(f), 'info'))) : null,
      passage.heading_path && passage.kind !== 'heading' ? h('div', { class: 'muted small' }, passage.heading_path) : null,
      body,
      caption,
    ].filter(Boolean));

    async function fill(allowAutoTranslate) {
      let units;
      try {
        units = await db.get(`units?passage_id=eq.${passage.id}&select=id,idx,text,kind&order=idx.asc`);
      } catch (e) {
        clear(body).append(notice('error', `Could not load this passage: ${errorMessage(e)}`, ' ', button('Retry', () => fill(false))));
        return;
      }
      let tr;
      try {
        tr = await loadTranslations(units);
      } catch (e) {
        clear(body).append(notice('error', `Could not load translations: ${errorMessage(e)}`, ' ', button('Retry', () => fill(false))));
        return;
      }
      const missing = units.filter((u) => !tr.latest.has(u.id));
      const attempt = attempts.get(passage.id);
      const running = inflight.has(passage.id);
      const canAuto = allowAutoTranslate && missing.length && cfg.aiConfigured && !attempt && !running;
      if (canAuto) {
        draw(units, tr, true);
        await translatePassage(passage.id);
        if (!disposed) await fill(false);
        return;
      }
      draw(units, tr, running);
    }

    function draw(units, tr, translating) {
      const attempt = attempts.get(passage.id);
      const missing = units.filter((u) => !tr.latest.has(u.id));
      const anyTranslated = units.some((u) => tr.latest.has(u.id));
      clear(body);
      for (const u of units) body.append(unitView(u, tr, translating, attempt));
      if (missing.length && !translating) {
        const reason = !cfg.aiConfigured
          ? 'AI translation is not configured on the server (ANTHROPIC_API_KEY is missing).'
          : attempt?.state === 'error' ? attempt.message : `${missing.length} sentence(s) have no translation.`;
        body.append(notice('warn', `Translation missing: ${reason}`, ' ',
          cfg.aiConfigured ? button('Retry translation', async () => { attempts.delete(passage.id); await fill(true); }) : null));
      }
      caption.textContent = anyTranslated ? 'Arabic: machine translation, not reviewed. Numbers, units and terms are checked automatically; anything flagged needs your attention.' : '';
    }

    function unitView(u, tr, translating, attempt) {
      const t = tr.latest.get(u.id);
      const wrap = h('div', { class: 'unit', 'data-unit-id': u.id }, h('div', { class: 'en', lang: 'en', dir: 'ltr' }, u.text));
      if (!t) {
        const reason = attempt?.failed?.get(u.id);
        wrap.append(translating
          ? h('div', { class: 'ar-pending' }, 'Translating...')
          : h('div', { class: 'ar-missing' }, `Translation missing${reason ? ` (${reason.replace(/_/g, ' ')})` : ''}. This sentence is not shown as translated.`));
        return wrap;
      }
      const edit = tr.latestEdit.get(t.id);
      const shown = edit ? edit.edited_text : t.machine_text;
      const arView = h('div', { class: 'ar', lang: 'ar', dir: 'rtl' }, shown);
      const meta = h('div', { class: 'ar-meta' });
      const flags = (t.flags ?? []);
      if (edit) meta.append(badge('Edited by you', 'ok'));
      for (const f of flags) meta.append(badge(`⚠ ${flagText(f)}`, 'warn'));
      const machine = h('div', { class: 'ar machine hidden', lang: 'ar', dir: 'rtl' }, t.machine_text);
      const controls = h('div', { class: 'row gap wrap' },
        button('Edit translation', () => startEdit(), { kind: 'link' }),
        edit && button('Show original machine output', (ev) => { machine.classList.toggle('hidden'); ev.target.textContent = machine.classList.contains('hidden') ? 'Show original machine output' : 'Hide original machine output'; }, { kind: 'link' }));
      function startEdit() {
        const ta = h('textarea', { class: 'ar edit', lang: 'ar', dir: 'rtl', rows: '3', 'aria-label': 'Edit the Arabic translation' }, shown);
        ta.value = shown;
        const err = h('div', { class: 'text-error small' });
        const editor = h('div', { class: 'stack' }, ta, err,
          h('div', { class: 'row gap' },
            button('Save correction', async () => {
              const v = ta.value.trim();
              if (!v) { err.textContent = 'The translation cannot be empty.'; return; }
              try {
                await db.insert('translation_edits', { translation_id: t.id, edited_text: v });
                await fill(false);
              } catch (e) { err.textContent = errorMessage(e); }
            }, { kind: 'primary' }),
            button('Cancel', () => editor.replaceWith(controls))));
        controls.replaceWith(editor);
        ta.focus();
      }
      wrap.append(...[arView, meta.childNodes.length ? meta : null, machine, controls].filter(Boolean));
      return wrap;
    }

    fill(true);
    return root;
  }

  // ------------------------------------------------------------- layout
  const handoutPanel = h('section', { class: 'panel', 'data-panel': 'handout', 'aria-label': 'Lecture Handout' });
  const sourcePanel = h('section', { class: 'panel', 'data-panel': 'source', 'aria-label': 'Primary Source' });
  const split = h('div', { class: 'split show-handout' }, sourcePanel, handoutPanel);
  const navInfo = h('span', { class: 'navinfo', 'aria-live': 'polite' });
  const jump = h('input', { type: 'number', min: '1', max: String(hPassages.length), class: 'jump', 'aria-label': 'Go to passage number' });
  const prevBtn = button('Previous passage', () => go(idx - 1));
  const nextBtn = button('Next passage', () => go(idx + 1), { kind: 'primary' });
  jump.addEventListener('change', () => { const n = parseInt(jump.value, 10); if (Number.isFinite(n)) go(n - 1); });
  const tabSource = button('Primary Source', () => setTab('source'), { kind: 'tab' });
  const tabHandout = button('Lecture Handout', () => setTab('handout'), { kind: 'tab' });
  function setTab(t) {
    activeTab = t;
    split.classList.toggle('show-source', t === 'source');
    split.classList.toggle('show-handout', t === 'handout');
    tabSource.setAttribute('aria-pressed', String(t === 'source'));
    tabHandout.setAttribute('aria-pressed', String(t === 'handout'));
  }

  function go(n) {
    if (n < 0 || n >= hPassages.length) return;
    idx = n;
    renderHandout();
    renderSource();
    saveSoon(300);
    handoutPanel.scrollTop = 0;
  }

  function linksFor(passageId) { return links.filter((l) => l.handout_passage_id === passageId); }

  function renderHandout() {
    const p = hPassages[idx];
    const my = linksFor(p.id);
    navInfo.textContent = `Passage ${idx + 1} of ${hPassages.length}`;
    jump.value = String(idx + 1);
    prevBtn.disabled = idx === 0;
    nextBtn.disabled = idx === hPassages.length - 1;
    mount(handoutPanel,
      h('div', { class: 'panel-head' },
        h('h2', null, 'Lecture Handout'),
        h('div', { class: 'row gap wrap' },
          my.length ? badge(`Manual link${my.length > 1 ? `s (${my.length})` : ''}`, 'ok') : badge('Not linked', 'neutral'))),
      passageView(p, hDoc, hPages));
  }

  async function renderSource() {
    const token = Symbol();
    renderSource.token = token;
    const p = hPassages[idx];
    if (!sDoc) {
      mount(sourcePanel, h('div', { class: 'panel-head' }, h('h2', null, 'Primary Source')),
        notice('info', 'No primary source was selected for this lesson. Go back to the Library to choose one.'));
      return;
    }
    const my = linksFor(p.id);
    const toggle = h('div', { class: 'row gap wrap' },
      button(`Linked passages (${my.length})`, () => { srcMode = 'linked'; renderSource(); }, { kind: 'tab', pressed: srcMode === 'linked' }),
      button('Browse source pages', () => { srcMode = 'browse'; renderSource(); }, { kind: 'tab', pressed: srcMode === 'browse' }));
    const head = h('div', { class: 'panel-head' }, h('h2', null, 'Primary Source'), toggle);
    const content = h('div', { class: 'stack' }, spinner('Loading...'));
    mount(sourcePanel, head, content);

    try {
      if (srcMode === 'linked') {
        if (!my.length) {
          clear(content).append(
            notice('info', h('strong', null, 'Not linked. '), 'No source passage has been linked to this handout passage yet. Links are made by you; automatic matching is not implemented.'),
            button('Browse source pages to link one', () => { srcMode = 'browse'; renderSource(); }, { kind: 'primary' }));
          return;
        }
        const rows = await getByIds('passages', 'id', my.map((l) => l.source_passage_id), PASSAGE_COLS);
        if (renderSource.token !== token) return;
        rows.sort((a, b) => a.page_index - b.page_index || a.seq - b.seq);
        clear(content);
        for (const sp of rows) {
          const link = my.find((l) => l.source_passage_id === sp.id);
          content.append(h('div', { class: 'linked' },
            h('div', { class: 'row gap wrap' }, badge('Manual link', 'ok')),
            passageView(sp, sDoc, sPages, { actions: [button('Remove link', () => removeLink(link.id), { kind: 'danger' })] })));
        }
      } else {
        const total = sDoc.pages_total || 1;
        srcPage = Math.min(Math.max(srcPage, 1), total);
        const input = h('input', { type: 'number', min: '1', max: String(total), value: String(srcPage), class: 'jump', 'aria-label': 'Source PDF page number' });
        const goPage = (n) => { if (Number.isFinite(n) && n >= 1 && n <= total) { srcPage = n; saveSoon(); renderSource(); } };
        input.addEventListener('change', () => goPage(parseInt(input.value, 10)));
        const rows = await db.get(`passages?document_id=eq.${sourceId}&page_index=eq.${srcPage}&select=${PASSAGE_COLS}&order=seq.asc`);
        if (renderSource.token !== token) return;
        clear(content).append(
          h('div', { class: 'row gap wrap pager' },
            button('Previous page', () => goPage(srcPage - 1), { disabled: srcPage <= 1 }),
            h('label', { class: 'inline' }, 'Source PDF page ', input, ` of ${total}`),
            button('Next page', () => goPage(srcPage + 1), { disabled: srcPage >= total })),
          h('div', { class: 'muted small' }, 'Choose passages below and link them to the handout passage you are studying.'));
        if (!rows.length) content.append(notice('info', `Source page ${srcPage} has no extracted passages.${sPages.get(srcPage)?.status === 'empty' ? ' The page has no readable text.' : ''}`, ' ', button('View original page', () => showOriginal(sDoc, srcPage))));
        for (const sp of rows) {
          const linked = my.some((l) => l.source_passage_id === sp.id);
          content.append(passageView(sp, sDoc, sPages, {
            actions: [linked ? badge('Linked to this handout passage', 'ok') : button('Link to this handout passage', () => addLink(sp.id), { kind: 'primary' })],
          }));
        }
      }
    } catch (e) {
      if (renderSource.token !== token) return;
      clear(content).append(notice('error', errorMessage(e)), button('Retry', renderSource));
    }
  }

  async function addLink(sourcePassageId) {
    const p = hPassages[idx];
    try {
      const [row] = await db.insert('links', { handout_passage_id: p.id, source_passage_id: sourcePassageId, method: 'manual', status: 'manual' }, true);
      links.push(row);
    } catch (e) {
      if (!/duplicate|unique|409/i.test(errorMessage(e))) {
        sourcePanel.prepend(notice('error', `Could not save the link: ${errorMessage(e)}`));
        return;
      }
    }
    renderHandout();
    renderSource();
  }
  async function removeLink(linkId) {
    try {
      await db.remove(`links?id=eq.${linkId}`);
      links = links.filter((l) => l.id !== linkId);
    } catch (e) {
      sourcePanel.prepend(notice('error', `Could not remove the link: ${errorMessage(e)}`));
      return;
    }
    renderHandout();
    renderSource();
  }

  // ------------------------------------------------------------- assemble
  mount(root,
    h('header', { class: 'timerbar' },
      button('Library', () => navigate('#/library')),
      h('div', { class: 'timerbox' }, clock, startBtn, pauseBtn, resetBtn),
      h('div', { class: 'timerbar-title' }, h('span', { class: 'ellipsis' }, hDoc.title), saveState)),
    h('div', { class: 'banner' }, h('strong', null, 'Automatic matching: not implemented. '), 'Links between handout and source are made by you (manual links).'),
    h('div', { class: 'tabs' }, tabSource, tabHandout),
    split,
    h('footer', { class: 'navbar' }, prevBtn, h('div', { class: 'row gap' }, navInfo, h('label', { class: 'inline' }, 'Go to ', jump)), nextBtn));
  setTab('handout');
  paint();
  renderHandout();
  renderSource();

  return () => {
    disposed = true;
    clearInterval(tick);
    clearTimeout(saveTimer);
    document.removeEventListener('visibilitychange', onVisible);
    document.removeEventListener('visibilitychange', onHide);
    window.removeEventListener('pageshow', onVisible);
    saveNow();
  };
}
