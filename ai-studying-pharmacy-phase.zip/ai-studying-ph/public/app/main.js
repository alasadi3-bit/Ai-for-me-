// App entry: boots, decides which screen to show, and routes by URL hash.
import { h, mount } from './dom.js';
import { notice, button, errorMessage } from './ui.js';
import { currentUser, loadConfig, restoreSession, signOut } from './api.js';
import { setupNeededScreen, signInScreen } from './screens-auth.js';
import { libraryScreen } from './screens-library.js';
import { prelessonScreen } from './screens-prelesson.js';
import { studyScreen } from './screens-study.js';

const root = document.getElementById('app');
let dispose = null;
let cfg = null;
let renderToken = 0;

const UUID = '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}';
const ROUTES = [
  { re: new RegExp(`^#/prelesson/(${UUID})/(${UUID}|none)$`, 'i'), screen: 'prelesson' },
  { re: new RegExp(`^#/study/(${UUID})/(${UUID}|none)$`, 'i'), screen: 'study' },
];

export function navigate(hash) {
  if (location.hash === hash) render();
  else location.hash = hash;
}

async function render() {
  const token = ++renderToken;
  if (dispose) {
    try { dispose(); } catch { /* ignore */ }
    dispose = null;
  }
  window.scrollTo(0, 0);
  try {
    cfg = await loadConfig();
  } catch (e) {
    mount(root, h('main', { class: 'page narrow' }, h('h1', null, 'AI for Studying Pharmacy'), notice('error', errorMessage(e)), button('Try again', render, { kind: 'primary' })));
    return;
  }
  if (token !== renderToken) return;
  if (!cfg.supabaseConfigured) return setupNeededScreen(root, cfg);
  if (currentUser() && !(await restoreSession())) {
    if (token !== renderToken) return;
    return signInScreen(root, { onSignedIn: () => navigate('#/library'), message: 'Your session expired. Please sign in again.' });
  }
  if (token !== renderToken) return;
  if (!currentUser()) {
    return signInScreen(root, { onSignedIn: () => navigate('#/library'), message: '' });
  }
  const hash = location.hash || '#/library';
  const env = {
    cfg,
    navigate,
    onSignedOut: () => navigate('#/library'),
  };
  try {
    for (const r of ROUTES) {
      const m = hash.match(r.re);
      if (!m) continue;
      const handoutId = m[1].toLowerCase();
      const sourceId = m[2] === 'none' ? null : m[2].toLowerCase();
      if (r.screen === 'prelesson') {
        await prelessonScreen(root, { ...env, handoutId, sourceId });
      } else {
        const d = await studyScreen(root, { ...env, handoutId, sourceId });
        if (token === renderToken) dispose = d;
        else d?.();
      }
      return;
    }
    await libraryScreen(root, env);
  } catch (e) {
    if (e?.code === 'not_signed_in') {
      signOut();
      return signInScreen(root, { onSignedIn: () => navigate('#/library'), message: 'Please sign in again.' });
    }
    mount(root, h('main', { class: 'page narrow' }, notice('error', errorMessage(e)), button('Back to the library', () => navigate('#/library'), { kind: 'primary' })));
  }
}

window.addEventListener('hashchange', render);
window.addEventListener('unhandledrejection', (ev) => {
  if (ev.reason?.code === 'not_signed_in') {
    signOut();
    render();
  }
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => { /* app works without it */ }));
}

render();
