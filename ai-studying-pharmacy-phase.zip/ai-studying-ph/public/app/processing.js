// Upload and in-browser PDF processing. Everything here is real: each state written to the
// database corresponds to something that actually happened, and failures are recorded, not hidden.
import { AppError, currentUser, db, downloadFile, uploadFile } from './api.js';
import { openDocument, rememberBytes } from './pdf.js';
import { classifyDocument } from '/lib/extract.js';
import { failedPageRows, processPdfPage } from '/lib/process.js';

const uuid = () => crypto.randomUUID();

/** Identify what a file really is, from its first bytes (not from its name). */
export async function sniffFile(file) {
  const head = new Uint8Array(await file.slice(0, 8).arrayBuffer());
  const text = String.fromCharCode(...head);
  if (text.startsWith('%PDF-')) return 'pdf';
  if (head[0] === 0x50 && head[1] === 0x4b) return 'zip'; // pptx, docx, xlsx
  if (head[0] === 0x89 && text.slice(1, 4) === 'PNG') return 'png';
  if (head[0] === 0xff && head[1] === 0xd8) return 'jpeg';
  return 'unknown';
}

const UNSUPPORTED_MESSAGES = {
  zip: 'This looks like an Office file (for example PowerPoint). Slide decks are not supported yet. Export it as a text-based PDF first.',
  png: 'Images are not supported yet (no OCR). Nothing was uploaded.',
  jpeg: 'Images are not supported yet (no OCR). Nothing was uploaded.',
  unknown: 'This file is not a PDF, so it was not uploaded.',
};

export async function createDocument(kind, file, title) {
  const user = currentUser();
  if (!user) throw new AppError('Please sign in.', { status: 401 });
  const sniffed = await sniffFile(file);
  if (sniffed !== 'pdf') throw new AppError(UNSUPPORTED_MESSAGES[sniffed] ?? UNSUPPORTED_MESSAGES.unknown);

  const id = uuid();
  const storagePath = `${user.id}/${id}.pdf`;
  await uploadFile(storagePath, file);
  const [row] = await db.insert(
    'documents',
    { id, kind, title: title || file.name.replace(/\.pdf$/i, ''), file_name: file.name, storage_path: storagePath, file_type: 'pdf', status: 'uploaded' },
    true,
  );
  rememberBytes(id, new Uint8Array(await file.arrayBuffer()));
  return row;
}

const chunk = (arr, n) => {
  const out = [];
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n));
  return out;
};

async function savePage(documentId, rows) {
  const p = rows.page.page_index;
  // Idempotent: replace anything previously stored for this page (units cascade from passages).
  await db.remove(`passages?document_id=eq.${documentId}&page_index=eq.${p}`);
  await db.remove(`document_pages?document_id=eq.${documentId}&page_index=eq.${p}`);
  await db.insert('document_pages', rows.page);
  if (rows.passages.length) await db.insert('passages', rows.passages);
  for (const part of chunk(rows.units, 400)) await db.insert('units', part);
}

async function setDoc(id, patch) {
  await db.patch(`documents?id=eq.${id}`, patch);
}

/**
 * Process pages of one document.
 * pages: 'resume' continues after pages_done; an array retries exactly those pages.
 * onProgress({done,total,page,failed}) is called after every real page save.
 */
export async function processDocument(doc, { pages = 'resume', onProgress = () => {}, shouldStop = () => false } = {}) {
  let pdf;
  try {
    pdf = await openDocument(doc.id, doc.storage_path);
  } catch (e) {
    const msg = `Could not open this PDF: ${e.message}`;
    await setDoc(doc.id, { status: 'failed', status_message: msg });
    return { status: 'failed', message: msg };
  }
  const total = pdf.numPages;
  const list = pages === 'resume' ? range(Math.max(1, (doc.pages_done ?? 0) + 1), total) : pages.filter((n) => n >= 1 && n <= total);
  await setDoc(doc.id, { status: 'processing', status_message: null, pages_total: total });

  let failed = 0;
  let sawTextInFirstPages = false;
  for (const i of list) {
    if (shouldStop()) {
      await setDoc(doc.id, { status: 'processing', status_message: 'Paused. Press Resume to continue.' });
      return { status: 'processing', message: 'paused' };
    }
    let rows;
    try {
      const page = await pdf.getPage(i);
      rows = await processPdfPage(doc.id, page, i, uuid);
    } catch (e) {
      rows = failedPageRows(doc.id, i, e?.message || String(e));
    }
    try {
      await savePage(doc.id, rows);
    } catch (e) {
      const msg = `Could not save page ${i}: ${e.message}`;
      await setDoc(doc.id, { status: 'failed', status_message: msg });
      return { status: 'failed', message: msg };
    }
    if (rows.page.status === 'failed') failed++;
    if (pages === 'resume') await setDoc(doc.id, { pages_done: i });
    onProgress({ done: i, total, page: i, failed });

    // A scanned PDF is detected from its first pages so we do not waste time on the rest.
    if (pages === 'resume' && i <= 3) {
      if (rows.page.status === 'ok') sawTextInFirstPages = true;
      if (i === Math.min(3, total) && !sawTextInFirstPages) break;
    }
  }

  const statuses = await db.getAll(`document_pages?document_id=eq.${doc.id}&select=page_index,status,error&order=page_index.asc`);
  if (statuses.some((s) => s.status === 'failed') && !statuses.some((s) => s.status === 'ok')) {
    const first = statuses.find((s) => s.status === 'failed');
    const msg = `No page produced text: ${statuses.filter((s) => s.status === 'failed').length} of ${statuses.length} page(s) failed with an extraction error and the rest are empty. First error (page ${first.page_index}): ${first.error || 'unknown error'}`;
    await setDoc(doc.id, { status: 'failed', status_message: msg, pages_total: total });
    return { status: 'failed', message: msg, failedPages: statuses.map((s) => s.page_index) };
  }
  const verdict = classifyDocument(statuses);
  if (!verdict.supported) {
    await setDoc(doc.id, { status: 'unsupported', status_message: verdict.message, pages_total: total });
    return { status: 'unsupported', message: verdict.message };
  }
  const failedPages = statuses.filter((s) => s.status === 'failed').map((s) => s.page_index);
  const done = statuses.length >= total;
  const notes = [];
  if (verdict.message) notes.push(verdict.message);
  if (failedPages.length) notes.push(`Processed with errors: ${failedPages.length} page(s) failed (${failedPages.slice(0, 10).join(', ')}${failedPages.length > 10 ? ', ...' : ''}). Use "Retry failed pages".`);
  if (!done) notes.push(`Only ${statuses.length} of ${total} pages are processed so far.`);
  const finalStatus = done ? 'processed' : 'processing';
  await setDoc(doc.id, { status: finalStatus, status_message: notes.join(' ') || null, pages_total: total });
  return { status: finalStatus, message: notes.join(' ') || null, failedPages };
}

function range(a, b) {
  const out = [];
  for (let i = a; i <= b; i++) out.push(i);
  return out;
}

export async function retryFailedPages(doc, onProgress) {
  const rows = await db.getAll(`document_pages?document_id=eq.${doc.id}&status=eq.failed&select=page_index&order=page_index.asc`);
  if (!rows.length) return { status: doc.status, message: 'No failed pages.' };
  return processDocument(doc, { pages: rows.map((r) => r.page_index), onProgress });
}

export { downloadFile };
