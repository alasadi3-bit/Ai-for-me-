// Browser-side access to Supabase (REST, auth, storage) and to our own /api functions.
// Only the public anon key is ever used here. Every table is protected by Row Level Security,
// and the Anthropic key exists only on the server.

const SESSION_KEY = 'aisph.session.v1';

let config = null;
let session = null;
let refreshing = null;

export class AppError extends Error {
  constructor(message, { status = 0, code = '' } = {}) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export async function loadConfig() {
  if (config) return config;
  let res;
  try {
    res = await fetch('/api/config', { cache: 'no-store' });
  } catch (e) {
    throw new AppError('Could not reach the server (/api/config). Check your connection.');
  }
  if (!res.ok) throw new AppError(`The server returned HTTP ${res.status} for /api/config.`, { status: res.status });
  config = await res.json();
  return config;
}

// ---------------------------------------------------------------- session
function readSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
function writeSession(s) {
  session = s;
  try {
    if (s) localStorage.setItem(SESSION_KEY, JSON.stringify(s));
    else localStorage.removeItem(SESSION_KEY);
  } catch {
    /* storage may be blocked; the session then lasts until the page closes */
  }
}
function toSession(body) {
  return {
    access_token: body.access_token,
    refresh_token: body.refresh_token,
    expires_at: Math.floor(Date.now() / 1000) + (body.expires_in ?? 3600),
    user: { id: body.user?.id, email: body.user?.email },
  };
}

export function currentUser() {
  if (!session) session = readSession();
  return session?.user ?? null;
}

async function authFetch(path, body, query = '') {
  const cfg = await loadConfig();
  if (!cfg.supabaseConfigured) throw new AppError('Supabase is not configured on the server yet.', { code: 'supabase_not_configured' });
  let res;
  try {
    res = await fetch(`${cfg.supabaseUrl}/auth/v1/${path}${query}`, {
      method: 'POST',
      headers: { apikey: cfg.supabaseAnonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch {
    throw new AppError('Could not reach Supabase. Check your connection.');
  }
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new AppError(json.msg || json.error_description || json.message || `Sign-in failed (HTTP ${res.status}).`, { status: res.status });
  return json;
}

export async function sendCode(email) {
  await authFetch('otp', { email, create_user: true });
}
export async function verifyCode(email, token) {
  const body = await authFetch('verify', { type: 'email', email, token: token.trim() });
  writeSession(toSession(body));
  return currentUser();
}
/**
 * Sign out. The local session is cleared immediately and always. The server-side sign-out
 * (which revokes the refresh token) is attempted in the background; if it fails (offline) the
 * device is still signed out locally and nothing is reported as revoked.
 */
export function signOut() {
  const old = session ?? readSession();
  writeSession(null);
  profileCache = null;
  if (old?.access_token && config?.supabaseConfigured) {
    fetch(`${config.supabaseUrl}/auth/v1/logout`, {
      method: 'POST',
      headers: { apikey: config.supabaseAnonKey, Authorization: `Bearer ${old.access_token}` },
    }).catch(() => { /* offline: local sign-out already happened */ });
  }
}

/**
 * Restore a saved session at start-up. Returns the user, or null if there is none or it can no
 * longer be refreshed (expired or revoked). Never pretends a dead session is alive.
 */
export async function restoreSession() {
  if (!currentUser()) return null;
  try {
    await accessToken(); // refreshes if the access token is (nearly) expired
    return currentUser();
  } catch (e) {
    if (e?.code === 'not_signed_in') return null;
    return currentUser(); // network trouble: keep the session, requests will report their own errors
  }
}

let profileCache = null;
/** The signed-in user's profile row ({id,email,display_name,role}) or null if unavailable. */
export async function loadProfile(force = false) {
  if (profileCache && !force) return profileCache;
  const user = currentUser();
  if (!user) return null;
  try {
    const [row] = await rest('GET', `profiles?id=eq.${user.id}&select=id,email,display_name,role`);
    profileCache = row ?? null;
  } catch {
    profileCache = null; // e.g. migration 0002 not applied yet
  }
  return profileCache;
}
export const isAdminProfile = (p) => p?.role === 'admin';

async function accessToken() {
  if (!session) session = readSession();
  if (!session) throw new AppError('Please sign in.', { status: 401, code: 'not_signed_in' });
  const now = Math.floor(Date.now() / 1000);
  if (session.expires_at - now > 60) return session.access_token;
  if (!refreshing) {
    refreshing = authFetch('token', { refresh_token: session.refresh_token }, '?grant_type=refresh_token')
      .then((body) => {
        writeSession(toSession(body));
      })
      .catch((e) => {
        // Only an answer from the auth server (the refresh token is invalid, expired or revoked)
        // ends the session. Being offline, or a server hiccup, must NOT sign the student out.
        if (e?.status >= 400 && e?.status < 500) {
          writeSession(null);
          throw new AppError('Your session expired. Please sign in again.', { status: 401, code: 'not_signed_in' });
        }
        throw e;
      })
      .finally(() => {
        refreshing = null;
      });
  }
  await refreshing;
  return session.access_token;
}

// ------------------------------------------------------------------- REST
async function rest(method, path, { body, prefer, headers } = {}) {
  const cfg = await loadConfig();
  const token = await accessToken();
  let res;
  try {
    res = await fetch(`${cfg.supabaseUrl}/rest/v1/${path}`, {
      method,
      headers: {
        apikey: cfg.supabaseAnonKey,
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...(prefer ? { Prefer: prefer } : {}),
        ...(headers ?? {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new AppError('Could not reach the database. Check your connection.');
  }
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    throw new AppError(`Database error (${method} ${path.split('?')[0]}): ${j.message || j.hint || 'HTTP ' + res.status}`, { status: res.status });
  }
  if (res.status === 204) return [];
  const text = await res.text();
  return text ? JSON.parse(text) : [];
}

export const db = {
  get: (path) => rest('GET', path),
  async getAll(path, pageSize = 1000) {
    const out = [];
    for (let offset = 0; ; offset += pageSize) {
      const sep = path.includes('?') ? '&' : '?';
      const rows = await rest('GET', `${path}${sep}limit=${pageSize}&offset=${offset}`);
      out.push(...rows);
      if (rows.length < pageSize) break;
    }
    return out;
  },
  insert: (table, rows, returning = false) => rest('POST', table, { body: rows, prefer: returning ? 'return=representation' : 'return=minimal' }),
  upsert: (table, rows, onConflict) =>
    rest('POST', `${table}?on_conflict=${onConflict}`, { body: rows, prefer: 'resolution=merge-duplicates,return=minimal' }),
  patch: (path, body) => rest('PATCH', path, { body, prefer: 'return=minimal' }),
  remove: (path) => rest('DELETE', path, { prefer: 'return=minimal' }),
};

/** Fetch rows for many ids without building an over-long URL. */
export async function getByIds(table, column, ids, select) {
  const out = [];
  for (let i = 0; i < ids.length; i += 40) {
    const part = ids.slice(i, i + 40);
    out.push(...(await db.get(`${table}?${column}=in.(${part.join(',')})&select=${select}`)));
  }
  return out;
}

// ---------------------------------------------------------------- storage
export async function uploadFile(path, file) {
  const cfg = await loadConfig();
  const token = await accessToken();
  let res;
  try {
    res = await fetch(`${cfg.supabaseUrl}/storage/v1/object/documents/${path}`, {
      method: 'POST',
      headers: {
        apikey: cfg.supabaseAnonKey,
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/pdf', // the bucket accepts PDFs only; the file was checked by its bytes
        'x-upsert': 'true',
      },
      body: file,
    });
  } catch {
    throw new AppError('Upload failed: could not reach storage. Check your connection.');
  }
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    throw new AppError(`Upload failed: ${j.message || j.error || 'HTTP ' + res.status}`, { status: res.status });
  }
}

export async function downloadFile(path) {
  const cfg = await loadConfig();
  const token = await accessToken();
  let res;
  try {
    res = await fetch(`${cfg.supabaseUrl}/storage/v1/object/authenticated/documents/${path}`, {
      headers: { apikey: cfg.supabaseAnonKey, Authorization: `Bearer ${token}` },
    });
  } catch {
    throw new AppError('Could not download the file. Check your connection.');
  }
  if (!res.ok) throw new AppError(`Could not download the file (HTTP ${res.status}).`, { status: res.status });
  return new Uint8Array(await res.arrayBuffer());
}

// ------------------------------------------------------- our server routes
export async function callServer(route, body) {
  const token = await accessToken();
  let res;
  try {
    res = await fetch(`/api/${route}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
  } catch {
    throw new AppError('Could not reach the server. Check your connection.');
  }
  const json = await res.json().catch(() => ({}));
  if (!res.ok && res.status !== 207) {
    throw new AppError(json.message || `Server error (HTTP ${res.status}).`, { status: res.status, code: json.error || '' });
  }
  return json;
}
