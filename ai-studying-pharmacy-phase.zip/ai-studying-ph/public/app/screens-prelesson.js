import { h, mount } from './dom.js';
import { badge, button, notice, spinner, errorMessage } from './ui.js';
import { callServer, db, getByIds } from './api.js';

const SECTIONS = [
  ['mental_preparation', 'Mental Preparation', 'The essential ideas and mental models to have in mind before you start.'],
  ['prerequisites', 'Prerequisite Concepts', 'Earlier concepts you need to understand this lesson.'],
  ['teaching_plan', 'Teaching Plan', 'What we will study and explain, in sequence, following the handout’s scope and drawing on the primary source.'],
];

export async function prelessonScreen(root, { handoutId, sourceId, cfg, navigate }) {
  const study = () => navigate(`#/study/${handoutId}/${sourceId ?? 'none'}`);
  const back = () => navigate('#/library');

  const frame = (...body) =>
    mount(
      root,
      h('header', { class: 'topbar' }, button('Library', back), h('h1', { class: 'title' }, 'Before you study')),
      h('main', { class: 'page' }, ...body),
    );

  async function load(force) {
    frame(spinner(force ? 'Preparing a new pre-lesson... this can take up to a minute.' : 'Preparing your pre-lesson... this can take up to a minute.'));
    let result;
    try {
      if (!cfg.aiConfigured) throw new Error('AI is not configured on the server (ANTHROPIC_API_KEY is missing), so the pre-lesson cannot be written.');
      result = await callServer('prelesson', { handoutId, sourceId: sourceId ?? null, force });
    } catch (e) {
      if (!cfg.aiConfigured) {
        frame(
          notice('warn', h('strong', null, 'AI is not configured, so no pre-lesson was generated. '), 'The three sections below are empty on purpose: nothing has been written or invented. You can still study the documents.'),
          SECTIONS.map(([key, title, help], i) =>
            h('section', { class: 'card', 'data-section': key },
              h('h2', null, `${i + 1}. ${title}`),
              h('p', { class: 'muted small' }, help),
              badge('Not generated: AI is not configured', 'warn'))),
          h('div', { class: 'row gap sticky-actions' }, button('Start Studying', study, { kind: 'primary' })));
        return;
      }
      frame(
        notice('error', errorMessage(e)),
        h('div', { class: 'row gap' },
          button('Try again', () => load(force), { kind: 'primary' }),
          button('Start studying anyway (no pre-lesson)', study)),
      );
      return;
    }
    const content = result.prelesson?.content;
    // Resolve passage references to real page numbers from our own database.
    const ids = new Set();
    for (const [key] of SECTIONS) for (const it of content[key] ?? []) for (const r of it.refs ?? []) ids.add(r);
    for (const id of content.uncovered_handout_passage_ids ?? []) ids.add(id);
    let refInfo = new Map();
    try {
      const rows = await getByIds('passages', 'id', [...ids], 'id,document_id,page_index,text');
      refInfo = new Map(rows.map((r) => [r.id, r]));
    } catch (e) {
      /* references fall back to "unknown page"; shown below */
    }
    render(content, result, refInfo);
  }

  function refLabel(id, refInfo) {
    const p = refInfo.get(id);
    if (!p) return 'passage (page unknown)';
    return `${p.document_id === handoutId ? 'Handout' : 'Source'} PDF page ${p.page_index}`;
  }

  function renderItem(it, refInfo) {
    return h('li', { class: 'preitem' },
      it.title && h('strong', null, it.title),
      h('p', null, it.text),
      h('div', { class: 'row gap wrap' },
        it.basis === 'document'
          ? [badge('From your documents', 'ok'), ...it.refs.map((r) => badge(refLabel(r, refInfo), 'neutral'))]
          : badge('General background (not from your documents)', 'warn'),
        it.flags?.includes('invalid_reference_removed') && badge('A reference from the AI did not exist and was removed', 'warn'),
        it.flags?.includes('no_valid_reference_downgraded') && badge('Claimed a document source without a valid reference; shown as general', 'warn'),
      ),
    );
  }

  function render(content, result, refInfo) {
    const uncovered = content.uncovered_handout_passage_ids ?? [];
    frame(
      result.status === 'cached' && notice('info', 'Showing the pre-lesson saved earlier for this handout and source.'),
      ...(content.notes ?? []).map((n) => notice('warn', n)),
      SECTIONS.map(([key, title, help], i) =>
        h('section', { class: 'card', 'data-section': key },
          h('h2', null, `${i + 1}. ${title}`),
          h('p', { class: 'muted small' }, help),
          (content[key] ?? []).length ? h('ol', { class: 'preitems' }, content[key].map((it) => renderItem(it, refInfo))) : notice('warn', 'Nothing was returned for this section.'),
        )),
      uncovered.length
        ? h('section', { class: 'card' },
            h('h3', null, 'Handout passages the Teaching Plan did not cover'),
            h('p', { class: 'muted small' }, 'The handout defines the required scope, so these are listed instead of being left out silently.'),
            h('ul', null, uncovered.map((id) => h('li', null, `${refLabel(id, refInfo)}: ${(refInfo.get(id)?.text ?? '').slice(0, 140)}`))),
          )
        : null,
      h('div', { class: 'row gap sticky-actions' },
        button('Start Studying', study, { kind: 'primary' }),
        button('Regenerate', () => load(true))),
    );
  }

  await load(false);
}
