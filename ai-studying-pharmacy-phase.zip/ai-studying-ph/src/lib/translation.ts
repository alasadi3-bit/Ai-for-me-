// Faithful literal translation: prompt, response parsing and validation.
//
// The AI can fail in ways that look fine on screen (dropping a sentence,
// merging two, summarising, changing a dose). Every result therefore passes
// through deterministic checks here, and anything that fails is FLAGGED and
// shown to the student. Nothing is auto-corrected and nothing is hidden.

export const PROMPT_VERSION = 'tr-v1';
export const TOOL_NAME = 'submit_translations';

export interface UnitIn {
  id: string;
  text: string;
}
export interface RawTranslation {
  id: string;
  arabic: string;
}
export interface Checks {
  numbers_ok: boolean;
  terms_ok: boolean;
  length_ratio: number | null;
  has_arabic_script: boolean;
  missing_numbers?: string[];
  added_numbers?: string[];
  missing_terms?: string[];
}
export interface ValidatedTranslation {
  id: string;
  arabic: string;
  flags: string[];
  checks: Checks;
}
export interface BatchValidation {
  accepted: ValidatedTranslation[];
  /** unit ids with no usable translation (missing, empty or duplicated) */
  missing: { id: string; reason: 'missing' | 'empty' | 'duplicate' }[];
  /** ids returned that were never requested (ignored) */
  unexpected: string[];
}

export const SYSTEM_PROMPT = `You are a precise English-to-Arabic translator for pharmacy and medical study material.
You receive numbered units. Each unit is ONE sentence or fragment taken exactly from a textbook or lecture handout.

Rules (all mandatory):
1. Return exactly one Arabic translation for every unit id, using the same ids. Never merge units, split a unit, skip a unit or change the order.
2. Translate literally and completely. Every clause and every word of the English must be represented. Do NOT summarise, shorten, paraphrase, explain, add comments, or add information that is not in the English.
3. Copy numbers exactly, written with Western digits (0-9). Keep units, symbols, equations, chemical formulas, abbreviations and codes (for example COX-1, mg/kg, 5-HT3) exactly as written in Latin script.
4. Keep drug names and technical terms in English (Latin script). Where an established Arabic term exists, write it in parentheses after the English term. If you are not sure of the Arabic term, keep only the English term. Do not invent Arabic terms.
5. If a unit looks cut off, garbled or incomplete, translate exactly what is there. Never complete, correct or guess missing words.
6. Reply only by calling the ${TOOL_NAME} tool.`;

export function buildUserMessage(units: UnitIn[]): string {
  return (
    'Translate these units into Arabic. Return one translation per id.\n\n' +
    JSON.stringify(units.map((u) => ({ id: u.id, english: u.text })), null, 2)
  );
}

export function buildAnthropicRequest(model: string, units: UnitIn[]) {
  return {
    model,
    max_tokens: 8000,
    system: SYSTEM_PROMPT,
    messages: [{ role: 'user', content: buildUserMessage(units) }],
    tools: [
      {
        name: TOOL_NAME,
        description: 'Submit the Arabic translation for every unit id.',
        input_schema: {
          type: 'object',
          properties: {
            translations: {
              type: 'array',
              items: {
                type: 'object',
                properties: { id: { type: 'string' }, arabic: { type: 'string' } },
                required: ['id', 'arabic'],
              },
            },
          },
          required: ['translations'],
        },
      },
    ],
    tool_choice: { type: 'tool', name: TOOL_NAME },
  };
}

/** Extract the tool call from an Anthropic Messages API response. */
export function parseAnthropicResponse(resp: any): { translations: RawTranslation[] } | { error: string } {
  if (!resp || !Array.isArray(resp.content)) return { error: 'unexpected response shape' };
  if (resp.stop_reason === 'max_tokens') return { error: 'model output was cut off (max_tokens)' };
  const block = resp.content.find((b: any) => b?.type === 'tool_use' && b?.name === TOOL_NAME);
  if (!block) return { error: 'model did not return a translation result' };
  const arr = block.input?.translations;
  if (!Array.isArray(arr)) return { error: 'translation result had no list' };
  const out: RawTranslation[] = [];
  for (const t of arr) {
    if (t && typeof t.id === 'string' && typeof t.arabic === 'string') out.push({ id: t.id, arabic: t.arabic });
  }
  return { translations: out };
}

// ------------------------------------------------------------ helper checks

const AR_INDIC = '٠١٢٣٤٥٦٧٨٩';
const EXT_AR_INDIC = '۰۱۲۳۴۵۶۷۸۹';

export function normaliseDigits(s: string): string {
  return s
    .replace(/[٠-٩]/g, (c) => String(AR_INDIC.indexOf(c)))
    .replace(/[۰-۹]/g, (c) => String(EXT_AR_INDIC.indexOf(c)))
    .replace(/٫/g, '.')
    .replace(/٬/g, ',');
}

function normaliseDashes(s: string): string {
  return s.replace(/[‐-―−]/g, '-');
}

export function numbersIn(s: string): string[] {
  return normaliseDigits(s).match(/\d+(?:[.,]\d+)*/g) ?? [];
}

/** Acronyms, codes and mixed letter-digit tokens that must be kept verbatim. */
export function protectedTermsIn(english: string): string[] {
  const tokens = normaliseDashes(english).match(/[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*/g) ?? [];
  const out = new Set<string>();
  for (const t of tokens) {
    if (/^\d+$/.test(t)) continue;
    const upper = (t.match(/[A-Z]/g) ?? []).length;
    const hasDigit = /\d/.test(t);
    const hasLetter = /[A-Za-z]/.test(t);
    if (upper >= 2 || (hasDigit && hasLetter)) out.add(t);
  }
  return [...out];
}

function letterCount(s: string): number {
  return (s.match(/\p{L}/gu) ?? []).length;
}

export function validateOne(english: string, arabic: string): { flags: string[]; checks: Checks } {
  const flags: string[] = [];
  const arNorm = normaliseDashes(normaliseDigits(arabic));
  const enNums = numbersIn(english);
  const arNums = numbersIn(arabic);

  const arCount = new Map<string, number>();
  for (const n of arNums) arCount.set(n, (arCount.get(n) ?? 0) + 1);
  const missingNumbers: string[] = [];
  for (const n of enNums) {
    const c = arCount.get(n) ?? 0;
    if (c > 0) arCount.set(n, c - 1);
    else missingNumbers.push(n);
  }
  const addedNumbers: string[] = [];
  for (const [n, c] of arCount) for (let i = 0; i < c; i++) addedNumbers.push(n);
  if (missingNumbers.length) flags.push('numbers_missing');
  if (addedNumbers.length) flags.push('numbers_added');

  const missingTerms = protectedTermsIn(english).filter((t) => !arNorm.includes(t));
  if (missingTerms.length) flags.push('terms_missing');

  const hasArabic = /[؀-ۿ]/.test(arabic);
  const enLetters = letterCount(english);
  const hasLowerWords = /[a-z]{3,}/.test(english);
  if (!hasArabic && hasLowerWords) flags.push('not_translated');

  let ratio: number | null = null;
  if (enLetters >= 15) {
    ratio = Math.round((arabic.replace(/\s/g, '').length / english.replace(/\s/g, '').length) * 100) / 100;
    if (ratio < 0.45) flags.push('possible_omission_or_summary');
    else if (ratio > 2.2) flags.push('possible_addition');
  }

  return {
    flags,
    checks: {
      numbers_ok: missingNumbers.length === 0 && addedNumbers.length === 0,
      terms_ok: missingTerms.length === 0,
      length_ratio: ratio,
      has_arabic_script: hasArabic,
      ...(missingNumbers.length ? { missing_numbers: missingNumbers } : {}),
      ...(addedNumbers.length ? { added_numbers: addedNumbers } : {}),
      ...(missingTerms.length ? { missing_terms: missingTerms } : {}),
    },
  };
}

export function validateBatch(expected: UnitIn[], returned: RawTranslation[]): BatchValidation {
  const expectedIds = new Set(expected.map((u) => u.id));
  const counts = new Map<string, number>();
  for (const r of returned) counts.set(r.id, (counts.get(r.id) ?? 0) + 1);
  const byId = new Map(returned.map((r) => [r.id, r] as const));

  const accepted: ValidatedTranslation[] = [];
  const missing: BatchValidation['missing'] = [];
  for (const u of expected) {
    const n = counts.get(u.id) ?? 0;
    if (n === 0) { missing.push({ id: u.id, reason: 'missing' }); continue; }
    if (n > 1) { missing.push({ id: u.id, reason: 'duplicate' }); continue; }
    const r = byId.get(u.id)!;
    if (!r.arabic || !r.arabic.trim()) { missing.push({ id: u.id, reason: 'empty' }); continue; }
    const { flags, checks } = validateOne(u.text, r.arabic);
    accepted.push({ id: u.id, arabic: r.arabic, flags, checks });
  }
  const unexpected = returned.filter((r) => !expectedIds.has(r.id)).map((r) => r.id);
  return { accepted, missing, unexpected };
}

/** Split units into request-sized batches (never splits a unit). */
export function chunkUnits(units: UnitIn[], maxUnits = 12, maxChars = 3500): UnitIn[][] {
  const out: UnitIn[][] = [];
  let cur: UnitIn[] = [];
  let chars = 0;
  for (const u of units) {
    if (cur.length && (cur.length >= maxUnits || chars + u.text.length > maxChars)) {
      out.push(cur);
      cur = [];
      chars = 0;
    }
    cur.push(u);
    chars += u.text.length;
  }
  if (cur.length) out.push(cur);
  return out;
}

export const FLAG_LABELS: Record<string, string> = {
  numbers_missing: 'A number in the English is missing from the Arabic',
  numbers_added: 'The Arabic contains a number that is not in the English',
  terms_missing: 'An acronym or code from the English is missing from the Arabic',
  not_translated: 'The Arabic contains no Arabic text',
  possible_omission_or_summary: 'The Arabic is much shorter than expected: possible omission or summary',
  possible_addition: 'The Arabic is much longer than expected: possible addition',
};
