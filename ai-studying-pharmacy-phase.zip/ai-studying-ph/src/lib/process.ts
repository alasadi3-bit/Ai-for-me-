// Turns an extracted page into database rows (passages and sentence units).
import { extractPage, type ExtractedPage } from './extract';
import { pageToItems, type PdfJsPageLike } from './pdfjs-adapter';
import { splitSentences, unitsPreserveText } from './sentences';

export interface PassageRow {
  id: string;
  document_id: string;
  page_index: number;
  seq: number;
  kind: 'heading' | 'paragraph';
  heading_path: string;
  raw_text: string;
  text: string;
  flags: string[];
}
export interface UnitRow {
  id: string;
  passage_id: string;
  document_id: string;
  idx: number;
  text: string;
  kind: 'sentence' | 'fragment';
}
export interface PageRows {
  page: {
    document_id: string;
    page_index: number;
    printed_label: string | null;
    raw_text: string;
    status: 'ok' | 'empty' | 'failed';
    flags: string[];
    error: string | null;
  };
  passages: PassageRow[];
  units: UnitRow[];
}

export function buildRows(
  documentId: string,
  extracted: ExtractedPage,
  newId: () => string,
): PageRows {
  const passages: PassageRow[] = [];
  const units: UnitRow[] = [];
  for (const p of extracted.passages) {
    const id = newId();
    const flags = [...p.flags];
    let us =
      p.kind === 'heading'
        ? [{ idx: 0, text: p.text, kind: 'fragment' as const }]
        : splitSentences(p.text);
    if (!unitsPreserveText(p.text, us)) {
      // Defensive: never lose text. Fall back to one unit holding the whole passage.
      us = [{ idx: 0, text: p.text, kind: 'fragment' as const }];
      flags.push('sentence_split_fallback');
    }
    passages.push({
      id,
      document_id: documentId,
      page_index: extracted.pageIndex,
      seq: p.seq,
      kind: p.kind,
      heading_path: p.headingPath,
      raw_text: p.rawText,
      text: p.text,
      flags,
    });
    for (const u of us) {
      units.push({ id: newId(), passage_id: id, document_id: documentId, idx: u.idx, text: u.text, kind: u.kind });
    }
  }
  return {
    page: {
      document_id: documentId,
      page_index: extracted.pageIndex,
      printed_label: extracted.printedLabel,
      raw_text: extracted.rawText,
      status: extracted.status,
      flags: extracted.flags,
      error: null,
    },
    passages,
    units,
  };
}

export async function processPdfPage(
  documentId: string,
  pdfPage: PdfJsPageLike,
  pageIndex: number,
  newId: () => string,
): Promise<PageRows> {
  const { items, pageHeight } = await pageToItems(pdfPage);
  const extracted = extractPage(items, { pageIndex, pageHeight });
  return buildRows(documentId, extracted, newId);
}

export function failedPageRows(documentId: string, pageIndex: number, message: string): PageRows {
  return {
    page: {
      document_id: documentId,
      page_index: pageIndex,
      printed_label: null,
      raw_text: '',
      status: 'failed',
      flags: ['extraction_failed'],
      error: message,
    },
    passages: [],
    units: [],
  };
}
