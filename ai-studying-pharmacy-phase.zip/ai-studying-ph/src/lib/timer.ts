// Study timer that stays correct when the iPad locks or the app is in the
// background. Elapsed time is always computed from wall-clock timestamps; a
// setInterval is only used to repaint the screen.

export interface TimerState {
  accumulatedMs: number; // time counted before the current run
  startedAt: number | null; // epoch ms when the current run began; null when paused/stopped
}

export const initialTimer: TimerState = { accumulatedMs: 0, startedAt: null };

export function elapsedMs(s: TimerState, now: number): number {
  const running = s.startedAt === null ? 0 : Math.max(0, now - s.startedAt);
  return Math.max(0, s.accumulatedMs) + running;
}

export function isRunning(s: TimerState): boolean {
  return s.startedAt !== null;
}

export function start(s: TimerState, now: number): TimerState {
  return s.startedAt === null ? { accumulatedMs: s.accumulatedMs, startedAt: now } : s;
}

export function pause(s: TimerState, now: number): TimerState {
  return s.startedAt === null ? s : { accumulatedMs: elapsedMs(s, now), startedAt: null };
}

export function reset(): TimerState {
  return { accumulatedMs: 0, startedAt: null };
}

export function formatElapsed(ms: number): string {
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const sec = total % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(sec)}` : `${pad(m)}:${pad(sec)}`;
}

export function serialize(s: TimerState): string {
  return JSON.stringify(s);
}

export function parse(raw: string | null): TimerState {
  if (!raw) return initialTimer;
  try {
    const o = JSON.parse(raw);
    const acc = Number(o.accumulatedMs);
    const st = o.startedAt === null || o.startedAt === undefined ? null : Number(o.startedAt);
    if (!Number.isFinite(acc) || acc < 0) return initialTimer;
    if (st !== null && !Number.isFinite(st)) return initialTimer;
    return { accumulatedMs: acc, startedAt: st };
  } catch {
    return initialTimer;
  }
}

/** Merge a locally stored timer with the one saved on the server: the one with more elapsed time wins. */
export function pickNewer(local: TimerState, remote: TimerState, now: number): TimerState {
  return elapsedMs(remote, now) > elapsedMs(local, now) ? remote : local;
}
