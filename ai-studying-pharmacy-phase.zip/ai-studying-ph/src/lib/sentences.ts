// Deterministic sentence splitting. No AI is involved.
//
// Contract (tested): joining the returned units with single spaces gives
// exactly the whitespace-normalised input. Nothing is dropped, reordered or
// rewritten. When a boundary is uncertain the splitter does NOT split, so a
// unit can be longer than one sentence, but text is never lost.

export type UnitKind = 'sentence' | 'fragment';
export interface SentenceUnit {
  idx: number;
  text: string;
  kind: UnitKind;
}

// Abbreviations that normally do not end a sentence (compared lower-case, without the final dot).
const ABBREVIATIONS = new Set([
  'e.g', 'i.e', 'cf', 'vs', 'viz', 'etc', 'approx', 'ca', 'al', 'et al',
  'fig', 'figs', 'eq', 'eqs', 'ref', 'refs', 'no', 'nos', 'vol', 'pp', 'p', 'ed', 'eds',
  'dr', 'mr', 'mrs', 'ms', 'prof', 'st', 'inc', 'ltd', 'co', 'jr', 'sr',
  'sp', 'spp', 'subsp', 'var', 'conc', 'temp', 'max', 'min', 'resp', 'incl', 'excl',
  'cap', 'tab', 'inj', 'sol', 'susp', 'oint', 'supp',
]);

export function normaliseWhitespace(s: string): string {
  return s.replace(/\s+/g, ' ').trim();
}

function lastToken(before: string): string {
  const m = before.match(/([A-Za-z][A-Za-z.]*)$/);
  return m ? m[1] : '';
}

function isAbbreviation(before: string): boolean {
  // `before` ends right before the dot we are examining.
  const tok = lastToken(before).toLowerCase();
  if (!tok) return false;
  if (ABBREVIATIONS.has(tok)) return true;
  // single capital letter initial, e.g. "J. Smith" or a chemical/enumeration letter
  if (/(^|[\s(])[A-Z]$/.test(before)) return true;
  // dotted abbreviations such as "i.e" / "e.g"
  if (/\b[a-z]\.[a-z]$/i.test(before)) return true;
  return false;
}

function startsLikeSentence(after: string): boolean {
  // After a terminator, a new sentence normally starts with an upper-case
  // letter, a digit, or an opening quote/bracket followed by one.
  return /^["'“‘(\[]?[A-Z0-9]/.test(after);
}

/** Split a normalised passage text into sentence units. */
export function splitSentences(input: string): SentenceUnit[] {
  const text = normaliseWhitespace(input);
  if (!text) return [];

  const cuts: number[] = []; // index just after the terminator (and closing quote/bracket)
  const re = /[.!?]+["'”’)\]]*(?=\s)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text)) !== null) {
    const end = m.index + m[0].length;
    const terminatorStart = m.index;
    const after = text.slice(end).trimStart();
    if (!after) continue;
    if (!startsLikeSentence(after)) continue;
    // only a single '.' can be an abbreviation dot
    if (m[0].startsWith('.') && /^\.["'”’)\]]*$/.test(m[0])) {
      if (isAbbreviation(text.slice(0, terminatorStart))) continue;
      // numbered list marker at the very start, e.g. "1. Aspirin"
      if (/^\d{1,3}$/.test(text.slice(0, terminatorStart))) continue;
    }
    cuts.push(end);
  }

  const parts: string[] = [];
  let start = 0;
  for (const c of cuts) {
    parts.push(text.slice(start, c).trim());
    start = c;
  }
  parts.push(text.slice(start).trim());

  return parts
    .filter((p) => p.length > 0)
    .map((p, i) => ({
      idx: i,
      text: p,
      kind: /[.!?]["'”’)\]]*$/.test(p) ? ('sentence' as const) : ('fragment' as const),
    }));
}

/** The invariant the rest of the app relies on. */
export function unitsPreserveText(passageText: string, units: SentenceUnit[]): boolean {
  return normaliseWhitespace(units.map((u) => u.text).join(' ')) === normaliseWhitespace(passageText);
}
