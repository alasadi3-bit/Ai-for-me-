// Converts one pdf.js page into the plain items that extractPage() understands.
// Kept separate so extract.ts has no dependency on pdf.js and is easy to test.
import type { RawItem } from './extract';

export interface PdfJsPageLike {
  getTextContent(): Promise<{ items: any[] }>;
  getViewport(opts: { scale: number }): { width: number; height: number };
}

export async function pageToItems(
  page: PdfJsPageLike,
): Promise<{ items: RawItem[]; pageHeight: number; pageWidth: number }> {
  const viewport = page.getViewport({ scale: 1 });
  const tc = await page.getTextContent();
  const items: RawItem[] = [];
  for (const it of tc.items) {
    if (typeof it.str !== 'string') continue; // marked-content markers have no text
    const t: number[] = it.transform ?? [1, 0, 0, 1, 0, 0];
    const h = Math.hypot(t[2], t[3]) || it.height || 0;
    items.push({ str: it.str, x: t[4], y: t[5], w: it.width ?? 0, h, eol: !!it.hasEOL });
  }
  return { items, pageHeight: viewport.height, pageWidth: viewport.width };
}
