// Pre-lesson content: Mental Preparation, Prerequisite Concepts, Teaching Plan.
//
// Grounding rules enforced in code (not just requested in the prompt):
//  - The model may only cite passage labels (H1.., S1..) it was given.
//  - An item labelled "document" with no valid citation is downgraded to
//    "general background".
//  - Page numbers shown to the student come from the database, never from the model.
//  - The handout defines the required scope: any handout passage the teaching
//    plan did not cite is listed as uncovered, not hidden.

export const PRELESSON_PROMPT_VERSION = 'pl-v1';
export const PRELESSON_TOOL = 'submit_prelesson';

export interface PassageIn {
  id: string;
  page_index: number;
  kind: 'heading' | 'paragraph';
  text: string;
  heading_path?: string;
}
export interface Labelled {
  label: string; // H1.. or S1..
  passage: PassageIn;
}
export interface PreItem {
  title: string;
  text: string;
  basis: 'document' | 'general';
  refs: string[]; // passage ids
  flags: string[];
}
export interface PreLessonContent {
  mental_preparation: PreItem[];
  prerequisites: PreItem[];
  teaching_plan: PreItem[];
  uncovered_handout_passage_ids: string[];
  notes: string[];
}

// ------------------------------------------------ keyword context selection
const STOP = new Set(
  'this that with from have been were will would could should their there which these those about into than then them they also such other more most some when what where while only over under after before between because each many much very both can may might shall does doing done being its our your his her she him had has not but and the for are was you any all one two use used using via per'.split(' '),
);

export function tokens(s: string): string[] {
  return (s.toLowerCase().match(/[a-z][a-z0-9-]{3,}/g) ?? []).filter((t) => !STOP.has(t));
}

/**
 * Choose source passages that share vocabulary with each handout passage.
 * This is context selection for the AI, NOT matching: results are never
 * presented to the student as links.
 */
export function selectSourceContext(
  handout: PassageIn[],
  source: PassageIn[],
  opts: { perPassage?: number; maxTotal?: number; minShared?: number } = {},
): PassageIn[] {
  const perPassage = opts.perPassage ?? 2;
  const maxTotal = opts.maxTotal ?? 60;
  const minShared = opts.minShared ?? 2;
  if (!source.length) return [];

  const df = new Map<string, number>();
  const postings = new Map<string, number[]>();
  const sourceTokens = source.map((p) => new Set(tokens(p.text)));
  sourceTokens.forEach((set, i) => {
    for (const t of set) {
      df.set(t, (df.get(t) ?? 0) + 1);
      const arr = postings.get(t);
      if (arr) arr.push(i);
      else postings.set(t, [i]);
    }
  });
  const N = source.length;
  const idf = (t: string) => Math.log(1 + (N - (df.get(t) ?? 0) + 0.5) / ((df.get(t) ?? 0) + 0.5));

  const chosen = new Map<number, number>(); // source index -> best score
  for (const h of handout) {
    const q = new Set(tokens(h.text));
    if (!q.size) continue;
    const score = new Map<number, number>();
    const shared = new Map<number, number>();
    for (const t of q) {
      const p = postings.get(t);
      if (!p) continue;
      const w = idf(t);
      for (const i of p) {
        score.set(i, (score.get(i) ?? 0) + w);
        shared.set(i, (shared.get(i) ?? 0) + 1);
      }
    }
    const ranked = [...score.entries()]
      .filter(([i]) => (shared.get(i) ?? 0) >= minShared)
      .sort((a, b) => b[1] - a[1])
      .slice(0, perPassage);
    for (const [i, s] of ranked) chosen.set(i, Math.max(chosen.get(i) ?? 0, s));
  }
  return [...chosen.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, maxTotal)
    .map(([i]) => i)
    .sort((a, b) => a - b)
    .map((i) => source[i]);
}

// ---------------------------------------------------------------- the prompt
export const PRELESSON_SYSTEM = `You prepare a pharmacy student for a lecture before they start studying.
The lecture HANDOUT defines the required scope. The PRIMARY SOURCE provides the main learning material.
You receive handout passages labelled H1, H2, ... and source excerpts labelled S1, S2, ... The source excerpts were selected by keyword similarity only; they are NOT verified matches and may not cover every handout passage.

Write three sections:
- mental_preparation: the essential ideas and mental models the student should have in mind before starting (3 to 6 items).
- prerequisites: earlier concepts the student must already understand for this lesson (3 to 8 items).
- teaching_plan: the ordered sequence of what will be studied and explained, following the handout order, using the source for depth. Cover every handout passage by citing its label. If no source excerpt covers a handout passage, say so in that item.

Grounding rules (mandatory):
1. basis "document": use only when the item is directly supported by the provided passages, and list the supporting labels in refs (for example ["H3","S2"]).
2. basis "general": for background knowledge you add that is not stated in the provided passages. refs must be empty.
3. Only use labels that were provided. Never invent labels, page numbers, chapter names or quotations.
4. Keep every item concise and specific. Write in English.
5. Reply only by calling the ${PRELESSON_TOOL} tool.`;

const itemSchema = {
  type: 'object',
  properties: {
    title: { type: 'string' },
    text: { type: 'string' },
    basis: { type: 'string', enum: ['document', 'general'] },
    refs: { type: 'array', items: { type: 'string' } },
  },
  required: ['title', 'text', 'basis', 'refs'],
};

export function buildPreLessonRequest(model: string, handout: Labelled[], source: Labelled[], trimHandout = false) {
  const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n) + ' [shortened]' : s);
  const h = handout.map((x) => `${x.label} (${x.passage.kind}, handout page ${x.passage.page_index}): ${trimHandout ? clip(x.passage.text, 300) : x.passage.text}`);
  const s = source.map((x) => `${x.label} (source page ${x.passage.page_index}): ${clip(x.passage.text, 900)}`);
  const user =
    'HANDOUT PASSAGES\n' + h.join('\n') +
    '\n\nSOURCE EXCERPTS (keyword-selected, not verified matches)\n' + (s.length ? s.join('\n') : '(none selected)');
  return {
    model,
    max_tokens: 8000,
    system: PRELESSON_SYSTEM,
    messages: [{ role: 'user', content: user }],
    tools: [
      {
        name: PRELESSON_TOOL,
        description: 'Submit the three pre-lesson sections.',
        input_schema: {
          type: 'object',
          properties: {
            mental_preparation: { type: 'array', items: itemSchema },
            prerequisites: { type: 'array', items: itemSchema },
            teaching_plan: { type: 'array', items: itemSchema },
          },
          required: ['mental_preparation', 'prerequisites', 'teaching_plan'],
        },
      },
    ],
    tool_choice: { type: 'tool', name: PRELESSON_TOOL },
  };
}

export function parsePreLessonResponse(resp: any): { raw: any } | { error: string } {
  if (!resp || !Array.isArray(resp.content)) return { error: 'unexpected response shape' };
  if (resp.stop_reason === 'max_tokens') return { error: 'model output was cut off (max_tokens)' };
  const block = resp.content.find((b: any) => b?.type === 'tool_use' && b?.name === PRELESSON_TOOL);
  if (!block || typeof block.input !== 'object' || !block.input) return { error: 'model did not return the pre-lesson' };
  return { raw: block.input };
}

// ------------------------------------------------------------- validation
function cleanItems(arr: any, byLabel: Map<string, string>, maxItems: number): PreItem[] {
  if (!Array.isArray(arr)) return [];
  const out: PreItem[] = [];
  for (const it of arr.slice(0, maxItems)) {
    if (!it || typeof it.text !== 'string' || !it.text.trim()) continue;
    const flags: string[] = [];
    const given: string[] = Array.isArray(it.refs) ? it.refs.filter((r: any) => typeof r === 'string') : [];
    const ids: string[] = [];
    for (const r of given) {
      const id = byLabel.get(r.trim().toUpperCase());
      if (id) { if (!ids.includes(id)) ids.push(id); }
      else flags.push('invalid_reference_removed');
    }
    let basis: 'document' | 'general' = it.basis === 'document' ? 'document' : 'general';
    if (basis === 'document' && ids.length === 0) {
      basis = 'general';
      flags.push('no_valid_reference_downgraded');
    }
    out.push({
      title: typeof it.title === 'string' ? it.title.trim() : '',
      text: it.text.trim(),
      basis,
      refs: basis === 'document' ? ids : [],
      flags: [...new Set(flags)],
    });
  }
  return out;
}

export function validatePreLesson(raw: any, handout: Labelled[], source: Labelled[], notes: string[] = []): PreLessonContent {
  const byLabel = new Map<string, string>();
  for (const l of [...handout, ...source]) byLabel.set(l.label.toUpperCase(), l.passage.id);

  const mental = cleanItems(raw?.mental_preparation, byLabel, 8);
  const prereq = cleanItems(raw?.prerequisites, byLabel, 10);
  const plan = cleanItems(raw?.teaching_plan, byLabel, 60);

  const handoutIds = new Set(handout.map((h) => h.passage.id));
  const cited = new Set<string>();
  for (const it of plan) for (const r of it.refs) if (handoutIds.has(r)) cited.add(r);
  const uncovered = handout.filter((h) => !cited.has(h.passage.id)).map((h) => h.passage.id);

  const outNotes = [...notes];
  if (!mental.length) outNotes.push('The AI returned no Mental Preparation items.');
  if (!prereq.length) outNotes.push('The AI returned no Prerequisite Concepts.');
  if (!plan.length) outNotes.push('The AI returned no Teaching Plan.');

  return {
    mental_preparation: mental,
    prerequisites: prereq,
    teaching_plan: plan,
    uncovered_handout_passage_ids: uncovered,
    notes: outNotes,
  };
}

export function labelPassages(prefix: 'H' | 'S', passages: PassageIn[]): Labelled[] {
  return passages.map((p, i) => ({ label: `${prefix}${i + 1}`, passage: p }));
}
