// Page text extraction, paragraph/heading structure and quality flags.
//
// Input is the list of text items a PDF reader (pdf.js) reports for one page.
// This module never drops content silently and never "fixes" words by guessing:
//   - raw_text keeps the lines exactly as extracted (joined with \n),
//   - text is the same content with whitespace normalised (and, only for a
//     lower-case continuation after a line-end hyphen, the hyphen joined; this
//     is flagged 'dehyphenated'),
//   - anything suspicious is recorded as a flag so the UI can send the student
//     to the original page.

export interface RawItem {
  str: string;
  x: number; // left edge
  y: number; // baseline, PDF coordinates (origin bottom-left)
  w: number; // width
  h: number; // font height
  eol?: boolean;
}

export interface Line {
  text: string;
  x: number;
  xEnd: number;
  y: number;
  size: number;
  wideGaps: number;
}

export interface ExtractedPassage {
  seq: number;
  kind: 'heading' | 'paragraph';
  headingPath: string;
  rawText: string;
  text: string;
  flags: string[];
}

export interface ExtractedPage {
  pageIndex: number;
  printedLabel: string | null;
  rawText: string;
  charCount: number;
  status: 'ok' | 'empty';
  flags: string[];
  passages: ExtractedPassage[];
}

const LIGATURES: Record<string, string> = {
  'ﬀ': 'ff', 'ﬁ': 'fi', 'ﬂ': 'fl', 'ﬃ': 'ffi', 'ﬄ': 'ffl', 'ﬅ': 'st', 'ﬆ': 'st',
};

export function mapLigatures(s: string): string {
  return s.replace(/[ﬀ-ﬆ]/g, (c) => LIGATURES[c] ?? c);
}

export const EMPTY_PAGE_MIN_CHARS = 25;

export function buildLines(items: RawItem[]): Line[] {
  const lines: Line[] = [];
  let cur: { parts: string[]; x: number; xEnd: number; y: number; size: number; wideGaps: number } | null = null;
  let prevEnd = 0;
  let prevStr = '';
  let startNext = true;

  const flush = () => {
    if (cur) {
      const text = cur.parts.join('');
      if (text.trim().length > 0) {
        lines.push({ text, x: cur.x, xEnd: cur.xEnd, y: cur.y, size: cur.size, wideGaps: cur.wideGaps });
      }
    }
    cur = null;
  };

  for (const it of items) {
    if (it.str === '' && !it.eol) continue;
    const size = it.h > 0 ? it.h : 10;
    const newLine =
      startNext ||
      !cur ||
      Math.abs(it.y - cur.y) > 0.5 * Math.max(size, cur.size);
    if (newLine) {
      flush();
      cur = { parts: [it.str], x: it.x, xEnd: it.x + it.w, y: it.y, size: it.str.trim() ? size : 0, wideGaps: 0 };
    } else if (cur) {
      const gap = it.x - prevEnd;
      const needSpace = gap > 0.12 * size && !/\s$/.test(prevStr) && !/^\s/.test(it.str);
      if (gap > 4 * size && it.str.trim()) cur.wideGaps += 1;
      cur.parts.push(needSpace ? ' ' + it.str : it.str);
      cur.xEnd = Math.max(cur.xEnd, it.x + it.w);
      if (it.str.trim()) cur.size = Math.max(cur.size, size);
    }
    prevEnd = it.x + it.w;
    prevStr = it.str;
    startNext = !!it.eol;
  }
  flush();
  return lines.map((l) => ({ ...l, text: l.text.replace(/[ \t]+/g, ' ').trim(), size: l.size || 10 }));
}

function median(nums: number[]): number {
  if (!nums.length) return 10;
  const s = [...nums].sort((a, b) => a - b);
  return s[Math.floor(s.length / 2)];
}

/** Body text size = the font size carrying the most characters. */
function bodySizeOf(lines: Line[]): number {
  const weight = new Map<number, number>();
  for (const l of lines) {
    const k = Math.round(l.size * 2) / 2;
    weight.set(k, (weight.get(k) ?? 0) + l.text.length);
  }
  let best = 10;
  let bestW = -1;
  for (const [k, w] of weight) if (w > bestW) { best = k; bestW = w; }
  return best;
}

const PAGE_NUMBER_RE = /^(?:page\s*)?(\d{1,4}|[ivxlcdm]{1,7})$/i;
const LIST_MARKER_RE = /^(?:[•●▪◦‣⁃]|[-–—*]\s|\(?\d{1,2}[.)]\s|\(?[a-z][.)]\s)/;
const TERMINATOR_RE = /[.!?:]["'”’)\]]*$/;

function qualityFlags(text: string): string[] {
  const flags: string[] = [];
  if (/�/.test(text)) flags.push('garbled');
  if (/[-]/.test(text)) flags.push('garbled_font');
  const nonSpace = text.replace(/\s/g, '');
  if (nonSpace.length >= 30) {
    const letters = (nonSpace.match(/\p{L}/gu) ?? []).length;
    if (letters / nonSpace.length < 0.45) flags.push('low_text_quality');
  }
  return flags;
}

export function extractPage(
  items: RawItem[],
  opts: { pageIndex: number; pageHeight: number },
): ExtractedPage {
  const { pageIndex, pageHeight } = opts;
  const rawPageText = items.map((i) => i.str + (i.eol ? '\n' : '')).join('');
  let lines = buildLines(items);
  const charCount = lines.reduce((n, l) => n + l.text.replace(/\s/g, '').length, 0);
  const pageFlags: string[] = [];

  if (charCount < EMPTY_PAGE_MIN_CHARS) {
    return {
      pageIndex,
      printedLabel: null,
      rawText: rawPageText,
      charCount,
      status: 'empty',
      flags: ['no_text_layer'],
      passages: [],
    };
  }

  // Printed page number lines in the top/bottom margin are recorded as a label
  // (shown as unverified) and excluded from passages.
  let printedLabel: string | null = null;
  if (pageHeight > 0) {
    const keep: Line[] = [];
    for (const l of lines) {
      const inMargin = l.y < pageHeight * 0.08 || l.y > pageHeight * 0.92;
      const m = inMargin ? l.text.match(PAGE_NUMBER_RE) : null;
      if (m && printedLabel === null) {
        printedLabel = m[1];
        if (!pageFlags.includes('page_number_line_excluded')) pageFlags.push('page_number_line_excluded');
        continue;
      }
      keep.push(l);
    }
    lines = keep;
  }

  // Reading-order and layout warnings.
  let jumps = 0;
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].y > lines[i - 1].y + 2 * lines[i - 1].size) jumps++;
  }
  if (jumps >= 2) pageFlags.push('order_jump_or_columns');
  const wideGapLines = lines.filter((l) => l.wideGaps > 0).length;
  if (wideGapLines >= 3) pageFlags.push('possible_table_or_columns');

  const body = bodySizeOf(lines);
  const maxXEnd = Math.max(0, ...lines.filter((l) => l.size <= body * 1.1).map((l) => l.xEnd));

  const passages: ExtractedPassage[] = [];
  const headingStack: { size: number; text: string }[] = [];
  let seq = 0;

  type Draft = { lines: Line[]; kind: 'heading' | 'paragraph'; headingPath: string };
  let draft: Draft | null = null;

  const push = () => {
    if (!draft) return;
    const rawText = draft.lines.map((l) => l.text).join('\n');
    const flags = new Set<string>();
    let text: string;
    if (draft.kind === 'heading') {
      text = mapLigatures(draft.lines.map((l) => l.text).join(' ')).replace(/\s+/g, ' ').trim();
    } else {
      let acc = '';
      for (let i = 0; i < draft.lines.length; i++) {
        const t = draft.lines[i].text;
        if (i === 0) { acc = t; continue; }
        if (/[A-Za-z]-$/.test(acc) && /^[a-z]/.test(t)) {
          acc = acc.slice(0, -1) + t;
          flags.add('dehyphenated');
        } else {
          acc += ' ' + t;
        }
      }
      text = mapLigatures(acc).replace(/\s+/g, ' ').trim();
    }
    for (const f of qualityFlags(text)) flags.add(f);
    passages.push({
      seq: seq++,
      kind: draft.kind,
      headingPath: draft.headingPath,
      rawText,
      text,
      flags: [...flags],
    });
    draft = null;
  };

  let prev: Line | null = null;
  let prevWasHeading = false;
  for (const line of lines) {
    const isHeading =
      line.size >= body * 1.18 &&
      line.text.length <= 140 &&
      !/[,;]$/.test(line.text);

    if (isHeading) {
      if (prevWasHeading && draft && draft.kind === 'heading' && prev && Math.abs(prev.size - line.size) < 0.5 && prev.y - line.y < prev.size * 2) {
        draft.lines.push(line); // multi-line heading
        const top = headingStack[headingStack.length - 1];
        if (top) top.text = draft.lines.map((l) => l.text).join(' ');
      } else {
        push();
        while (headingStack.length && headingStack[headingStack.length - 1].size <= line.size + 0.25) headingStack.pop();
        headingStack.push({ size: line.size, text: line.text });
        draft = { lines: [line], kind: 'heading', headingPath: headingStack.map((h) => h.text).join(' › ') };
      }
      prevWasHeading = true;
      prev = line;
      continue;
    }

    const path = headingStack.map((h) => h.text).join(' › ');
    let breakBefore = false;
    if (!draft || draft.kind === 'heading') {
      breakBefore = true;
    } else if (prev) {
      const gapY = prev.y - line.y;
      if (gapY > 1.6 * Math.max(prev.size, line.size)) breakBefore = true;
      else if (line.y > prev.y + 0.5 * prev.size) breakBefore = true; // moved up: new column or block
      else if (LIST_MARKER_RE.test(line.text)) breakBefore = true;
      else if (line.x - prev.x > 1.2 * line.size && TERMINATOR_RE.test(prev.text)) breakBefore = true;
      else if (maxXEnd > 0 && prev.xEnd < maxXEnd * 0.8 && TERMINATOR_RE.test(prev.text) && /^["'“(]?[A-Z0-9]/.test(line.text)) breakBefore = true;
    }
    if (breakBefore) {
      push();
      draft = { lines: [line], kind: 'paragraph', headingPath: path };
    } else if (draft) {
      draft.lines.push(line);
    }
    prevWasHeading = false;
    prev = line;
  }
  push();

  // Paragraphs that run across a page boundary are stored per page; flag them.
  const paras = passages.filter((p) => p.kind === 'paragraph');
  if (paras.length) {
    const first = paras[0];
    const last = paras[paras.length - 1];
    if (/^[a-z]/.test(first.text)) first.flags.push('continues_previous_page');
    if (!TERMINATOR_RE.test(last.text) && last === passages[passages.length - 1]) last.flags.push('continues_next_page');
  }

  return {
    pageIndex,
    printedLabel,
    rawText: rawPageText,
    charCount,
    status: 'ok',
    flags: pageFlags,
    passages,
  };
}

/** Decide whether a whole document can be treated as a text PDF. */
export function classifyDocument(pages: { status: 'ok' | 'empty' | 'failed' }[]): {
  supported: boolean;
  message: string | null;
} {
  const total = pages.length;
  if (total === 0) return { supported: false, message: 'The file has no pages.' };
  const empty = pages.filter((p) => p.status === 'empty').length;
  if (empty / total >= 0.6) {
    return {
      supported: false,
      message:
        `${empty} of ${total} pages have no readable text layer. This looks like a scanned or image-based PDF. ` +
        'Scanned PDFs, photos and slide images are not supported yet, so this file was NOT processed.',
    };
  }
  return { supported: true, message: empty > 0 ? `${empty} page(s) have no readable text and are marked as empty.` : null };
}
