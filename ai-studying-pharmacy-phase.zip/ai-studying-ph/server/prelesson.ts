import {
  ApiError, DEFAULT_MODEL, isUuid, makeSb, callAnthropic, errorResult,
  type Env, type FetchLike, type HandlerResult,
} from './common';
import {
  PRELESSON_PROMPT_VERSION, buildPreLessonRequest, labelPassages, parsePreLessonResponse,
  selectSourceContext, validatePreLesson, type PassageIn,
} from '../src/lib/prelesson';

export interface PreLessonInput {
  env: Env;
  fetchImpl: FetchLike;
  token: string | null;
  body: any;
}

const PASSAGE_COLS = 'id,page_index,seq,kind,heading_path,text';
const HANDOUT_TRIM_THRESHOLD = 60_000; // characters

/**
 * Build (or return the cached) pre-lesson for a handout + optional source.
 * The model only sees passages that exist in the database and may only cite their labels;
 * validatePreLesson removes anything else.
 */
export async function handlePreLesson(input: PreLessonInput): Promise<HandlerResult> {
  try {
    const { env, fetchImpl, token, body } = input;
    if (!token) throw new ApiError(401, 'not_signed_in', 'Sign in first.');
    const handoutId = body?.handoutId;
    const sourceId = body?.sourceId ?? null;
    if (!isUuid(handoutId)) throw new ApiError(400, 'bad_request', 'handoutId must be a valid id.');
    if (sourceId !== null && !isUuid(sourceId)) throw new ApiError(400, 'bad_request', 'sourceId must be a valid id.');
    const force = body?.force === true;

    const sb = makeSb(env, token, fetchImpl);
    const pairFilter = `handout_id=eq.${handoutId}&source_id=${sourceId ? `eq.${sourceId}` : 'is.null'}`;

    if (!force) {
      const cached = await sb.get(`prelessons?${pairFilter}&select=id,content,model,prompt_version,created_at&order=created_at.desc&limit=1`);
      if (cached.length) return { status: 200, json: { status: 'cached', prelesson: cached[0] } };
    }

    const handout: PassageIn[] = await sb.getAll(
      `passages?document_id=eq.${handoutId}&select=${PASSAGE_COLS}&order=page_index.asc,seq.asc`,
    );
    if (!handout.length) throw new ApiError(409, 'handout_not_ready', 'The handout has no extracted text yet.');
    const source: PassageIn[] = sourceId
      ? await sb.getAll(`passages?document_id=eq.${sourceId}&select=${PASSAGE_COLS}&order=page_index.asc,seq.asc`)
      : [];

    const notes: string[] = [];
    if (!sourceId) notes.push('No primary source was selected, so nothing in this plan is grounded in a source.');
    const selected = selectSourceContext(handout, source);
    if (sourceId && !selected.length) notes.push('No source passages shared enough vocabulary with the handout to be offered to the AI.');
    const hl = labelPassages('H', handout);
    const sl = labelPassages('S', selected);

    const handoutChars = handout.reduce((a, p) => a + p.text.length, 0);
    const trim = handoutChars > HANDOUT_TRIM_THRESHOLD;
    if (trim) notes.push('The handout is long, so long passages were shortened when sent to the AI.');

    const model = env.ANTHROPIC_MODEL || DEFAULT_MODEL;
    const resp = await callAnthropic(env, fetchImpl, buildPreLessonRequest(model, hl, sl, trim));
    const parsed = parsePreLessonResponse(resp);
    if ('error' in parsed) throw new ApiError(502, 'prelesson_failed', `The AI did not return a usable pre-lesson: ${parsed.error}.`);

    const content = validatePreLesson(parsed.raw, hl, sl, notes);
    const rows = await sb.insert(
      'prelessons',
      { handout_id: handoutId, source_id: sourceId, content, model, prompt_version: PRELESSON_PROMPT_VERSION },
      { returning: true },
    );
    return { status: 200, json: { status: 'ok', prelesson: rows[0] ?? { content, model, prompt_version: PRELESSON_PROMPT_VERSION } } };
  } catch (e) {
    return errorResult(e);
  }
}
