// Shared server helpers. Runs inside Vercel serverless functions.
// The server NEVER uses a service-role key: it calls Supabase with the
// signed-in student's own token, so Row Level Security applies to every call.

export interface Env {
  SUPABASE_URL?: string;
  SUPABASE_ANON_KEY?: string;
  ANTHROPIC_API_KEY?: string;
  ANTHROPIC_MODEL?: string;
  [k: string]: string | undefined;
}

export type FetchLike = (input: string, init?: any) => Promise<any>;

export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export interface HandlerResult {
  status: number;
  json: unknown;
}

export const DEFAULT_MODEL = 'claude-sonnet-5-5';
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const isUuid = (s: unknown): s is string => typeof s === 'string' && UUID_RE.test(s);

export function requireSupabase(env: Env): { url: string; anon: string } {
  const url = (env.SUPABASE_URL || '').replace(/\/+$/, '');
  const anon = env.SUPABASE_ANON_KEY || '';
  if (!url || !anon) {
    throw new ApiError(503, 'supabase_not_configured', 'SUPABASE_URL and SUPABASE_ANON_KEY are not set on the server.');
  }
  return { url, anon };
}

export function requireAnthropicKey(env: Env): string {
  if (!env.ANTHROPIC_API_KEY) {
    throw new ApiError(503, 'ai_not_configured', 'ANTHROPIC_API_KEY is not set on the server, so AI features are unavailable.');
  }
  return env.ANTHROPIC_API_KEY;
}

export interface Sb {
  get(path: string): Promise<any[]>;
  getAll(path: string, pageSize?: number): Promise<any[]>;
  insert(table: string, rows: unknown, opts?: { returning?: boolean }): Promise<any[]>;
}

/** Minimal PostgREST client that acts as the signed-in student. */
export function makeSb(env: Env, token: string, fetchImpl: FetchLike): Sb {
  const { url, anon } = requireSupabase(env);
  const headers = (extra: Record<string, string> = {}) => ({
    apikey: anon,
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra,
  });
  const fail = async (r: any, what: string): Promise<never> => {
    let detail = '';
    try { const j = await r.json(); detail = j?.message || j?.hint || JSON.stringify(j); } catch { /* ignore */ }
    if (r.status === 401 || r.status === 403) throw new ApiError(401, 'not_authorised', `Supabase refused the request (${what}). Sign in again. ${detail}`.trim());
    throw new ApiError(502, 'supabase_error', `Supabase error during ${what} (HTTP ${r.status}). ${detail}`.trim());
  };
  const get = async (path: string) => {
    const r = await fetchImpl(`${url}/rest/v1/${path}`, { headers: headers() });
    if (!r.ok) await fail(r, `read ${path.split('?')[0]}`);
    return (await r.json()) as any[];
  };
  return {
    get,
    async getAll(path, pageSize = 1000) {
      const out: any[] = [];
      for (let offset = 0; ; offset += pageSize) {
        const sep = path.includes('?') ? '&' : '?';
        const rows = await get(`${path}${sep}limit=${pageSize}&offset=${offset}`);
        out.push(...rows);
        if (rows.length < pageSize) break;
      }
      return out;
    },
    async insert(table, rows, opts = {}) {
      const r = await fetchImpl(`${url}/rest/v1/${table}`, {
        method: 'POST',
        headers: headers({ Prefer: opts.returning ? 'return=representation' : 'return=minimal' }),
        body: JSON.stringify(rows),
      });
      if (!r.ok) await fail(r, `write ${table}`);
      return opts.returning ? ((await r.json()) as any[]) : [];
    },
  };
}

export interface AnthropicCall {
  body: unknown;
}

/** Call the Anthropic Messages API. The key never leaves the server. */
export async function callAnthropic(env: Env, fetchImpl: FetchLike, body: unknown): Promise<any> {
  const key = requireAnthropicKey(env);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 55_000);
  let r: any;
  try {
    r = await fetchImpl('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
  } catch (e: any) {
    throw new ApiError(504, 'ai_unreachable', e?.name === 'AbortError' ? 'The AI request timed out.' : `Could not reach the AI service: ${e?.message ?? e}`);
  } finally {
    clearTimeout(timer);
  }
  let json: any = null;
  try { json = await r.json(); } catch { /* ignore */ }
  if (!r.ok) {
    const msg = json?.error?.message || `HTTP ${r.status}`;
    if (r.status === 401) throw new ApiError(502, 'ai_key_invalid', 'The AI service rejected ANTHROPIC_API_KEY. Check the key in the Vercel environment variables.');
    if (r.status === 404) throw new ApiError(502, 'ai_model_not_found', `The AI model was not found (${msg}). Set ANTHROPIC_MODEL to a model your key can use.`);
    if (r.status === 429) throw new ApiError(429, 'ai_rate_limited', 'The AI service is rate limiting requests. Try again shortly.');
    throw new ApiError(502, 'ai_error', `The AI service returned an error: ${msg}`);
  }
  return json;
}

export function errorResult(e: unknown): HandlerResult {
  if (e instanceof ApiError) return { status: e.status, json: { error: e.code, message: e.message } };
  const msg = e instanceof Error ? e.message : String(e);
  return { status: 500, json: { error: 'internal', message: msg } };
}
