import {
  ApiError, DEFAULT_MODEL, isUuid, makeSb, callAnthropic, errorResult,
  type Env, type FetchLike, type HandlerResult,
} from './common';
import {
  PROMPT_VERSION, buildAnthropicRequest, parseAnthropicResponse, validateBatch, chunkUnits,
  type UnitIn,
} from '../src/lib/translation';

export interface TranslateInput {
  env: Env;
  fetchImpl: FetchLike;
  token: string | null;
  body: any;
}

/**
 * Translate every sentence unit of one passage that has no translation yet.
 * Existing translations are never regenerated or overwritten (append-only).
 */
export async function handleTranslate(input: TranslateInput): Promise<HandlerResult> {
  try {
    const { env, fetchImpl, token, body } = input;
    if (!token) throw new ApiError(401, 'not_signed_in', 'Sign in first.');
    const passageId = body?.passageId;
    if (!isUuid(passageId)) throw new ApiError(400, 'bad_request', 'passageId must be a valid id.');

    const sb = makeSb(env, token, fetchImpl);
    const units: { id: string; idx: number; text: string }[] = await sb.getAll(
      `units?passage_id=eq.${passageId}&select=id,idx,text&order=idx.asc`,
    );
    if (!units.length) throw new ApiError(404, 'not_found', 'No sentence units found for this passage.');

    const ids = units.map((u) => u.id).join(',');
    const have: { unit_id: string }[] = await sb.getAll(`translations?unit_id=in.(${ids})&select=unit_id`);
    const haveSet = new Set(have.map((h) => h.unit_id));
    const todo: UnitIn[] = units.filter((u) => !haveSet.has(u.id)).map((u) => ({ id: u.id, text: u.text }));
    if (!todo.length) return { status: 200, json: { status: 'cached', translated: 0, failed: [], flagged: 0 } };

    const model = env.ANTHROPIC_MODEL || DEFAULT_MODEL;
    let translated = 0;
    let flagged = 0;
    const failed: { unitId: string; reason: string }[] = [];

    for (const batch of chunkUnits(todo)) {
      let resp: any;
      try {
        resp = await callAnthropic(env, fetchImpl, buildAnthropicRequest(model, batch));
      } catch (e) {
        if (e instanceof ApiError && translated + failed.length === 0 && batch === todo.slice(0, batch.length)) throw e;
        for (const u of batch) failed.push({ unitId: u.id, reason: e instanceof ApiError ? e.code : 'ai_error' });
        continue;
      }
      const parsed = parseAnthropicResponse(resp);
      if ('error' in parsed) {
        for (const u of batch) failed.push({ unitId: u.id, reason: parsed.error });
        continue;
      }
      const v = validateBatch(batch, parsed.translations);
      if (v.accepted.length) {
        await sb.insert(
          'translations',
          v.accepted.map((a) => ({
            unit_id: a.id,
            machine_text: a.arabic,
            model,
            prompt_version: PROMPT_VERSION,
            flags: a.flags,
            checks: a.checks,
          })),
        );
        translated += v.accepted.length;
        flagged += v.accepted.filter((a) => a.flags.length > 0).length;
      }
      for (const m of v.missing) failed.push({ unitId: m.id, reason: `translation_${m.reason}` });
    }

    return { status: failed.length ? 207 : 200, json: { status: failed.length ? 'partial' : 'ok', translated, failed, flagged } };
  } catch (e) {
    return errorResult(e);
  }
}
