// Thin adapter between Node/Vercel request objects and the testable handlers in this folder.
import { errorResult, type Env, type HandlerResult } from './common';
import { handleTranslate } from './translate';
import { handlePreLesson } from './prelesson';

export type Handler = (i: { env: Env; fetchImpl: any; token: string | null; body: any }) => Promise<HandlerResult>;

export function bearerToken(header: unknown): string | null {
  if (typeof header !== 'string') return null;
  const m = header.match(/^Bearer\s+(\S+)$/i);
  return m ? m[1] : null;
}

export function publicConfig(env: Env): HandlerResult {
  const url = (env.SUPABASE_URL || '').replace(/\/+$/, '');
  const anonKey = env.SUPABASE_ANON_KEY || '';
  return {
    status: 200,
    json: {
      // The anon key is designed to be public: Row Level Security protects the data.
      supabaseUrl: url || null,
      supabaseAnonKey: anonKey || null,
      supabaseConfigured: !!(url && anonKey),
      aiConfigured: !!env.ANTHROPIC_API_KEY, // boolean only; the key itself is never sent
    },
  };
}

export function makeNodeHandler(handler: Handler) {
  return async function (req: any, res: any) {
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'POST') {
      res.statusCode = 405;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ error: 'method_not_allowed', message: 'Use POST.' }));
      return;
    }
    let result: HandlerResult;
    try {
      let body = req.body;
      if (typeof body === 'string') body = JSON.parse(body);
      result = await handler({
        env: process.env as Env,
        fetchImpl: fetch,
        token: bearerToken(req.headers?.authorization),
        body: body ?? {},
      });
    } catch (e) {
      result = errorResult(e);
    }
    res.statusCode = result.status;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(result.json));
  };
}

export const translateHandler = makeNodeHandler(handleTranslate);
export const preLessonHandler = makeNodeHandler(handlePreLesson);
