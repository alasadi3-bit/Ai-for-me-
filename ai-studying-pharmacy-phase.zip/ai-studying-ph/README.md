# AI for Studying Pharmacy

Personal study app: upload a primary source and a lecture handout (text-based PDFs), study them side by side with a faithful Arabic translation under each English sentence, with a study timer and manual passage links.

* Setup (Supabase, Vercel, roles): [`docs/supabase-setup.md`](docs/supabase-setup.md)
* Plan: [`docs/project-plan.md`](docs/project-plan.md)

## Run the tests
```
python3 scripts/make-fixtures.py        # creates the three test PDFs (they are not stored in git)
npm run build                           # transpiles src/lib and copies pdf.js (legacy build)
npm test                                # unit, security, client-session and RLS tests
npm run test:e2e                        # browser tests (needs Playwright + Chromium)
```
`tests/rls.test.ts` starts a temporary PostgreSQL server (needs the PostgreSQL 16 server binaries and root). If they are missing the suite is **skipped**, not passed.
